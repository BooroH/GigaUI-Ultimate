package application.setting;

public class Settings {
	private Settings() {
	}

	private static class Holder {
		private static final Settings INSTANCE = new Settings();
	}

	public static Settings getInstance() {
		return Holder.INSTANCE;
	}

	private int icon_spacing = -4;
	private int slot_size = 55;
	private int perk_size = 47;
	private int dirSlot_size = 57;
	private int bottomBar_row = 2;
	private int bottomBar_column = 17;
	private int bottomBar_Pos_Y = 6;
	private int lPortrait_x = -263;
	private int lPortrait_y = 8;
	private int rPortrait_x = 263;
	private int rPortrait_y = 8;
	private int lrPortrait_y_diff = 38;
	private int lp_buff_size = 31;
	private int lp_buff_spacing = 1;
	private int lp_buff_column = 8;
	private int rp_buff_size = 31;
	private int rp_buff_spacing = 1;
	private int rp_buff_column = 8;
	private int rp_buff_filter = 3; // 0=없음 1=디버프만 2=버프만 3=둘다
	private int soulshard_x = 0;
	private int soulshard_y = 6;
	private int floatingPortrait_buff_filter = 1;
	private int floatingPortrait_buff_size = 20;
	private int floatingPortrait_buff_spacing = 0;
	private int floatingPortrait_buff_column = 10;
	private int floatingPortrait_style = 1;
	private int floatingPortrait_hp_color = 1;
	private int floatingPortrait_hp_thickness = 33;
	private int miniSlot_count = 0;
	private int miniSlot_spacing = -3;
	private int miniSlot_margin = 4;
	private int miniSlot_size = 37;
	private int miniSlot_pos_x = -210;
	private int miniSlot_pos_y = 0;
	private int showMiniMap = 1;
	private int isSimpleMap = 0;
	private int isCSIHorizontal = 0;
	private int castBar_style = 1;
	private int castBar_text_location = 1;
	private int castBar_color = 1;
	private int castBar_thickness = 3;
	private int inventory_layout = 1;
	private int inventory_row = 10;
	private int inventory_column = 8;
	private int trader_layout = 1;
	private int trader_row = 5;
	private int trader_column = 10;
	private int fontSize = 0;
	private int cdFontSize = 15;
	private int hpLabelBrightness = 100;
	private int buffTextBrightness = 87;
	private int top_buff_size = 31;
	private int top_buff_spacing = 1;
	private int top_buff_column = 20;
	private int petListSize = 240;
	private int groupHPColor = 1;
	private int raidHPColor = 1;
	private int overheadHPSize = 1;
	private int overheadHPColor = 1;
	private int overheadFontSize = 32;
	private int targetOfTargetX = 220;
	private int targetOfTargetY = 0;
	private int targetOfTargetYMinus = 0;

	private double nameplate_alpha = 0.8;
	private double floatingPortrait_bar_alpha = 1.0;
	private double castBar_alpha = 1.0;
	private double petListAlpha = 0.93;
	private double overheadHPAlpha = 1.0;

	private boolean isHideEmptySlots = false;
	private boolean floatingPortrait_show_mana = false;
	private boolean isMiniSlotHide = false;
	private boolean isSlotHideForOptionOnly = false;
	private boolean isHPLabelBold = false;
	private boolean isPetListSizeLimit = true;

	private String cdFontWeight = "GG Bold";
	private String overheadFontWeight = "GG Regular";
	
	public int getTargetOfTargetYMinus() {
		return targetOfTargetYMinus;
	}
	
	public void setTargetOfTargetYMinus(int targetOfTargetYMinus) {
		this.targetOfTargetYMinus = targetOfTargetYMinus;
	}

	public int getTargetOfTargetX() {
		return targetOfTargetX;
	}
	
	public void setTargetOfTargetX(int targetOfTargetX) {
		this.targetOfTargetX = targetOfTargetX;
	}
	
	public int getTargetOfTargetY() {
		return targetOfTargetY;
	}
	
	public void setTargetOfTargetY(int targetOfTargetY) {
		this.targetOfTargetY = targetOfTargetY;
	}
	
	public int getIcon_spacing() {
		return icon_spacing;
	}

	public void setIcon_spacing(int icon_spacing) {
		this.icon_spacing = icon_spacing;
	}

	public int getSlot_size() {
		return slot_size;
	}

	public void setSlot_size(int slot_size) {
		this.slot_size = slot_size;
	}

	public int getPerk_size() {
		return perk_size;
	}

	public void setPerk_size(int perk_size) {
		this.perk_size = perk_size;
	}

	public int getDirSlot_size() {
		return dirSlot_size;
	}

	public void setDirSlot_size(int dirSlot_size) {
		this.dirSlot_size = dirSlot_size;
	}

	public int getBottomBar_row() {
		return bottomBar_row;
	}

	public void setBottomBar_row(int bottomBar_row) {
		this.bottomBar_row = bottomBar_row;
	}

	public int getBottomBar_column() {
		return bottomBar_column;
	}

	public void setBottomBar_column(int bottomBar_column) {
		this.bottomBar_column = bottomBar_column;
	}

	public int getBottomBar_Pos_Y() {
		return bottomBar_Pos_Y;
	}

	public void setBottomBar_Pos_Y(int bottomBar_Pos_Y) {
		this.bottomBar_Pos_Y = bottomBar_Pos_Y;
	}

	public int getLPortrait_x() {
		return lPortrait_x;
	}

	public void setLPortrait_x(int lPortrait_x) {
		this.lPortrait_x = lPortrait_x;
	}

	public int getLPortrait_y() {
		return lPortrait_y;
	}

	public void setLPortrait_y(int lPortrait_y) {
		this.lPortrait_y = lPortrait_y;
	}

	public int getRPortrait_x() {
		return rPortrait_x;
	}

	public void setRPortrait_x(int rPortrait_x) {
		this.rPortrait_x = rPortrait_x;
	}

	public int getRPortrait_y() {
		return rPortrait_y;
	}

	public void setRPortrait_y(int rPortrait_y) {
		this.rPortrait_y = rPortrait_y;
	}

	public int getLRPortrait_y_diff() {
		return lrPortrait_y_diff;
	}

	public void setLRPortrait_y_diff(int lrPortrait_y_diff) {
		this.lrPortrait_y_diff = lrPortrait_y_diff;
	}

	public int getLP_buff_size() {
		return lp_buff_size;
	}

	public void setLP_buff_size(int lp_buff_size) {
		this.lp_buff_size = lp_buff_size;
	}

	public int getLP_buff_spacing() {
		return lp_buff_spacing;
	}

	public void setLP_buff_spacing(int lp_buff_spacing) {
		this.lp_buff_spacing = lp_buff_spacing;
	}

	public int getLP_buff_column() {
		return lp_buff_column;
	}

	public void setLP_buff_column(int lp_buff_column) {
		this.lp_buff_column = lp_buff_column;
	}

	public int getRP_buff_size() {
		return rp_buff_size;
	}

	public void setRP_buff_size(int rp_buff_size) {
		this.rp_buff_size = rp_buff_size;
	}

	public int getRP_buff_spacing() {
		return rp_buff_spacing;
	}

	public void setRP_buff_spacing(int rp_buff_spacing) {
		this.rp_buff_spacing = rp_buff_spacing;
	}

	public int getRP_buff_column() {
		return rp_buff_column;
	}

	public void setRP_buff_column(int rp_buff_column) {
		this.rp_buff_column = rp_buff_column;
	}

	public int getRP_buff_filter() {
		return rp_buff_filter;
	}

	public void setRP_buff_filter(int rp_buff_filter) {
		this.rp_buff_filter = rp_buff_filter;
	}

	public int getSoulshard_x() {
		return soulshard_x;
	}

	public void setSoulshard_x(int soulshard_x) {
		this.soulshard_x = soulshard_x;
	}

	public int getSoulshard_y() {
		return soulshard_y;
	}

	public void setSoulshard_y(int soulshard_y) {
		this.soulshard_y = soulshard_y;
	}

	public int getFloatingPortrait_buff_filter() {
		return floatingPortrait_buff_filter;
	}

	public void setFloatingPortrait_buff_filter(int floatingPortrait_buff_filter) {
		this.floatingPortrait_buff_filter = floatingPortrait_buff_filter;
	}

	public int getFloatingPortrait_buff_size() {
		return floatingPortrait_buff_size;
	}

	public void setFloatingPortrait_buff_size(int floatingPortrait_buff_size) {
		this.floatingPortrait_buff_size = floatingPortrait_buff_size;
	}

	public int getFloatingPortrait_buff_spacing() {
		return floatingPortrait_buff_spacing;
	}

	public void setFloatingPortrait_buff_spacing(int floatingPortrait_buff_spacing) {
		this.floatingPortrait_buff_spacing = floatingPortrait_buff_spacing;
	}

	public int getFloatingPortrait_buff_column() {
		return floatingPortrait_buff_column;
	}

	public void setFloatingPortrait_buff_column(int floatingPortrait_buff_column) {
		this.floatingPortrait_buff_column = floatingPortrait_buff_column;
	}

	public int getFloatingPortrait_style() {
		return floatingPortrait_style;
	}

	public void setFloatingPortrait_style(int floatingPortrait_style) {
		this.floatingPortrait_style = floatingPortrait_style;
	}

	public int getFloatingPortrait_hp_color() {
		return floatingPortrait_hp_color;
	}

	public void setFloatingPortrait_hp_color(int floatingPortrait_hp_color) {
		this.floatingPortrait_hp_color = floatingPortrait_hp_color;
	}

	public int getFloatingPortrait_hp_thickness() {
		return floatingPortrait_hp_thickness;
	}

	public void setFloatingPortrait_hp_thickness(int floatingPortrait_hp_thickness) {
		this.floatingPortrait_hp_thickness = floatingPortrait_hp_thickness;
	}

	public int getMiniSlot_count() {
		return miniSlot_count;
	}

	public void setMiniSlot_count(int miniSlot_count) {
		this.miniSlot_count = miniSlot_count;
	}

	public int getMiniSlot_spacing() {
		return miniSlot_spacing;
	}

	public void setMiniSlot_spacing(int miniSlot_spacing) {
		this.miniSlot_spacing = miniSlot_spacing;
	}

	public int getMiniSlot_margin() {
		return miniSlot_margin;
	}

	public void setMiniSlot_margin(int miniSlot_margin) {
		this.miniSlot_margin = miniSlot_margin;
	}

	public int getMiniSlot_size() {
		return miniSlot_size;
	}

	public void setMiniSlot_size(int miniSlot_size) {
		this.miniSlot_size = miniSlot_size;
	}

	public int getMiniSlot_pos_x() {
		return miniSlot_pos_x;
	}

	public void setMiniSlot_pos_x(int miniSlot_pos_x) {
		this.miniSlot_pos_x = miniSlot_pos_x;
	}

	public int getMiniSlot_pos_y() {
		return miniSlot_pos_y;
	}

	public void setMiniSlot_pos_y(int miniSlot_pos_y) {
		this.miniSlot_pos_y = miniSlot_pos_y;
	}

	public int getShowMiniMap() {
		return showMiniMap;
	}

	public void setShowMiniMap(int showMiniMap) {
		this.showMiniMap = showMiniMap;
	}

	public int getIsSimpleMap() {
		return isSimpleMap;
	}

	public void setIsSimpleMap(int isSimpleMap) {
		this.isSimpleMap = isSimpleMap;
	}

	public int getIsCSIHorizontal() {
		return isCSIHorizontal;
	}

	public void setIsCSIHorizontal(int isCSIHorizontal) {
		this.isCSIHorizontal = isCSIHorizontal;
	}

	public int getCastBar_style() {
		return castBar_style;
	}

	public void setCastBar_style(int castBar_style) {
		this.castBar_style = castBar_style;
	}

	public int getCastBar_text_location() {
		return castBar_text_location;
	}

	public void setCastBar_text_location(int castBar_text_location) {
		this.castBar_text_location = castBar_text_location;
	}

	public int getCastBar_color() {
		return castBar_color;
	}

	public void setCastBar_color(int castBar_color) {
		this.castBar_color = castBar_color;
	}
	
	public int getCastBar_thickness() {
		return castBar_thickness;
	}

	public void setCastBar_thickness(int castBar_thickness) {
		this.castBar_thickness = castBar_thickness;
	}

	public int getInventory_layout() {
		return inventory_layout;
	}

	public void setInventory_layout(int inventory_layout) {
		this.inventory_layout = inventory_layout;
	}

	public int getInventory_row() {
		return inventory_row;
	}

	public void setInventory_row(int inventory_row) {
		this.inventory_row = inventory_row;
	}

	public int getInventory_column() {
		return inventory_column;
	}

	public void setInventory_column(int inventory_column) {
		this.inventory_column = inventory_column;
	}

	public int getTrader_layout() {
		return trader_layout;
	}

	public void setTrader_layout(int trader_layout) {
		this.trader_layout = trader_layout;
	}

	public int getTrader_row() {
		return trader_row;
	}

	public void setTrader_row(int trader_row) {
		this.trader_row = trader_row;
	}

	public int getTrader_column() {
		return trader_column;
	}

	public void setTrader_column(int trader_column) {
		this.trader_column = trader_column;
	}

	public int getFontSize() {
		return fontSize;
	}

	public void setFontSize(int fontSize) {
		this.fontSize = fontSize;
	}

	public int getCDFontSize() {
		return cdFontSize;
	}

	public void setCDFontSize(int cdFontSize) {
		this.cdFontSize = cdFontSize;
	}

	public int getHPLabelBrightness() {
		return hpLabelBrightness;
	}

	public void setHPLabelBrightness(int hpLabelBrightness) {
		this.hpLabelBrightness = hpLabelBrightness;
	}

	public int getBuffTextBrightness() {
		return buffTextBrightness;
	}

	public void setBuffTextBrightness(int buffTextBrightness) {
		this.buffTextBrightness = buffTextBrightness;
	}

	public int getTop_buff_size() {
		return top_buff_size;
	}

	public void setTop_buff_size(int top_buff_size) {
		this.top_buff_size = top_buff_size;
	}

	public int getTop_buff_spacing() {
		return top_buff_spacing;
	}

	public void setTop_buff_spacing(int top_buff_spacing) {
		this.top_buff_spacing = top_buff_spacing;
	}

	public int getTop_buff_column() {
		return top_buff_column;
	}

	public void setTop_buff_column(int top_buff_column) {
		this.top_buff_column = top_buff_column;
	}

	public int getPetListSize() {
		return petListSize;
	}

	public void setPetListSize(int petListSize) {
		this.petListSize = petListSize;
	}

	public int getGroupHPColor() {
		return groupHPColor;
	}

	public void setGroupHPColor(int groupHPColor) {
		this.groupHPColor = groupHPColor;
	}

	public int getRaidHPColor() {
		return raidHPColor;
	}

	public void setRaidHPColor(int raidHPColor) {
		this.raidHPColor = raidHPColor;
	}

	public int getOverheadHPSize() {
		return overheadHPSize;
	}

	public void setOverheadHPSize(int overheadHPSize) {
		this.overheadHPSize = overheadHPSize;
	}

	public int getOverheadHPColor() {
		return overheadHPColor;
	}

	public void setOverheadHPColor(int overheadHPColor) {
		this.overheadHPColor = overheadHPColor;
	}

	public int getOverheadFontSize() {
		return overheadFontSize;
	}

	public void setOverheadFontSize(int overheadFontSize) {
		this.overheadFontSize = overheadFontSize;
	}

	public double getNameplate_alpha() {
		return nameplate_alpha;
	}

	public void setNameplate_alpha(double nameplate_alpha) {
		this.nameplate_alpha = nameplate_alpha;
	}

	public double getFloatingPortrait_bar_alpha() {
		return floatingPortrait_bar_alpha;
	}

	public void setFloatingPortrait_bar_alpha(double floatingPortrait_bar_alpha) {
		this.floatingPortrait_bar_alpha = floatingPortrait_bar_alpha;
	}

	public double getCastBar_alpha() {
		return castBar_alpha;
	}

	public void setCastBar_alpha(double castBar_alpha) {
		this.castBar_alpha = castBar_alpha;
	}

	public double getPetListAlpha() {
		return petListAlpha;
	}

	public void setPetListAlpha(double petListAlpha) {
		this.petListAlpha = petListAlpha;
	}

	public double getOverheadHPAlpha() {
		return overheadHPAlpha;
	}

	public void setOverheadHPAlpha(double overheadHPAlpha) {
		this.overheadHPAlpha = overheadHPAlpha;
	}

	public boolean isHideEmptySlots() {
		return isHideEmptySlots;
	}

	public void setHideEmptySlots(boolean hideEmptySlots) {
		isHideEmptySlots = hideEmptySlots;
	}

	public boolean isFloatingPortrait_show_mana() {
		return floatingPortrait_show_mana;
	}

	public void setFloatingPortrait_show_mana(boolean floatingPortrait_show_mana) {
		this.floatingPortrait_show_mana = floatingPortrait_show_mana;
	}

	public boolean isMiniSlotHide() {
		return isMiniSlotHide;
	}

	public void setMiniSlotHide(boolean miniSlotHide) {
		isMiniSlotHide = miniSlotHide;
	}

	public boolean isSlotHideForOptionOnly() {
		return isSlotHideForOptionOnly;
	}

	public void setSlotHideForOptionOnly(boolean slotHideForOptionOnly) {
		isSlotHideForOptionOnly = slotHideForOptionOnly;
	}

	public boolean isHPLabelBold() {
		return isHPLabelBold;
	}

	public void setHPLabelBold(boolean HPLabelBold) {
		isHPLabelBold = HPLabelBold;
	}

	public boolean isPetListSizeLimit() {
		return isPetListSizeLimit;
	}

	public void setPetListSizeLimit(boolean petListSizeLimit) {
		isPetListSizeLimit = petListSizeLimit;
	}

	public String getCDFontWeight() {
		return cdFontWeight;
	}

	public void setCDFontWeight(String cdFontWeight) {
		this.cdFontWeight = cdFontWeight;
	}

	public String getOverheadFontWeight() {
		return overheadFontWeight;
	}

	public void setOverheadFontWeight(String overheadFontWeight) {
		this.overheadFontWeight = overheadFontWeight;
	}
}
