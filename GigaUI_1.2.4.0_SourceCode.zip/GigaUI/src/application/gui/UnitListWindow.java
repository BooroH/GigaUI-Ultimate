package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UnitListWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider groupHpColorSlider;
	private Label groupHoColorLabel;

	private Slider raidHpColorSlider;
	private Label raidHpColorLabel;

	private CheckBox petLimitCheckBox;

	private Slider petLimitSlider;
	private Label petLimitLabel;

	private Slider petAlphaSlider;
	private Label petAlphaLabel;

	private Button okButton;
	private Button backButton;

	public UnitListWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int grpColor = manager.getSettings().getGroupHPColor();
		int raidColor = manager.getSettings().getRaidHPColor();
		boolean petLimit = manager.getSettings().isPetListSizeLimit();
		int petMaxHeight = manager.getSettings().getPetListSize();
		int petAlpha = (int) (manager.getSettings().getPetListAlpha() * 100);

		groupHpColorSlider = createSlider(1, 14, grpColor, 1, 300);
		groupHoColorLabel = new Label("");

		raidHpColorSlider = createSlider(1, 14, raidColor, 1, 300);
		raidHpColorLabel = new Label("");

		petLimitCheckBox = new CheckBox("");

		petLimitSlider = createSlider(200, 330, petMaxHeight, 1, 300);
		petLimitLabel = new Label(String.valueOf(petMaxHeight));

		petAlphaSlider = createSlider(80, 100, petAlpha, 1, 300);
		petAlphaLabel = new Label(String.valueOf(petAlpha));

		if (grpColor == 1)
			groupHoColorLabel.setText("Red");
		else if (grpColor == 2)
			groupHoColorLabel.setText("Aqua");
		else if (grpColor == 3)
			groupHoColorLabel.setText("Blue");
		else if (grpColor == 4)
			groupHoColorLabel.setText("Grass");
		else if (grpColor == 5)
			groupHoColorLabel.setText("Green");
		else if (grpColor == 6)
			groupHoColorLabel.setText("Lemon");
		else if (grpColor == 7)
			groupHoColorLabel.setText("Orange");
		else if (grpColor == 8)
			groupHoColorLabel.setText("Peach");
		else if (grpColor == 9)
			groupHoColorLabel.setText("Pink");
		else if (grpColor == 10)
			groupHoColorLabel.setText("Purple");
		else if (grpColor == 11)
			groupHoColorLabel.setText("Sky");
		else if (grpColor == 12)
			groupHoColorLabel.setText("Vanilla");
		else if (grpColor == 13)
			groupHoColorLabel.setText("White");
		else if (grpColor == 14)
			groupHoColorLabel.setText("Wine");

		if (raidColor == 1)
			raidHpColorLabel.setText("Red");
		else if (raidColor == 2)
			raidHpColorLabel.setText("Aqua");
		else if (raidColor == 3)
			raidHpColorLabel.setText("Blue");
		else if (raidColor == 4)
			raidHpColorLabel.setText("Grass");
		else if (raidColor == 5)
			raidHpColorLabel.setText("Green");
		else if (raidColor == 6)
			raidHpColorLabel.setText("Lemon");
		else if (raidColor == 7)
			raidHpColorLabel.setText("Orange");
		else if (raidColor == 8)
			raidHpColorLabel.setText("Peach");
		else if (raidColor == 9)
			raidHpColorLabel.setText("Pink");
		else if (raidColor == 10)
			raidHpColorLabel.setText("Purple");
		else if (raidColor == 11)
			raidHpColorLabel.setText("Sky");
		else if (raidColor == 12)
			raidHpColorLabel.setText("Vanilla");
		else if (raidColor == 13)
			raidHpColorLabel.setText("White");
		else if (raidColor == 14)
			raidHpColorLabel.setText("Wine");

		petLimitCheckBox.setSelected(petLimit);
		if (!petLimit) {
			petLimitSlider.setDisable(true);
			petLimitLabel.setText("");
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox groupHpColorBox = new HBox(10, new Label("Group HP Color"), groupHpColorSlider, groupHoColorLabel);
		HBox raidHpColorBox = new HBox(10, new Label("Raid HP Color"), raidHpColorSlider, raidHpColorLabel);
		HBox limitBox = new HBox(10, new Label("Limit Height"), petLimitCheckBox);
		HBox petLimitBox = new HBox(10, new Label("Maximum Height"), petLimitSlider, petLimitLabel);
		HBox petAlphaBox = new HBox(10, new Label("Alpha"), petAlphaSlider, petAlphaLabel);

		Label petLabel = new Label("PET");
		VBox.setMargin(petLabel, new Insets(20, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(new Label("GROUP/RAID"), groupHpColorBox, raidHpColorBox, petLabel, limitBox,
				petLimitBox, petAlphaBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		groupHpColorSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			groupHpColorSlider.setValue(newVal.intValue());
			
			if (newVal.intValue() == 1)
				groupHoColorLabel.setText("Red");
			else if (newVal.intValue() == 2)
				groupHoColorLabel.setText("Aqua");
			else if (newVal.intValue() == 3)
				groupHoColorLabel.setText("Blue");
			else if (newVal.intValue() == 4)
				groupHoColorLabel.setText("Grass");
			else if (newVal.intValue() == 5)
				groupHoColorLabel.setText("Green");
			else if (newVal.intValue() == 6)
				groupHoColorLabel.setText("Lemon");
			else if (newVal.intValue() == 7)
				groupHoColorLabel.setText("Orange");
			else if (newVal.intValue() == 8)
				groupHoColorLabel.setText("Peach");
			else if (newVal.intValue() == 9)
				groupHoColorLabel.setText("Pink");
			else if (newVal.intValue() == 10)
				groupHoColorLabel.setText("Purple");
			else if (newVal.intValue() == 11)
				groupHoColorLabel.setText("Sky");
			else if (newVal.intValue() == 12)
				groupHoColorLabel.setText("Vanilla");
			else if (newVal.intValue() == 13)
				groupHoColorLabel.setText("White");
			else if (newVal.intValue() == 14)
				groupHoColorLabel.setText("Wine");
			
		});

		raidHpColorSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			raidHpColorSlider.setValue(newVal.intValue());
			
			if (newVal.intValue() == 1)
				raidHpColorLabel.setText("Red");
			else if (newVal.intValue() == 2)
				raidHpColorLabel.setText("Aqua");
			else if (newVal.intValue() == 3)
				raidHpColorLabel.setText("Blue");
			else if (newVal.intValue() == 4)
				raidHpColorLabel.setText("Grass");
			else if (newVal.intValue() == 5)
				raidHpColorLabel.setText("Green");
			else if (newVal.intValue() == 6)
				raidHpColorLabel.setText("Lemon");
			else if (newVal.intValue() == 7)
				raidHpColorLabel.setText("Orange");
			else if (newVal.intValue() == 8)
				raidHpColorLabel.setText("Peach");
			else if (newVal.intValue() == 9)
				raidHpColorLabel.setText("Pink");
			else if (newVal.intValue() == 10)
				raidHpColorLabel.setText("Purple");
			else if (newVal.intValue() == 11)
				raidHpColorLabel.setText("Sky");
			else if (newVal.intValue() == 12)
				raidHpColorLabel.setText("Vanilla");
			else if (newVal.intValue() == 13)
				raidHpColorLabel.setText("White");
			else if (newVal.intValue() == 14)
				raidHpColorLabel.setText("Wine");
			
		});

		petLimitCheckBox.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
			petLimitSlider.setDisable(!isSelected);
			if (isSelected) {
				petLimitLabel.setText(String.valueOf((int) petLimitSlider.getValue()));
			} else {
				petLimitLabel.setText("");
			}
		});
		petLimitSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			petLimitSlider.setValue(newVal.intValue());
			petLimitLabel.setText(String.valueOf(newVal.intValue()));
		});
		petAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			petAlphaSlider.setValue(newVal.intValue());
			petAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setGroupHPColor((int) groupHpColorSlider.getValue());
			manager.getSettings().setRaidHPColor((int) raidHpColorSlider.getValue());
			manager.getSettings().setPetListSizeLimit(petLimitCheckBox.isSelected());
			manager.getSettings().setPetListSize((int) petLimitSlider.getValue());
			manager.getSettings().setPetListAlpha(petAlphaSlider.getValue() / 100);
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Group, Raid, Pet List";
	}

}