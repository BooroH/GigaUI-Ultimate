package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FloatingPortraitWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider styleSlider;
	private Label styleLabel;
	private Slider nameBgAlphaSlider;
	private Label nameBgAlphaLabel;
	private Slider buffSizeSlider;
	private Label buffSizeLabel;
	private Slider buffGapSlider;
	private Label buffGapLabel;
	private Slider buffColSlider;
	private Label buffColLabel;
	private Slider barAlphaSlider;
	private Label barAlphaLabel;
	private Slider hpColorSlider;
	private Label hpColorLabel;
	private Slider hpHeightSlider;
	private Label hpHeightLabel;

	private Button okButton;
	private Button backButton;

	CheckBox showManaCheckBox;
	CheckBox showDebuffCheckBox;

	public FloatingPortraitWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int style = manager.getSettings().getFloatingPortrait_style();
		int hpColor = manager.getSettings().getFloatingPortrait_hp_color();
		int hpHeight = manager.getSettings().getFloatingPortrait_hp_thickness();
		int alpha = (int) (manager.getSettings().getFloatingPortrait_bar_alpha() * 100);
		int nameBgAlpha = (int) (manager.getSettings().getNameplate_alpha() * 100);
		boolean showMana = manager.getSettings().isFloatingPortrait_show_mana();

		int debuffFilter = manager.getSettings().getFloatingPortrait_buff_filter();
		int debuffSize = manager.getSettings().getFloatingPortrait_buff_size();
		int debuffGap = manager.getSettings().getFloatingPortrait_buff_spacing();
		int debuffCol = manager.getSettings().getFloatingPortrait_buff_column();

		styleSlider = createSlider(1, 2, style, 1, 100);
		styleLabel = new Label("Style " + String.valueOf(style));

		hpColorSlider = createSlider(1, 15, hpColor, 1, 200);
		hpColorLabel = new Label("");

		hpHeightSlider = createSlider(19, 33, hpHeight, 1, 200);
		hpHeightLabel = new Label(String.valueOf(hpHeight));

		barAlphaSlider = createSlider(80, 100, alpha, 1, 300);
		barAlphaLabel = new Label(String.valueOf(alpha));

		nameBgAlphaSlider = createSlider(0, 100, nameBgAlpha, 1, 300);
		nameBgAlphaLabel = new Label(String.valueOf(nameBgAlpha));

		showManaCheckBox = new CheckBox("");
		showDebuffCheckBox = new CheckBox("");

		buffSizeSlider = createSlider(20, 49, debuffSize, 1, 300);
		buffSizeLabel = new Label(String.valueOf(debuffSize));

		buffGapSlider = createSlider(0, 5, debuffGap, 1, 200);
		buffGapLabel = new Label(String.valueOf(debuffGap));

		buffColSlider = createSlider(5, 20, debuffCol, 1, 300);
		buffColLabel = new Label(String.valueOf(debuffCol));

		showManaCheckBox.setSelected(showMana);

		if (style == 1) {
			showManaCheckBox.setDisable(true);
			showManaCheckBox.setSelected(false);
		} else {
			hpColorSlider.setDisable(true);
			hpHeightSlider.setDisable(true);
			hpColorLabel.setText("");
			hpHeightLabel.setText("");
		}

		if (hpColor == 1)
			hpColorLabel.setText("Red");
		else if (hpColor == 2)
			hpColorLabel.setText("Aqua");
		else if (hpColor == 3)
			hpColorLabel.setText("Blue");
		else if (hpColor == 4)
			hpColorLabel.setText("Grass");
		else if (hpColor == 5)
			hpColorLabel.setText("Green");
		else if (hpColor == 6)
			hpColorLabel.setText("Lemon");
		else if (hpColor == 7)
			hpColorLabel.setText("Orange");
		else if (hpColor == 8)
			hpColorLabel.setText("Peach");
		else if (hpColor == 9)
			hpColorLabel.setText("Pink");
		else if (hpColor == 10)
			hpColorLabel.setText("Purple");
		else if (hpColor == 11)
			hpColorLabel.setText("Sky");
		else if (hpColor == 12)
			hpColorLabel.setText("Vanilla");
		else if (hpColor == 13)
			hpColorLabel.setText("White");
		else if (hpColor == 14)
			hpColorLabel.setText("Wine");
		else if (hpColor == 15)
			hpColorLabel.setText("Yellow");

		if (debuffFilter == 0) {
			showDebuffCheckBox.setSelected(false);
			buffSizeSlider.setDisable(true);
			buffSizeLabel.setText("");
			buffGapSlider.setDisable(true);
			buffGapLabel.setText("");
			buffColSlider.setDisable(true);
			buffColLabel.setText("");
		} else {
			showDebuffCheckBox.setSelected(true);
			buffColSlider.setDisable(false);
			buffColLabel.setText(String.valueOf(debuffCol));
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox styleBox = new HBox(10, new Label("Style"), styleSlider, styleLabel);
		HBox nameBgAlphaBox = new HBox(10, new Label("Name Background Alpha"), nameBgAlphaSlider, nameBgAlphaLabel);
		HBox buffSizeBox = new HBox(10, new Label("Size"), buffSizeSlider, buffSizeLabel);
		HBox buffGapBox = new HBox(10, new Label("Gap"), buffGapSlider, buffGapLabel);
		HBox buffColBox = new HBox(10, new Label("Column"), buffColSlider, buffColLabel);
		HBox barAlphaBox = new HBox(10, new Label("Alpha"), barAlphaSlider, barAlphaLabel);
		HBox hpColorBox = new HBox(10, new Label("Color"), hpColorSlider, hpColorLabel);
		HBox hpHeightBox = new HBox(10, new Label("Thickness"), hpHeightSlider, hpHeightLabel);
		HBox showManaBox = new HBox(10, new Label("Show Mana/Stam"), showManaCheckBox);
		HBox showDebuffBox = new HBox(10, new Label("Show Debuff"), showDebuffCheckBox);

		Label barLabel = new Label("STATUS BAR");
		Label debuffLabel = new Label("DEBUFF");
		VBox.setMargin(debuffLabel, new Insets(20, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(barLabel, styleBox, hpColorBox, hpHeightBox, barAlphaBox, nameBgAlphaBox,
				showManaBox, debuffLabel, showDebuffBox, buffSizeBox, buffGapBox, buffColBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		styleSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			styleSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1) {
				showManaCheckBox.setDisable(true);
				showManaCheckBox.setSelected(false);
				hpColorSlider.setDisable(false);
				hpHeightSlider.setDisable(false);
				hpHeightLabel.setText(String.valueOf((int) hpHeightSlider.getValue()));
				
				if (((int) hpColorSlider.getValue()) == 1)
					hpColorLabel.setText("Red");
				else if (((int) hpColorSlider.getValue()) == 2)
					hpColorLabel.setText("Aqua");
				else if (((int) hpColorSlider.getValue()) == 3)
					hpColorLabel.setText("Blue");
				else if (((int) hpColorSlider.getValue()) == 4)
					hpColorLabel.setText("Grass");
				else if (((int) hpColorSlider.getValue()) == 5)
					hpColorLabel.setText("Green");
				else if (((int) hpColorSlider.getValue()) == 6)
					hpColorLabel.setText("Lemon");
				else if (((int) hpColorSlider.getValue()) == 7)
					hpColorLabel.setText("Orange");
				else if (((int) hpColorSlider.getValue()) == 8)
					hpColorLabel.setText("Peach");
				else if (((int) hpColorSlider.getValue()) == 9)
					hpColorLabel.setText("Pink");
				else if (((int) hpColorSlider.getValue()) == 10)
					hpColorLabel.setText("Purple");
				else if (((int) hpColorSlider.getValue()) == 11)
					hpColorLabel.setText("Sky");
				else if (((int) hpColorSlider.getValue()) == 12)
					hpColorLabel.setText("Vanilla");
				else if (((int) hpColorSlider.getValue()) == 13)
					hpColorLabel.setText("White");
				else if (((int) hpColorSlider.getValue()) == 14)
					hpColorLabel.setText("Wine");
				else if (((int) hpColorSlider.getValue()) == 15)
					hpColorLabel.setText("Yellow");
				
			} else {
				showManaCheckBox.setDisable(false);
				hpColorSlider.setDisable(true);
				hpHeightSlider.setDisable(true);
				hpColorLabel.setText("");
				hpHeightLabel.setText("");
			}
			styleLabel.setText("Style " + String.valueOf(newVal.intValue()));
		});

		hpColorSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			hpColorSlider.setValue(newVal.intValue());
			
			if (newVal.intValue() == 1)
				hpColorLabel.setText("Red");
			else if (newVal.intValue() == 2)
				hpColorLabel.setText("Aqua");
			else if (newVal.intValue() == 3)
				hpColorLabel.setText("Blue");
			else if (newVal.intValue() == 4)
				hpColorLabel.setText("Grass");
			else if (newVal.intValue() == 5)
				hpColorLabel.setText("Green");
			else if (newVal.intValue() == 6)
				hpColorLabel.setText("Lemon");
			else if (newVal.intValue() == 7)
				hpColorLabel.setText("Orange");
			else if (newVal.intValue() == 8)
				hpColorLabel.setText("Peach");
			else if (newVal.intValue() == 9)
				hpColorLabel.setText("Pink");
			else if (newVal.intValue() == 10)
				hpColorLabel.setText("Purple");
			else if (newVal.intValue() == 11)
				hpColorLabel.setText("Sky");
			else if (newVal.intValue() == 12)
				hpColorLabel.setText("Vanilla");
			else if (newVal.intValue() == 13)
				hpColorLabel.setText("White");
			else if (newVal.intValue() == 14)
				hpColorLabel.setText("Wine");
			else if (newVal.intValue() == 15)
				hpColorLabel.setText("Yellow");

		});

		hpHeightSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			hpHeightSlider.setValue(newVal.intValue());
			hpHeightLabel.setText(String.valueOf(newVal.intValue()));
		});

		barAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			barAlphaSlider.setValue(newVal.intValue());
			barAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});

		nameBgAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			nameBgAlphaSlider.setValue(newVal.intValue());
			nameBgAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});

		showDebuffCheckBox.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
			if (!isSelected) {
				buffSizeSlider.setDisable(true);
				buffSizeLabel.setText("");
				buffGapSlider.setDisable(true);
				buffGapLabel.setText("");
				buffColSlider.setDisable(true);
				buffColLabel.setText("");
			} else {
				buffSizeSlider.setDisable(false);
				buffSizeLabel.setText(String.valueOf((int) buffSizeSlider.getValue()));
				buffGapSlider.setDisable(false);
				buffGapLabel.setText(String.valueOf((int) buffGapSlider.getValue()));
				buffColSlider.setDisable(false);
				buffColLabel.setText(String.valueOf((int) buffColSlider.getValue()));
			}
		});

		buffSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			buffSizeSlider.setValue(newVal.intValue());
			buffSizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		buffGapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			buffGapSlider.setValue(newVal.intValue());
			buffGapLabel.setText(String.valueOf(newVal.intValue()));
		});
		buffColSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			buffColSlider.setValue(newVal.intValue());
			buffColLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setFloatingPortrait_style((int) styleSlider.getValue());
			manager.getSettings().setFloatingPortrait_hp_color((int) hpColorSlider.getValue());
			manager.getSettings().setFloatingPortrait_hp_thickness((int) hpHeightSlider.getValue());
			manager.getSettings().setFloatingPortrait_bar_alpha(barAlphaSlider.getValue() / 100);
			manager.getSettings().setNameplate_alpha(nameBgAlphaSlider.getValue() / 100);
			manager.getSettings().setFloatingPortrait_show_mana(showManaCheckBox.isSelected());
			if (showDebuffCheckBox.isSelected()) {
				manager.getSettings().setFloatingPortrait_buff_filter(1);
			} else {
				manager.getSettings().setFloatingPortrait_buff_filter(0);
			}
			manager.getSettings().setFloatingPortrait_buff_size((int) buffSizeSlider.getValue());
			manager.getSettings().setFloatingPortrait_buff_spacing((int) buffGapSlider.getValue());
			manager.getSettings().setFloatingPortrait_buff_column((int) buffColSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() {
		return 620;
	}

	@Override
	protected double getHeight() {
		return 550;
	}

	@Override
	protected String getTitle() {
		return "Floating Portrait";
	}

}
