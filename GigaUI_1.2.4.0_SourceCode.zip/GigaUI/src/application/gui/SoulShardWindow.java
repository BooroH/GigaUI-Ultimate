package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SoulShardWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider moveXSlider;
	private Label moveXLabel;
	
	private Slider moveYSlider;
	private Label moveYLabel;

	private Button okButton;
	private Button backButton;

	public SoulShardWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}
	
	@Override
	protected void initComponents() {
		int x = manager.getSettings().getSoulshard_x();
		int y = manager.getSettings().getSoulshard_y();
		
		moveXSlider = createSlider(-900, 900, x, 1, 400);
		moveXLabel = new Label(String.valueOf(x));
		
		moveYSlider = createSlider(0, 800, y, 1, 400);
		moveYLabel = new Label(String.valueOf(y));

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox moveXBox = new HBox(10, new Label("Move X"), moveXSlider, moveXLabel);
		HBox moveYBox = new HBox(10, new Label("Move Y"), moveYSlider, moveYLabel);
		
		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(moveXBox, moveYBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		moveXSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveXSlider.setValue(newVal.intValue());
			moveXLabel.setText(String.valueOf(newVal.intValue()));
		});
		moveYSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveYSlider.setValue(newVal.intValue());
			moveYLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setSoulshard_x((int)moveXSlider.getValue());
			manager.getSettings().setSoulshard_y((int)moveYSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() { return 600; }  
	@Override
    protected double getHeight() { return 200; }  
	@Override
	protected String getTitle() {
		return "Assassin Soulshard";
	}

}