package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class TeamListBigEntryView {

	public static void readTeamListBigEntryView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListBigEntryView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		// 그룹체력색 추출
		if (content.contains("_red"))
			settings.setGroupHPColor(1);
		else if (content.contains("_auqa"))
			settings.setGroupHPColor(2);
		else if (content.contains("_blue"))
			settings.setGroupHPColor(3);
		else if (content.contains("_grass"))
			settings.setGroupHPColor(4);
		else if (content.contains("_green"))
			settings.setGroupHPColor(5);
		else if (content.contains("_lemon"))
			settings.setGroupHPColor(6);
		else if (content.contains("_orange"))
			settings.setGroupHPColor(7);
		else if (content.contains("_peach"))
			settings.setGroupHPColor(8);
		else if (content.contains("_pink"))
			settings.setGroupHPColor(9);
		else if (content.contains("_purple"))
			settings.setGroupHPColor(10);
		else if (content.contains("_sky"))
			settings.setGroupHPColor(11);
		else if (content.contains("_vanilla"))
			settings.setGroupHPColor(12);
		else if (content.contains("_white"))
			settings.setGroupHPColor(13);
		else if (content.contains("_wine"))
			settings.setGroupHPColor(14);

	}

	public static void writeTeamListBigEntryView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListBigEntryView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");
			// 체력 오프셋
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,1)\"");
		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_name_margin_y1", "-1");
			content = content.replaceAll("var_name_margin_y2", "0");
			// 체력 오프셋
			content = content.replaceAll("var_label_offset", "");
		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");
			// 체력 오프셋
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,1)\"");
		}

		// 체력바 폰트 볼드
		if (settings.isHPLabelBold()) {
			content = content.replaceAll("var_label_font", "label_font=\"NORMAL_BOLD\"");
		} else {
			content = content.replaceAll("var_label_font", "");
		}

		// HP 라벨 컬러(밝기)
		content = content.replaceAll("var_label_color", HexConverter.intToHex(settings.getHPLabelBrightness()));

		// 체력바색
		String group_hp_color = "";

		if (settings.getGroupHPColor() == 1)
			group_hp_color = "_red";
		else if (settings.getGroupHPColor() == 2)
			group_hp_color = "_aqua";
		else if (settings.getGroupHPColor() == 3)
			group_hp_color = "_blue";
		else if (settings.getGroupHPColor() == 4)
			group_hp_color = "_grass";
		else if (settings.getGroupHPColor() == 5)
			group_hp_color = "_green";
		else if (settings.getGroupHPColor() == 6)
			group_hp_color = "_lemon";
		else if (settings.getGroupHPColor() == 7)
			group_hp_color = "_orange";
		else if (settings.getGroupHPColor() == 8)
			group_hp_color = "_peach";
		else if (settings.getGroupHPColor() == 9)
			group_hp_color = "_pink";
		else if (settings.getGroupHPColor() == 10)
			group_hp_color = "_purple";
		else if (settings.getGroupHPColor() == 11)
			group_hp_color = "_sky";
		else if (settings.getGroupHPColor() == 12)
			group_hp_color = "_vanilla";
		else if (settings.getGroupHPColor() == 13)
			group_hp_color = "_white";
		else if (settings.getGroupHPColor() == 14)
			group_hp_color = "_wine";

		content = content.replaceAll("var_hp_color", group_hp_color);

		FileManager.stringToFile(targetDir, content);

	}
}
