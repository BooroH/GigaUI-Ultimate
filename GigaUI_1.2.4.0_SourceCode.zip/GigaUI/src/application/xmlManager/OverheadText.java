package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;

public class OverheadText {

	public static void readOverheadText(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/OverheadText.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		// 오버헤드체력색 추출
		if (content.contains("fg_red"))
			settings.setOverheadHPColor(1);
		else if (content.contains("_auqa"))
			settings.setOverheadHPColor(2);
		else if (content.contains("_blue"))
			settings.setOverheadHPColor(3);
		else if (content.contains("_grass"))
			settings.setOverheadHPColor(4);
		else if (content.contains("_green"))
			settings.setOverheadHPColor(5);
		else if (content.contains("_lemon"))
			settings.setOverheadHPColor(16);
		else if (content.contains("_orange"))
			settings.setOverheadHPColor(7);
		else if (content.contains("_peach"))
			settings.setOverheadHPColor(8);
		else if (content.contains("_pink"))
			settings.setOverheadHPColor(9);
		else if (content.contains("_purple"))
			settings.setOverheadHPColor(10);
		else if (content.contains("_sky"))
			settings.setOverheadHPColor(11);
		else if (content.contains("_vanilla"))
			settings.setOverheadHPColor(12);
		else if (content.contains("_white"))
			settings.setOverheadHPColor(13);
		else if (content.contains("_wine"))
			settings.setOverheadHPColor(14);

		// 오버헤드알파값추출
		settings.setOverheadHPAlpha(1.0);
		p = Pattern.compile("view_alpha\\s*=\\s*\"([0-9.]+)\"");
		m = p.matcher(content);
		if (m.find()) {
			String alphaValue = m.group(1);
			double alpha = Double.parseDouble(alphaValue);
			settings.setOverheadHPAlpha(alpha);
		}

		// 오버헤드체력사이즈 추출
		if (content.contains("size2_"))
			settings.setOverheadHPSize(2);
		else
			settings.setOverheadHPSize(1);
	}

	public static void writeOverheadText(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/OverheadText.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String overhead_hp_color = "";

		if (settings.getOverheadHPColor() == 1)
			overhead_hp_color = "_red";
		else if (settings.getOverheadHPColor() == 2)
			overhead_hp_color = "_aqua";
		else if (settings.getOverheadHPColor() == 3)
			overhead_hp_color = "_blue";
		else if (settings.getOverheadHPColor() == 4)
			overhead_hp_color = "_grass";
		else if (settings.getOverheadHPColor() == 5)
			overhead_hp_color = "_green";
		else if (settings.getOverheadHPColor() == 6)
			overhead_hp_color = "_lemon";
		else if (settings.getOverheadHPColor() == 7)
			overhead_hp_color = "_orange";
		else if (settings.getOverheadHPColor() == 8)
			overhead_hp_color = "_peach";
		else if (settings.getOverheadHPColor() == 9)
			overhead_hp_color = "_pink";
		else if (settings.getOverheadHPColor() == 10)
			overhead_hp_color = "_purple";
		else if (settings.getOverheadHPColor() == 11)
			overhead_hp_color = "_sky";
		else if (settings.getOverheadHPColor() == 12)
			overhead_hp_color = "_vanilla";
		else if (settings.getOverheadHPColor() == 13)
			overhead_hp_color = "_white";
		else if (settings.getOverheadHPColor() == 14)
			overhead_hp_color = "_wine";

		content = content.replaceAll("var_hp_color", overhead_hp_color);

		if (settings.getOverheadHPAlpha() == 1.0) {
			content = content.replaceAll("var_hp_alpha", "");
		} else {
			content = content.replaceAll("var_hp_alpha",
					"view_alpha=\"" + String.valueOf(settings.getOverheadHPAlpha()) + "\"");
		}

		if (settings.getOverheadHPSize() == 1)
			content = content.replaceAll("var_hp_size", "");
		else if (settings.getOverheadHPSize() == 2)
			content = content.replaceAll("var_hp_size", "size2_");

		FileManager.stringToFile(targetDir, content);

	}
}
