package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;

public class HUDView {

	public static void readdHUDView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/HUDView.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		p = Pattern.compile("icon_size=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);

		if (m.find()) {
			int width = Integer.parseInt(m.group(1));
			int height = Integer.parseInt(m.group(2));

			settings.setTop_buff_size(width);
		}

		p = Pattern.compile("icon_spacing=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);

		if (m.find()) {
			int width = Integer.parseInt(m.group(1));
			int height = Integer.parseInt(m.group(2));

			settings.setTop_buff_spacing(width);
		}

		p = Pattern.compile("max_columns=\"(\\d+)\"");
		m = p.matcher(content);

		if (m.find()) {
			int maxColumns = Integer.parseInt(m.group(1));

			settings.setTop_buff_column(maxColumns);
		}

	}

	public static void writeHUDView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/HUDView.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String helpButton_margin = new String("");
		String miniMap_on = new String("");
		String miniMap_off = new String("");

		if (settings.getShowMiniMap() == 1) {
			miniMap_on = "<View name=\"RadarViewDock\" view_layout=\"vertical\" h_local_alignment=\"RIGHT\" layout_borders=\"Rect(0,23,0,0)\"/>";
			miniMap_off = "";
			helpButton_margin = "14";
		} else {
			miniMap_on = "";
			miniMap_off = "<View name=\"RadarViewDock\" view_layout=\"vertical\"/>";
			helpButton_margin = "17";
		}

		content = content.replaceAll("var_help_button_margin", helpButton_margin);
		content = content.replaceAll("var_minimap_off", miniMap_off);
		content = content.replaceAll("var_minimap_on", miniMap_on);

		// hud.xml 상단버프
		content = content.replaceAll("var_icon_size", String.valueOf(settings.getTop_buff_size()));
		content = content.replaceAll("var_icon_spacing", String.valueOf(settings.getTop_buff_spacing()));
		content = content.replaceAll("var_icon_column", String.valueOf(settings.getTop_buff_column()));

		FileManager.stringToFile(targetDir, content);

	}

}
