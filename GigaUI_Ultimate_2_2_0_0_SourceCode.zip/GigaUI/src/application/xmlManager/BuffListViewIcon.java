package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class BuffListViewIcon {

	public static void readBuffListViewIcon(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/BuffGUI/BuffListViewIcon.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		// 버프 텍스트 컬러 추출
		p = Pattern.compile("<TextView\\s+[^>]*name=\"StackSizeView\"[^>]*default_color=\"(#[0-9a-fA-F]{6})\"",
				Pattern.CASE_INSENSITIVE);
		m = p.matcher(content);

		if (m.find()) {
			String colorCode = m.group(1);
			settings.setBuffTextBrightness(HexConverter.hexToInt(colorCode));
		}

		// 체력바 폰트 볼드인지 확인
		if (content.contains("NORMAL_BOLD")) {
			settings.setBuffTimerBold(true);
		} else {
			settings.setBuffTimerBold(false);
		}
	}

	public static void writeBuffListViewIcon(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/BuffGUI/BuffListViewIcon.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 버프 텍스트 컬러(밝기)
		content = content.replaceAll("var_text_color", HexConverter.intToHex(settings.getBuffTextBrightness()));
		
		//버프타이머 폰트
		String font;
		if(settings.isBuffTimerBold()) {
			font = " font=\"NORMAL_BOLD\"";
		}
		else {
			font="";
		}
		
		content = content.replaceAll("var_stack_font", font);
		content = content.replaceAll("var_timer_font", font);

		FileManager.stringToFile(targetDir, content);

	}
}
