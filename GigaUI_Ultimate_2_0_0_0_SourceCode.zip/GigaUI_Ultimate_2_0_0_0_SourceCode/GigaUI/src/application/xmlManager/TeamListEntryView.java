package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class TeamListEntryView {

	public static void readTeamListEntryView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListEntryView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

	}

	public static void writeTeamListEntryView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListEntryView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			content = content.replaceAll("var_nameplate_magin_y2", "-1");
			content = content.replaceAll("var_name_margin_y1", "-1");
			content = content.replaceAll("var_name_margin_y2", "0");

		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_nameplate_magin_y2", "-2");
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");

		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_nameplate_magin_y2", "-2");
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");
		}

		FileManager.stringToFile(targetDir, content);

	}
}
