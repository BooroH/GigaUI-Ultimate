package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class FloatingShortcutBarV {
	public static void writeFloatingShortcutBarV(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/FloatingShortcutBarV.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String code = "";
		String chroma_code = "";

		// 컬러
		if (settings.getSlot_bg_lightness() == 0) {
			chroma_code = "";
		} else {
			chroma_code = "_c_0_0_" + String.valueOf((int) settings.getSlot_bg_lightness());
		}

		if (settings.getBottomBar_row() < 3 && settings.getBottomBar_column() < 21) {
			code = "<View view_layout=\"stacked\" view_flags=\"WID_HANDLE_MOUSE\">\r\n"
					+ "	<template:ShortcutView icon_spacing=\"-4\" out_of_range_bitmap=\"../../Customized/gfx/bottombar/outofrange.png\" slot_bg_gfx=\"../../Customized/gfx/bottombar/56"
					+ chroma_code + ".png\" slot_template=\"SlotTemplate\">\r\n" + "		<template:ItemSlotView\r\n"
					+ "			slot_size    = \"Point(55,55)\"\r\n" + "			icon_borders = \"Point(6,6)\"\r\n"
					+ "			template:name=\"SlotTemplate\"\r\n" + "		/>\r\n"
					+ "	</template:ShortcutView>	\r\n" + "\r\n"
					+ "	<View name=\"BgView\" view_layout=\"vertical\">\r\n"
					+ "		<BitmapView bitmap_gfx=\"bottombars/ASB/asb_top.tga\"/>\r\n"
					+ "		<BitmapView bitmap_gfx=\"\" max_size_extend=\"Point(0,COORD_MAX)\"/>\r\n"
					+ "		<BitmapView name=\"ResizeKnob\" bitmap_gfx=\"bottombars/ASB/asb_bottom.tga\" view_flags=\"WID_HANDLE_MOUSE\" />\r\n"
					+ "	</View>\r\n" + "	<ShortcutView name=\"ShortcutView\"\r\n"
					+ "		view_layout=\"vertical\"\r\n" + "		v_alignment=\"EXTEND\"\r\n"
					+ "		min_size_limit=\"Point(COORD_MAX,55)\"\r\n" + "		layout_borders=\"Rect(0,13,0,13)\"\r\n"
					+ "		view_flags = \"SBF_VERTICAL|SBF_HIDE_EMPTY_SLOTS\"\r\n" + "		first_slot=\"20000\"\r\n"
					+ "		slot_count=\"20\" \r\n" + "		hotkeyrange_start=\"Shortcutbar_Extra1_1\"\r\n" + "	/>\r\n"
					+ "</View>";

		} else {
			code = "<View view_layout=\"vertical\">\r\n" + "</View>";
		}

		content = content.replaceAll("var_code", code);

		FileManager.stringToFile(targetDir, content);

	}
}
