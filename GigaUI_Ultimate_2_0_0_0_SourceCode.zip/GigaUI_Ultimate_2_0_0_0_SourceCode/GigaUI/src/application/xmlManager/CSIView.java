package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.ImageManager;

public class CSIView {

	public static void readCSIView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/ComboSequenceIndicator/CSIView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		if (content.contains("dir_h")) {
			settings.setIsCSIHorizontal(1);
		} else {
			settings.setIsCSIHorizontal(0);
		}

		// 다크모드 컬러
		Matcher m;
		Pattern p;
		p = Pattern.compile("bitmap_gfx=\"../../Customized/gfx/csi/dir[^\"]*_c_(-?\\d+)_(-?\\d+)_(-?\\d+)\\.png\"");
		m = p.matcher(content);

		if (m.find()) {
			int hue = Integer.parseInt(m.group(1));
			int chroma = Integer.parseInt(m.group(2));
			int lightness = Integer.parseInt(m.group(3));

			settings.setCsi_bg_lightness(lightness);
		} else {
			settings.setCsi_bg_lightness(0);
		}

	}

	public static void writeCSIView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/ComboSequenceIndicator/CSIView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String csi_layout;
		String csi_dir_type;
		String csi_inner_borders_x;
		String csi_inner_borders_y;
		String csi_last_img;

		if (settings.getIsCSIHorizontal() == 0) {
			csi_layout = new String("vertical");
			csi_dir_type = new String("v");
			csi_inner_borders_x = new String("0");
			csi_inner_borders_y = new String("6");
			csi_last_img = new String("bottom");
		} else {
			csi_layout = new String("horizontal");
			csi_dir_type = new String("h");
			csi_inner_borders_x = new String("6");
			csi_inner_borders_y = new String("0");
			csi_last_img = new String("right");
		}

		content = content.replaceAll("var_csi_layout", csi_layout);
		content = content.replaceAll("var_csi_type", csi_dir_type);
		content = content.replaceAll("var_csi_inner_borders_x", csi_inner_borders_x);
		content = content.replaceAll("var_csi_inner_borders_y", csi_inner_borders_y);
		content = content.replaceAll("var_csi_last_img", csi_last_img);

		// bg 다크모드 컬러
		String chroma_code = "";

		String dir_v_souceImgDir = customizedDir + "/gfx/csi/dir_v.png";
		String dir_v_customImgDir = customizedDir + "/gfx/csi/dir_v.png";

		String dir_h_souceImgDir = customizedDir + "/gfx/csi/dir_h.png";
		String dir_h_customImgDir = customizedDir + "/gfx/csi/dir_h.png";

		String icon_v_souceImgDir = customizedDir + "/gfx/csi/icon_v.png";
		String icon_v_customImgDir = customizedDir + "/gfx/csi/icon_v.png";

		String icon_h_souceImgDir = customizedDir + "/gfx/csi/icon_h.png";
		String icon_h_customImgDir = customizedDir + "/gfx/csi/icon_h.png";

		String bottom_souceImgDir = customizedDir + "/gfx/csi/bottom.png";
		String bottom_customImgDir = customizedDir + "/gfx/csi/bottom.png";

		String right_souceImgDir = customizedDir + "/gfx/csi/right.png";
		String right_customImgDir = customizedDir + "/gfx/csi/right.png";

		if (settings.getCsi_bg_lightness() == 0) {
			chroma_code = "";
		} else {
			chroma_code = "_c_0_0_" + String.valueOf(settings.getCsi_bg_lightness());

			dir_v_customImgDir = customizedDir + "/gfx/csi/dir_v" + chroma_code + ".png";
			dir_h_customImgDir = customizedDir + "/gfx/csi/dir_h" + chroma_code + ".png";
			icon_v_customImgDir = customizedDir + "/gfx/csi/icon_v" + chroma_code + ".png";
			icon_h_customImgDir = customizedDir + "/gfx/csi/icon_h" + chroma_code + ".png";
			bottom_customImgDir = customizedDir + "/gfx/csi/bottom" + chroma_code + ".png";
			right_customImgDir = customizedDir + "/gfx/csi/right" + chroma_code + ".png";

			ImageManager.process(dir_v_souceImgDir, dir_v_customImgDir, 0, 0, settings.getCsi_bg_lightness());
			ImageManager.process(dir_h_souceImgDir, dir_h_customImgDir, 0, 0, settings.getCsi_bg_lightness());
			ImageManager.process(icon_v_souceImgDir, icon_v_customImgDir, 0, 0, settings.getCsi_bg_lightness());
			ImageManager.process(icon_h_souceImgDir, icon_h_customImgDir, 0, 0, settings.getCsi_bg_lightness());
			ImageManager.process(bottom_souceImgDir, bottom_customImgDir, 0, 0, settings.getCsi_bg_lightness());
			ImageManager.process(right_souceImgDir, right_customImgDir, 0, 0, settings.getCsi_bg_lightness());
		}
		content = content.replaceAll("var_chroma", chroma_code);

		FileManager.stringToFile(targetDir, content);
	}
}
