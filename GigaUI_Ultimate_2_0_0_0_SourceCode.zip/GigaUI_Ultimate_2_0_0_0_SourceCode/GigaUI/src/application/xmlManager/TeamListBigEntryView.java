package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class TeamListBigEntryView {

	public static void readTeamListBigEntryView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListBigEntryView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

	}

	public static void writeTeamListBigEntryView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListBigEntryView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");
			// 체력 오프셋
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,1)\"");
		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_name_margin_y1", "-1");
			content = content.replaceAll("var_name_margin_y2", "0");
			// 체력 오프셋
			content = content.replaceAll("var_label_offset", "");
		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");
			// 체력 오프셋
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,1)\"");
		}

		// 체력바 폰트 볼드
		if (settings.isHPLabelBold()) {
			content = content.replaceAll("var_label_font", "label_font=\"NORMAL_BOLD\"");
		} else {
			content = content.replaceAll("var_label_font", "");
		}

		// HP 라벨 컬러(밝기)
		content = content.replaceAll("var_label_color", HexConverter.intToHex(settings.getHPLabelBrightness()));

		FileManager.stringToFile(targetDir, content);

	}
}
