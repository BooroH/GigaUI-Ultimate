package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MenuIconWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider menuIcon_location_slider;
	private Label menuIcon_location_label;
	
	private Slider menuIcon_layout_slider;
	private Label menuIcon_layout_label;

	private Button okButton;
	private Button backButton;

	public MenuIconWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int isMenuIcon_right;
		if(manager.getSettings().isMenuIcon_right())
			isMenuIcon_right=1;
		else
			isMenuIcon_right=0;
		
		int isMenuIcon_horizontal;
		if(manager.getSettings().isMenuIcon_horizontal())
			isMenuIcon_horizontal=1;
		else
			isMenuIcon_horizontal=0;
		
		menuIcon_location_slider = createSlider(0, 1, isMenuIcon_right, 1, 130);
		menuIcon_location_label = new Label("");
		
		menuIcon_layout_slider = createSlider(0, 1, isMenuIcon_horizontal, 1, 130);
		menuIcon_layout_label = new Label("");
		
		if(isMenuIcon_right==0)
			menuIcon_location_label.setText("Left");
		else if(isMenuIcon_right==1)
			menuIcon_location_label.setText("Right");
		
		if(isMenuIcon_horizontal==0)
			menuIcon_layout_label.setText("Vertical");
		else if(isMenuIcon_horizontal==1)
			menuIcon_layout_label.setText("Horizontal");
		
		backButton = new Button("Back");
		okButton = new Button("OK");
	}
	
	@Override
	protected Parent createView() {
		HBox locationBox = new HBox(10, new Label("Location"), menuIcon_location_slider, menuIcon_location_label);
		HBox layoutBox = new HBox(10, new Label("Layout"), menuIcon_layout_slider, menuIcon_layout_label);
		
		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(locationBox,layoutBox);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		menuIcon_location_slider.valueProperty().addListener((obs, oldVal, newVal) -> {
			menuIcon_location_slider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				menuIcon_location_label.setText("Left");
			else if(newVal.intValue()==1)
				menuIcon_location_label.setText("Right");
		});
		
		menuIcon_layout_slider.valueProperty().addListener((obs, oldVal, newVal) -> {
			menuIcon_layout_slider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				menuIcon_layout_label.setText("Vertical");
			else if(newVal.intValue()==1)
				menuIcon_layout_label.setText("Horizontal");
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			if(((int)menuIcon_location_slider.getValue())==1)
				manager.getSettings().setMenuIcon_right(true);
			else
				manager.getSettings().setMenuIcon_right(false);
			
			if(((int)menuIcon_layout_slider.getValue())==1)
				manager.getSettings().setMenuIcon_horizontal(true);
			else
				manager.getSettings().setMenuIcon_horizontal(false);

			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() { return 450; }  
	@Override
    protected double getHeight() { return 250; }  
	@Override
	protected String getTitle() {
		return "Menu Icons";
	}

}
