package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UnitListWindow extends BaseWindow {
	private final WindowManager manager;

	private CheckBox petLimitCheckBox;

	private Slider petLimitSlider;
	private Label petLimitLabel;

	private Slider petAlphaSlider;
	private Label petAlphaLabel;
	
	private Slider groupAlphaSlider;
	private Label groupAlphaLabel;
	
	private Slider raidAlphaSlider;
	private Label raidAlphaLabel;

	private Button okButton;
	private Button backButton;

	public UnitListWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		boolean petLimit = manager.getSettings().isPetListSizeLimit();
		int petMaxHeight = manager.getSettings().getPetListSize();
		int petAlpha = (int) (manager.getSettings().getPetListAlpha() * 100);
		int groupAlpha = (int) (manager.getSettings().getGroupHPAlpha() * 100);
		int raidAlpha = (int) (manager.getSettings().getRaidHPAlpha() * 100);

		groupAlphaSlider = createSlider(80, 100, groupAlpha, 1, 300);
		groupAlphaLabel = new Label(String.valueOf(groupAlpha));
		
		raidAlphaSlider = createSlider(80, 100, raidAlpha, 1, 300);
		raidAlphaLabel = new Label(String.valueOf(raidAlpha));
		
		petLimitCheckBox = new CheckBox("");

		petLimitSlider = createSlider(200, 330, petMaxHeight, 1, 300);
		petLimitLabel = new Label(String.valueOf(petMaxHeight));

		petAlphaSlider = createSlider(80, 100, petAlpha, 1, 300);
		petAlphaLabel = new Label(String.valueOf(petAlpha));

		petLimitCheckBox.setSelected(petLimit);
		if (!petLimit) {
			petLimitSlider.setDisable(true);
			petLimitLabel.setText("");
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox limitBox = new HBox(10, new Label("Limit Height"), petLimitCheckBox);
		HBox petLimitBox = new HBox(10, new Label("Maximum Height"), petLimitSlider, petLimitLabel);
		HBox petAlphaBox = new HBox(10, new Label("Alpha"), petAlphaSlider, petAlphaLabel);
		HBox groupAlphaBox = new HBox(10, new Label("Group HP Alpha"), groupAlphaSlider, groupAlphaLabel);
		HBox raidAlphaBox = new HBox(10, new Label("Raid HP Alpha"), raidAlphaSlider, raidAlphaLabel);

		Label petLabel = new Label("PET");
		VBox.setMargin(petLabel, new Insets(20, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(groupAlphaBox,raidAlphaBox,petLabel, limitBox,
				petLimitBox, petAlphaBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		groupAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			groupAlphaSlider.setValue(newVal.intValue());
			groupAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});
		raidAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			raidAlphaSlider.setValue(newVal.intValue());
			raidAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});
		
		petLimitCheckBox.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
			petLimitSlider.setDisable(!isSelected);
			if (isSelected) {
				petLimitLabel.setText(String.valueOf((int) petLimitSlider.getValue()));
			} else {
				petLimitLabel.setText("");
			}
		});
		petLimitSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			petLimitSlider.setValue(newVal.intValue());
			petLimitLabel.setText(String.valueOf(newVal.intValue()));
		});
		petAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			petAlphaSlider.setValue(newVal.intValue());
			petAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setPetListSizeLimit(petLimitCheckBox.isSelected());
			manager.getSettings().setPetListSize((int) petLimitSlider.getValue());
			manager.getSettings().setPetListAlpha(petAlphaSlider.getValue() / 100);
			manager.getSettings().setGroupHPAlpha(groupAlphaSlider.getValue() / 100);
			manager.getSettings().setRaidHPAlpha(raidAlphaSlider.getValue() / 100);
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Group, Raid, Pet List";
	}

}