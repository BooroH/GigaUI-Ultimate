package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MiniSlotWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider colSlider;
	private Label colLabel;
	private Slider sizeSlider;
	private Label sizeLabel;
	private Slider gapSlider;
	private Label gapLabel;
	private Slider moveXSlider;
	private Label moveXLabel;
	private Slider moveYSlider;
	private Label moveYLabel;

	private Slider mainGapSlider;
	private Label mainGapLabel;

	private Slider mainMoveYSlider;
	private Label mainMoveYLabel;

	private Button okButton;
	private Button backButton;

	private CheckBox hideCheckBox;

	public MiniSlotWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int mainGap = manager.getSettings().getIcon_spacing();
		int mainY = manager.getSettings().getBottomBar_Pos_Y();

		int col = manager.getSettings().getMiniSlot_count();
		int size = manager.getSettings().getMiniSlot_size();
		int gap = manager.getSettings().getMiniSlot_spacing();
		int x = manager.getSettings().getMiniSlot_pos_x();
		int y = manager.getSettings().getMiniSlot_pos_y();
		boolean hide = manager.getSettings().isMiniSlotHide();

		mainGapSlider = createSlider(-7, 0, mainGap, 1, 300);
		mainGapLabel = new Label(String.valueOf(mainGap));

		mainMoveYSlider = createSlider(0, 800, mainY, 1, 300);
		mainMoveYLabel = new Label(String.valueOf(mainY));

		colSlider = createSlider(0, 5, col, 1, 200);
		colLabel = new Label(String.valueOf(col));

		sizeSlider = createSlider(33, 65, size, 2, 300);
		sizeLabel = new Label(String.valueOf(size));

		gapSlider = createSlider(-6, 0, gap, 1, 200);
		gapLabel = new Label(String.valueOf(gap));

		moveXSlider = createSlider(-1000, 1000, x, 1, 350);
		moveXLabel = new Label(String.valueOf(x));

		moveYSlider = createSlider(0, 800, y, 1, 350);
		moveYLabel = new Label(String.valueOf(y));

		hideCheckBox = new CheckBox("");
		hideCheckBox.setSelected(hide);

		if (col == 0) {
			sizeSlider.setDisable(true);
			sizeLabel.setText("");
			gapSlider.setDisable(true);
			gapLabel.setText("");
			moveXSlider.setDisable(true);
			moveXLabel.setText("");
			moveYSlider.setDisable(true);
			moveYLabel.setText("");
			hideCheckBox.setDisable(true);
		}

		if (manager.getSettings().isHideEmptySlots()) {
			hideCheckBox.setDisable(true);
			hideCheckBox.setSelected(true);
		}

		if (manager.getSettings().getBottomBar_column() > 17) {
			if (manager.getSettings().getBottomBar_column() > 27 || manager.getSettings().getBottomBar_row() > 2) {
				colSlider.setDisable(true);
			} else {
				colSlider.setDisable(false);
			}
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox mainGapBox = new HBox(10, new Label("Gap"), mainGapSlider, mainGapLabel);
		HBox mainMoveYBox = new HBox(10, new Label("Move y"), mainMoveYSlider, mainMoveYLabel);

		HBox colBox = new HBox(10, new Label("Column"), colSlider, colLabel);
		HBox sizeBox = new HBox(10, new Label("Size"), sizeSlider, sizeLabel);
		HBox gapBox = new HBox(10, new Label("Gap"), gapSlider, gapLabel);
		HBox moveXBox = new HBox(10, new Label("Move x"), moveXSlider, moveXLabel);
		HBox moveYBox = new HBox(10, new Label("Move y"), moveYSlider, moveYLabel);
		HBox hideBox = new HBox(10, new Label("Hide Empty Slots"), hideCheckBox);
		
		Label miniBarLabel = new Label("Mini Bar");
		VBox.setMargin(miniBarLabel, new Insets(30, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(new Label("Main Bar"), mainGapBox, mainMoveYBox, miniBarLabel, colBox,
				sizeBox, gapBox, moveXBox, moveYBox, hideBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		mainGapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			mainGapSlider.setValue(newVal.intValue());
			mainGapLabel.setText(String.valueOf(newVal.intValue()));
		});
		mainMoveYSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			mainMoveYSlider.setValue(newVal.intValue());
			mainMoveYLabel.setText(String.valueOf(newVal.intValue()));
		});
		
		colSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			colSlider.setValue(newVal.intValue());
			colLabel.setText(String.valueOf(newVal.intValue()));

			if (newVal.intValue() == 0) {
				sizeSlider.setDisable(true);
				sizeLabel.setText("");
				gapSlider.setDisable(true);
				gapLabel.setText("");
				moveXSlider.setDisable(true);
				moveXLabel.setText("");
				moveYSlider.setDisable(true);
				moveYLabel.setText("");
				if (manager.getSettings().isHideEmptySlots())
					hideCheckBox.setSelected(true);
				else
					hideCheckBox.setSelected(false);
				hideCheckBox.setDisable(true);
			} else {
				sizeSlider.setDisable(false);
				sizeLabel.setText(String.valueOf((int) sizeSlider.getValue()));
				gapSlider.setDisable(false);
				gapLabel.setText(String.valueOf((int) gapSlider.getValue()));
				moveXSlider.setDisable(false);
				moveXLabel.setText(String.valueOf((int) moveXSlider.getValue()));
				moveYSlider.setDisable(false);
				moveYLabel.setText(String.valueOf((int) moveYSlider.getValue()));
				if (manager.getSettings().isHideEmptySlots()) {
					hideCheckBox.setDisable(true);
					hideCheckBox.setSelected(true);
				} else {
					hideCheckBox.setDisable(false);
				}
			}
		});
		gapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			gapSlider.setValue(newVal.intValue());
			gapLabel.setText(String.valueOf(newVal.intValue()));
		});
		sizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			sizeSlider.setValue(newVal.intValue());
			sizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		moveXSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveXSlider.setValue(newVal.intValue());
			moveXLabel.setText(String.valueOf(newVal.intValue()));
		});
		moveYSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveYSlider.setValue(newVal.intValue());
			moveYLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setIcon_spacing((int) mainGapSlider.getValue());
			manager.getSettings().setBottomBar_Pos_Y((int) mainMoveYSlider.getValue());
			
			manager.getSettings().setMiniSlot_count((int) colSlider.getValue());
			manager.getSettings().setMiniSlot_size((int) sizeSlider.getValue());
			manager.getSettings().setMiniSlot_spacing((int) gapSlider.getValue());
			manager.getSettings().setMiniSlot_pos_x((int) moveXSlider.getValue());
			manager.getSettings().setMiniSlot_pos_y((int) moveYSlider.getValue());
			manager.getSettings().setMiniSlotHide(hideCheckBox.isSelected());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() {
		return 580;
	}

	@Override
	protected double getHeight() {
		return 540;
	}
	@Override
	protected String getTitle() {
		return "Action Bar";
	}
}
