package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FloatingPortraitWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider nameBgAlphaSlider;
	private Label nameBgAlphaLabel;
	private Slider buffSizeSlider;
	private Label buffSizeLabel;
	private Slider buffGapSlider;
	private Label buffGapLabel;
	private Slider buffColSlider;
	private Label buffColLabel;
	private Slider barAlphaSlider;
	private Label barAlphaLabel;
	private Slider widthSlider;
	private Label widthLabel;

	private Button okButton;
	private Button backButton;

	CheckBox showManaCheckBox;
	CheckBox showDebuffCheckBox;

	public FloatingPortraitWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int width = manager.getSettings().getFloatingPortrait_width();
		int alpha = (int) (manager.getSettings().getFloatingPortrait_bar_alpha() * 100);
		int nameBgAlpha = (int) (manager.getSettings().getNameplate_alpha() * 100);
		boolean showMana = manager.getSettings().isFloatingPortrait_show_mana();

		int debuffFilter = manager.getSettings().getFloatingPortrait_buff_filter();
		int debuffSize = manager.getSettings().getFloatingPortrait_buff_size();
		int debuffGap = manager.getSettings().getFloatingPortrait_buff_spacing();
		int debuffCol = manager.getSettings().getFloatingPortrait_buff_column();

		widthSlider = createSlider(185, 233, width, 24, 200);
		int width_p = 100 - Math.round((233 - (int)widthSlider.getValue()) / 0.96f);
		widthLabel = new Label(String.valueOf(width_p)+"%");

		barAlphaSlider = createSlider(80, 100, alpha, 1, 300);
		barAlphaLabel = new Label(String.valueOf(alpha));

		nameBgAlphaSlider = createSlider(0, 100, nameBgAlpha, 1, 300);
		nameBgAlphaLabel = new Label(String.valueOf(nameBgAlpha));

		showManaCheckBox = new CheckBox("");
		showDebuffCheckBox = new CheckBox("");

		buffSizeSlider = createSlider(19, 49, debuffSize, 1, 300);
		buffSizeLabel = new Label(String.valueOf(debuffSize));

		buffGapSlider = createSlider(0, 5, debuffGap, 1, 200);
		buffGapLabel = new Label(String.valueOf(debuffGap));

		buffColSlider = createSlider(5, 20, debuffCol, 1, 300);
		buffColLabel = new Label(String.valueOf(debuffCol));

		showManaCheckBox.setSelected(showMana);

		if (debuffFilter == 0) {
			showDebuffCheckBox.setSelected(false);
			buffSizeSlider.setDisable(true);
			buffSizeLabel.setText("");
			buffGapSlider.setDisable(true);
			buffGapLabel.setText("");
			buffColSlider.setDisable(true);
			buffColLabel.setText("");
		} else {
			showDebuffCheckBox.setSelected(true);
			buffColSlider.setDisable(false);
			buffColLabel.setText(String.valueOf(debuffCol));
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox nameBgAlphaBox = new HBox(10, new Label("Name Bg Alpha"), nameBgAlphaSlider, nameBgAlphaLabel);
		HBox buffSizeBox = new HBox(10, new Label("Size"), buffSizeSlider, buffSizeLabel);
		HBox buffGapBox = new HBox(10, new Label("Gap"), buffGapSlider, buffGapLabel);
		HBox buffColBox = new HBox(10, new Label("Column"), buffColSlider, buffColLabel);
		HBox barAlphaBox = new HBox(10, new Label("Bar Alpha"), barAlphaSlider, barAlphaLabel);
		HBox sizeBox = new HBox(10, new Label("Size"), widthSlider, widthLabel);
		HBox showManaBox = new HBox(10, new Label("Show Mana/Stam"), showManaCheckBox);
		HBox showDebuffBox = new HBox(10, new Label("Show Debuff"), showDebuffCheckBox);

		Label barLabel = new Label("STATUS BAR");
		Label debuffLabel = new Label("DEBUFF");
		VBox.setMargin(debuffLabel, new Insets(20, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(barLabel, sizeBox, barAlphaBox, nameBgAlphaBox,
				showManaBox, debuffLabel, showDebuffBox, buffSizeBox, buffGapBox, buffColBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {

		widthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			widthSlider.setValue(newVal.intValue());
			int width_p = 100 - Math.round((233 - newVal.intValue()) / 0.96f);
			widthLabel.setText(String.valueOf(width_p)+"%");
		});

		barAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			barAlphaSlider.setValue(newVal.intValue());
			barAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});

		nameBgAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			nameBgAlphaSlider.setValue(newVal.intValue());
			nameBgAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});

		showDebuffCheckBox.selectedProperty().addListener((obs, wasSelected, isSelected) -> {
			if (!isSelected) {
				buffSizeSlider.setDisable(true);
				buffSizeLabel.setText("");
				buffGapSlider.setDisable(true);
				buffGapLabel.setText("");
				buffColSlider.setDisable(true);
				buffColLabel.setText("");
			} else {
				buffSizeSlider.setDisable(false);
				buffSizeLabel.setText(String.valueOf((int) buffSizeSlider.getValue()));
				buffGapSlider.setDisable(false);
				buffGapLabel.setText(String.valueOf((int) buffGapSlider.getValue()));
				buffColSlider.setDisable(false);
				buffColLabel.setText(String.valueOf((int) buffColSlider.getValue()));
			}
		});

		buffSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			buffSizeSlider.setValue(newVal.intValue());
			buffSizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		buffGapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			buffGapSlider.setValue(newVal.intValue());
			buffGapLabel.setText(String.valueOf(newVal.intValue()));
		});
		buffColSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			buffColSlider.setValue(newVal.intValue());
			buffColLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setFloatingPortrait_width((int) widthSlider.getValue());
			manager.getSettings().setFloatingPortrait_bar_alpha(barAlphaSlider.getValue() / 100);
			manager.getSettings().setNameplate_alpha(nameBgAlphaSlider.getValue() / 100);
			manager.getSettings().setFloatingPortrait_show_mana(showManaCheckBox.isSelected());
			if (showDebuffCheckBox.isSelected()) {
				manager.getSettings().setFloatingPortrait_buff_filter(1);
			} else {
				manager.getSettings().setFloatingPortrait_buff_filter(0);
			}
			manager.getSettings().setFloatingPortrait_buff_size((int) buffSizeSlider.getValue());
			manager.getSettings().setFloatingPortrait_buff_spacing((int) buffGapSlider.getValue());
			manager.getSettings().setFloatingPortrait_buff_column((int) buffColSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() {
		return 620;
	}

	@Override
	protected double getHeight() {
		return 600;
	}

	@Override
	protected String getTitle() {
		return "Floating Portrait";
	}

}
