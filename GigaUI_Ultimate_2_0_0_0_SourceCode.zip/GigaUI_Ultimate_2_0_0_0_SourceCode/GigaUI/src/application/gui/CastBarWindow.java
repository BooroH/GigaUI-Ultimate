package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CastBarWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider hueSlider;
	private Label hueLabel;
	private Slider textLocSlider;
	private Label textLocLabel;
	private Slider widthSlider;
	private Label widthLabel;
	private Slider heightSlider;
	private Label heightLabel;
	private Slider alphaSlider;
	private Label alphaLabel;
	private Slider text_y_slider;
	private Label text_y_label;

	private Button okButton;
	private Button backButton;

	public CastBarWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int width = manager.getSettings().getCastBar_width();
		int height = manager.getSettings().getCastBar_height();
		int hue = (int) manager.getSettings().getCastBar_hue();
		int textLoc = manager.getSettings().getCastBar_text_location();
		int text_y = manager.getSettings().getCastBar_text_y();
		int alpha = (int) (manager.getSettings().getCastBar_alpha() * 100);

		hueSlider = createSlider(-180, 181, hue, 1, 360);
		String color = "";
		if (hue<-150) {
			color = "blue";
		}
		else if(hue<-120) {
			color = "violet";
		}
		else if(hue<-90) {
			color = "purple";
		}
		else if(hue<-60) {
			color = "pink";
		}
		else if(hue<-30) {
			color = "red";
		}
		else if(hue<0) {
			color = "orange";
		}
		else if(hue<30) {
			color = "yellow";
		}
		else if(hue<70) {
			color = "green";
		}
		else if(hue<110) {
			color = "aqua";
		}
		else if(hue<140) {
			color = "emerald";
		}
		else if(hue<170) {
			color = "skyblue";
		}
		else if(hue<181){
			color = "blue";
		}
		else {
			color = "white";
		}
		
		hueLabel = new Label(color+" ("+String.valueOf(hue) + ")");

		textLocSlider = createSlider(1, 3, textLoc, 1, 120);
		textLocLabel = new Label("");
		
		text_y_slider = createSlider(-3, 3, text_y, 1, 180);
		text_y_label = new Label(String.valueOf(text_y));

		widthSlider = createSlider(209, 269, width, 2, 280);
		int width_p = 100 - Math.round((269 - (int)widthSlider.getValue()) / 1.2f);
		widthLabel = new Label(String.valueOf(width_p)+"%");
		
		heightSlider = createSlider(29, 43, height, 2, 280);
		int height_p = 100 - Math.round((43 - (int)heightSlider.getValue()) / 0.28f);
		heightLabel = new Label(String.valueOf(height_p)+"%");

		alphaSlider = createSlider(80, 100, alpha, 1, 300);
		alphaLabel = new Label(String.valueOf(alpha));

		if (textLoc == 1) {
			textLocLabel.setText("Top");

		} else if (textLoc == 2) {
			textLocLabel.setText("Inside");
		} else if (textLoc == 3) {
			textLocLabel.setText("Bottom");
		}

		
		backButton = new Button("Back");
		okButton = new Button("OK");
		
	}

	@Override
	protected Parent createView() {
		HBox hueBox = new HBox(10, new Label("Color"), hueSlider, hueLabel);
		HBox textLocBox = new HBox(10, new Label("Text Location"), textLocSlider, textLocLabel);
		HBox text_y_box = new HBox(10, new Label("Text Move y"), text_y_slider, text_y_label);
		HBox widthBox = new HBox(10, new Label("Width"), widthSlider, widthLabel);
		HBox heightBox = new HBox(10, new Label("Height"), heightSlider, heightLabel);
		HBox alphaBox = new HBox(10, new Label("Alpha"), alphaSlider, alphaLabel);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(hueBox, widthBox, heightBox, textLocBox, text_y_box, alphaBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		alphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			alphaSlider.setValue(newVal.intValue());
			alphaLabel.setText(String.valueOf(newVal.intValue()));
		});
		textLocSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			textLocSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1) {
				textLocLabel.setText("Top");
			} else if (newVal.intValue() == 2) {
				textLocLabel.setText("Inside");
			} else if (newVal.intValue() == 3) {
				textLocLabel.setText("Bottom");
			}
		});
		hueSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			hueSlider.setValue(newVal.intValue());
			String color = "";
			if (newVal.intValue()<-150) {
				color = "blue";
			}
			else if(newVal.intValue()<-120) {
				color = "violet";
			}
			else if(newVal.intValue()<-90) {
				color = "purple";
			}
			else if(newVal.intValue()<-60) {
				color = "pink";
			}
			else if(newVal.intValue()<-30) {
				color = "red";
			}
			else if(newVal.intValue()<0) {
				color = "orange";
			}
			else if(newVal.intValue()<30) {
				color = "yellow";
			}
			else if(newVal.intValue()<70) {
				color = "green";
			}
			else if(newVal.intValue()<110) {
				color = "aqua";
			}
			else if(newVal.intValue()<140) {
				color = "emerald";
			}
			else if(newVal.intValue()<170) {
				color = "skyblue";
			}
			else if(newVal.intValue()<181){
				color = "blue";
			}
			else {
				color = "white";
			}
			hueLabel.setText(color+" ("+String.valueOf(newVal.intValue())+")");

		});
		widthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			widthSlider.setValue(newVal.intValue());
			int width_p = 100 - Math.round((269 - newVal.intValue()) / 1.2f);
			widthLabel.setText(String.valueOf(width_p)+"%");
		});
		heightSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			heightSlider.setValue(newVal.intValue());
			int height_p = 100 - Math.round((43 - newVal.intValue()) / 0.28f);
			heightLabel.setText(String.valueOf(height_p)+"%");
		});
		text_y_slider.valueProperty().addListener((obs, oldVal, newVal) -> {
			text_y_slider.setValue(newVal.intValue());
			text_y_label.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setCastBar_hue(hueSlider.getValue());
			manager.getSettings().setCastBar_text_location((int) textLocSlider.getValue());
			manager.getSettings().setCastBar_alpha(alphaSlider.getValue() / 100);
			manager.getSettings().setCastBar_width((int) widthSlider.getValue());
			manager.getSettings().setCastBar_height((int) heightSlider.getValue());
			manager.getSettings().setCastBar_text_y((int) text_y_slider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Castbar";
	}

}
