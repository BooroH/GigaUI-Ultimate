package application.setting;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import application.xmlManager.*;

public class SettingManager {

	public static void saveProfile(File file) {
		Settings settings = Settings.getInstance();
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("icon_spacing=").append(settings.getIcon_spacing()).append("\n");
			sb.append("slot_size=").append(settings.getSlot_size()).append("\n");
			sb.append("perk_size=").append(settings.getPerk_size()).append("\n");
			sb.append("dirSlot_size=").append(settings.getDirSlot_size()).append("\n");
			sb.append("bottomBar_row=").append(settings.getBottomBar_row()).append("\n");
			sb.append("bottomBar_column=").append(settings.getBottomBar_column()).append("\n");
			sb.append("isHideEmptySlots=").append(settings.isHideEmptySlots()).append("\n");
			sb.append("bottomBar_Pos_Y=").append(settings.getBottomBar_Pos_Y()).append("\n");
			sb.append("lPortrait_x=").append(settings.getLPortrait_x()).append("\n");
			sb.append("lPortrait_y=").append(settings.getLPortrait_y()).append("\n");
			sb.append("rPortrait_x=").append(settings.getRPortrait_x()).append("\n");
			sb.append("rPortrait_y=").append(settings.getRPortrait_y()).append("\n");
			sb.append("lrPortrait_y_diff=").append(settings.getLRPortrait_y_diff()).append("\n");
			sb.append("lp_buff_size=").append(settings.getLP_buff_size()).append("\n");
			sb.append("lp_buff_spacing=").append(settings.getLP_buff_spacing()).append("\n");
			sb.append("lp_buff_column=").append(settings.getLP_buff_column()).append("\n");
			sb.append("rp_buff_size=").append(settings.getRP_buff_size()).append("\n");
			sb.append("rp_buff_spacing=").append(settings.getRP_buff_spacing()).append("\n");
			sb.append("rp_buff_column=").append(settings.getRP_buff_column()).append("\n");
			sb.append("rp_buff_filter=").append(settings.getRP_buff_filter()).append("\n");
			sb.append("soulshard_x=").append(settings.getSoulshard_x()).append("\n");
			sb.append("soulshard_y=").append(settings.getSoulshard_y()).append("\n");
			sb.append("nameplate_alpha=").append(settings.getNameplate_alpha()).append("\n");
			sb.append("floatingPortrait_bar_alpha=").append(settings.getFloatingPortrait_bar_alpha()).append("\n");
			sb.append("floatingPortrait_show_mana=").append(settings.isFloatingPortrait_show_mana()).append("\n");
			sb.append("floatingPortrait_buff_filter=").append(settings.getFloatingPortrait_buff_filter()).append("\n");
			sb.append("floatingPortrait_buff_size=").append(settings.getFloatingPortrait_buff_size()).append("\n");
			sb.append("floatingPortrait_buff_spacing=").append(settings.getFloatingPortrait_buff_spacing())
					.append("\n");
			sb.append("floatingPortrait_buff_column=").append(settings.getFloatingPortrait_buff_column()).append("\n");
			sb.append("floatingPortrait_style=").append(settings.getFloatingPortrait_style()).append("\n");
			sb.append("floatingPortrait_hp_color=").append(settings.getFloatingPortrait_hp_color()).append("\n");
			sb.append("floatingPortrait_hp_thickness=").append(settings.getFloatingPortrait_hp_thickness())
					.append("\n");
			sb.append("miniSlot_count=").append(settings.getMiniSlot_count()).append("\n");
			sb.append("miniSlot_spacing=").append(settings.getMiniSlot_spacing()).append("\n");
			sb.append("miniSlot_margin=").append(settings.getMiniSlot_margin()).append("\n");
			sb.append("miniSlot_size=").append(settings.getMiniSlot_size()).append("\n");
			sb.append("miniSlot_pos_x=").append(settings.getMiniSlot_pos_x()).append("\n");
			sb.append("miniSlot_pos_y=").append(settings.getMiniSlot_pos_y()).append("\n");
			sb.append("isMiniSlotHide=").append(settings.isMiniSlotHide()).append("\n");
			sb.append("isSlotHideForOptionOnly=").append(settings.isSlotHideForOptionOnly()).append("\n");
			sb.append("showMiniMap=").append(settings.getShowMiniMap()).append("\n");
			sb.append("isSimpleMap=").append(settings.getIsSimpleMap()).append("\n");
			sb.append("isCSIHorizontal=").append(settings.getIsCSIHorizontal()).append("\n");
			sb.append("castBar_style=").append(settings.getCastBar_style()).append("\n");
			sb.append("castBar_text_location=").append(settings.getCastBar_text_location()).append("\n");
			sb.append("castBar_alpha=").append(settings.getCastBar_alpha()).append("\n");
			sb.append("castBar_color=").append(settings.getCastBar_color()).append("\n");
			sb.append("inventory_layout=").append(settings.getInventory_layout()).append("\n");
			sb.append("inventory_row=").append(settings.getInventory_row()).append("\n");
			sb.append("inventory_column=").append(settings.getInventory_column()).append("\n");
			sb.append("trader_layout=").append(settings.getTrader_layout()).append("\n");
			sb.append("trader_row=").append(settings.getTrader_row()).append("\n");
			sb.append("trader_column=").append(settings.getTrader_column()).append("\n");
			sb.append("fontSize=").append(settings.getFontSize()).append("\n");
			sb.append("cdFontSize=").append(settings.getCDFontSize()).append("\n");
			sb.append("cdFontWeight=").append(settings.getCDFontWeight()).append("\n");
			sb.append("isHPLabelBold=").append(settings.isHPLabelBold()).append("\n");
			sb.append("hpLabelBrightness=").append(settings.getHPLabelBrightness()).append("\n");
			sb.append("buffTextBrightness=").append(settings.getBuffTextBrightness()).append("\n");
			sb.append("top_buff_size=").append(settings.getTop_buff_size()).append("\n");
			sb.append("top_buff_spacing=").append(settings.getTop_buff_spacing()).append("\n");
			sb.append("top_buff_column=").append(settings.getTop_buff_column()).append("\n");
			sb.append("petListSize=").append(settings.getPetListSize()).append("\n");
			sb.append("isPetListSizeLimit=").append(settings.isPetListSizeLimit()).append("\n");
			sb.append("petListAlpha=").append(settings.getPetListAlpha()).append("\n");
			sb.append("groupHPColor=").append(settings.getGroupHPColor()).append("\n");
			sb.append("raidHPColor=").append(settings.getRaidHPColor()).append("\n");
			sb.append("overheadHPSize=").append(settings.getOverheadHPSize()).append("\n");
			sb.append("overheadHPColor=").append(settings.getOverheadHPColor()).append("\n");
			sb.append("overheadHPAlpha=").append(settings.getOverheadHPAlpha()).append("\n");
			sb.append("overheadFontWeight=").append(settings.getOverheadFontWeight()).append("\n");
			sb.append("overheadFontSize=").append(settings.getOverheadFontSize()).append("\n");

			Files.write(file.toPath(), sb.toString().getBytes());
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static boolean loadProfile(File file) {
		Settings settings = Settings.getInstance();
		try {
			List<String> lines = Files.readAllLines(file.toPath());
			Set<String> loadedKeys = new HashSet<>();

			for (String line : lines) {
				String[] parts = line.split("=");
				if (parts.length == 2) {
					String key = parts[0].trim();
					String value = parts[1].trim();

					switch (key) {
					case "icon_spacing":
						settings.setIcon_spacing(Integer.parseInt(value));
						break;
					case "slot_size":
						settings.setSlot_size(Integer.parseInt(value));
						loadedKeys.add(key);
						break;
					case "perk_size":
						settings.setPerk_size(Integer.parseInt(value));
						loadedKeys.add(key);
						break;
					case "dirSlot_size":
						settings.setDirSlot_size(Integer.parseInt(value));
						loadedKeys.add(key);
						break;
					case "bottomBar_row":
						settings.setBottomBar_row(Integer.parseInt(value));
						loadedKeys.add(key);
						break;
					case "bottomBar_column":
						settings.setBottomBar_column(Integer.parseInt(value));
						loadedKeys.add(key);
						break;
					case "bottomBar_Pos_Y":
						settings.setBottomBar_Pos_Y(Integer.parseInt(value));
						break;
					case "lPortrait_x":
						settings.setLPortrait_x(Integer.parseInt(value));
						break;
					case "lPortrait_y":
						settings.setLPortrait_y(Integer.parseInt(value));
						break;
					case "rPortrait_x":
						settings.setRPortrait_x(Integer.parseInt(value));
						break;
					case "rPortrait_y":
						settings.setRPortrait_y(Integer.parseInt(value));
						break;
					case "lrPortrait_y_diff":
						settings.setLRPortrait_y_diff(Integer.parseInt(value));
						break;
					case "lp_buff_size":
						settings.setLP_buff_size(Integer.parseInt(value));
						break;
					case "lp_buff_spacing":
						settings.setLP_buff_spacing(Integer.parseInt(value));
						break;
					case "lp_buff_column":
						settings.setLP_buff_column(Integer.parseInt(value));
						break;
					case "rp_buff_size":
						settings.setRP_buff_size(Integer.parseInt(value));
						break;
					case "rp_buff_spacing":
						settings.setRP_buff_spacing(Integer.parseInt(value));
						break;
					case "rp_buff_column":
						settings.setRP_buff_column(Integer.parseInt(value));
						break;
					case "rp_buff_filter":
						settings.setRP_buff_filter(Integer.parseInt(value));
						break;
					case "soulshard_x":
						settings.setSoulshard_x(Integer.parseInt(value));
						break;
					case "soulshard_y":
						settings.setSoulshard_y(Integer.parseInt(value));
						break;
					case "floatingPortrait_buff_filter":
						settings.setFloatingPortrait_buff_filter(Integer.parseInt(value));
						break;
					case "floatingPortrait_buff_size":
						settings.setFloatingPortrait_buff_size(Integer.parseInt(value));
						break;
					case "floatingPortrait_buff_spacing":
						settings.setFloatingPortrait_buff_spacing(Integer.parseInt(value));
						break;
					case "floatingPortrait_buff_column":
						settings.setFloatingPortrait_buff_column(Integer.parseInt(value));
						break;
					case "floatingPortrait_style":
						settings.setFloatingPortrait_style(Integer.parseInt(value));
						break;
					case "floatingPortrait_hp_color":
						settings.setFloatingPortrait_hp_color(Integer.parseInt(value));
						break;
					case "floatingPortrait_hp_thickness":
						settings.setFloatingPortrait_hp_thickness(Integer.parseInt(value));
						break;
					case "miniSlot_count":
						settings.setMiniSlot_count(Integer.parseInt(value));
						break;
					case "miniSlot_spacing":
						settings.setMiniSlot_spacing(Integer.parseInt(value));
						break;
					case "miniSlot_margin":
						settings.setMiniSlot_margin(Integer.parseInt(value));
						break;
					case "miniSlot_size":
						settings.setMiniSlot_size(Integer.parseInt(value));
						break;
					case "miniSlot_pos_x":
						settings.setMiniSlot_pos_x(Integer.parseInt(value));
						break;
					case "miniSlot_pos_y":
						settings.setMiniSlot_pos_y(Integer.parseInt(value));
						break;
					case "showMiniMap":
						settings.setShowMiniMap(Integer.parseInt(value));
						break;
					case "isSimpleMap":
						settings.setIsSimpleMap(Integer.parseInt(value));
						break;
					case "isCSIHorizontal":
						settings.setIsCSIHorizontal(Integer.parseInt(value));
						break;
					case "castBar_style":
						settings.setCastBar_style(Integer.parseInt(value));
						break;
					case "castBar_text_location":
						settings.setCastBar_text_location(Integer.parseInt(value));
						break;
					case "castBar_color":
						settings.setCastBar_color(Integer.parseInt(value));
						break;
					case "inventory_layout":
						settings.setInventory_layout(Integer.parseInt(value));
						break;
					case "inventory_row":
						settings.setInventory_row(Integer.parseInt(value));
						break;
					case "inventory_column":
						settings.setInventory_column(Integer.parseInt(value));
						break;
					case "trader_layout":
						settings.setTrader_layout(Integer.parseInt(value));
						break;
					case "trader_row":
						settings.setTrader_row(Integer.parseInt(value));
						break;
					case "trader_column":
						settings.setTrader_column(Integer.parseInt(value));
						break;
					case "fontSize":
						settings.setFontSize(Integer.parseInt(value));
						break;
					case "cdFontSize":
						settings.setCDFontSize(Integer.parseInt(value));
						break;
					case "hpLabelBrightness":
						settings.setHPLabelBrightness(Integer.parseInt(value));
						break;
					case "buffTextBrightness":
						settings.setBuffTextBrightness(Integer.parseInt(value));
						break;
					case "top_buff_size":
						settings.setTop_buff_size(Integer.parseInt(value));
						break;
					case "top_buff_spacing":
						settings.setTop_buff_spacing(Integer.parseInt(value));
						break;
					case "top_buff_column":
						settings.setTop_buff_column(Integer.parseInt(value));
						break;
					case "petListSize":
						settings.setPetListSize(Integer.parseInt(value));
						break;
					case "groupHPColor":
						settings.setGroupHPColor(Integer.parseInt(value));
						break;
					case "raidHPColor":
						settings.setRaidHPColor(Integer.parseInt(value));
						break;
					case "overheadHPSize":
						settings.setOverheadHPSize(Integer.parseInt(value));
						break;
					case "overheadHPColor":
						settings.setOverheadHPColor(Integer.parseInt(value));
						break;
					case "overheadFontSize":
						settings.setOverheadFontSize(Integer.parseInt(value));
						break;

					case "castBar_alpha":
						settings.setCastBar_alpha(Double.parseDouble(value));
						break;
					case "nameplate_alpha":
						settings.setNameplate_alpha(Double.parseDouble(value));
						break;
					case "floatingPortrait_bar_alpha":
						settings.setFloatingPortrait_bar_alpha(Double.parseDouble(value));
						break;
					case "petListAlpha":
						settings.setPetListAlpha(Double.parseDouble(value));
						break;
					case "overheadHPAlpha":
						settings.setOverheadHPAlpha(Double.parseDouble(value));
						break;

					case "isHideEmptySlots":
						settings.setHideEmptySlots(Boolean.parseBoolean(value));
						break;
					case "floatingPortrait_show_mana":
						settings.setFloatingPortrait_show_mana(Boolean.parseBoolean(value));
						break;
					case "isPetListSizeLimit":
						settings.setPetListSizeLimit(Boolean.parseBoolean(value));
						break;
					case "isMiniSlotHide":
						settings.setMiniSlotHide(Boolean.parseBoolean(value));
						break;
					case "isSlotHideForOptionOnly":
						settings.setSlotHideForOptionOnly(Boolean.parseBoolean(value));
						break;
					case "isHPLabelBold":
						settings.setHPLabelBold(Boolean.parseBoolean(value));
						break;
					case "cdFontWeight":
						settings.setCDFontWeight(value);
						break;
					case "overheadFontWeight":
						settings.setOverheadFontWeight(value);
						break;
					}
				}
			}
			List<String> requiredKeys = Arrays.asList("slot_size", "bottomBar_row", "bottomBar_column");
			for (String key : requiredKeys) {
				if (!loadedKeys.contains(key)) {
					return false;
				}
			}
			return true;
		} catch (IOException ex) {
			ex.printStackTrace();
			return false;
		}
	}

	public static void loadSettings(String aocDir) {
		String customizedDir = aocDir + "/Data/GUI/Customized";

		BottomBar.readBottomBar(customizedDir);
		BuffListViewIcon.readBuffListViewIcon(customizedDir);
		CharPortraitLeft.readLeftPortrait(customizedDir);
		CharPortraitRight.readRightPortrait(customizedDir);
		CommandTimerBar.readCommandTimerBar(customizedDir);
		CSIView.readCSIView(customizedDir);
		FloatingPortraitView.readFloatingPortraitView(customizedDir);
		Fonts.readFonts(customizedDir);
		HUDView.readdHUDView(customizedDir);
		InventoryView.readInventoryView(customizedDir);
		MapWindowSkin.readMapWindowSkin(customizedDir);
		MinimapView.readMinimapView(customizedDir);
		OverheadText.readOverheadText(customizedDir);
		PetListView.readPetListView(customizedDir);
		TeamListBigEntryView.readTeamListBigEntryView(customizedDir);
		TeamListEntryView.readTeamListEntryView(customizedDir);
		TradePostMainView.readTradePostMainView(customizedDir);

	}
}
