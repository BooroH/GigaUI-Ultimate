package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class MinimapView {

	public static void readMinimapView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MapGUI/MinimapView.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		if (content.contains("name=\"MapView\"")) {
			settings.setShowMiniMap(1);
		} else {
			settings.setShowMiniMap(0);
		}

	}

	public static void writeMinimapView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MapGUI/MinimapView.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 미니맵
		String minimapView_code;
		if (settings.getShowMiniMap() == 1) {
			minimapView_code = "<View view_layout=\"stacked\" waypoint_cap_radius=\"65\" layout_borders=\"Rect(0,0,5,0)\">\r\n"
					+ "	<RegionMapRenderer name=\"MapView\"\r\n"
					+ "		view_flags=\"RMRF_DISABLE_WAYPOINT_LABELS\"\r\n"
					+ "		min_size_extend=\"Point(212,212)\"\r\n" + "		max_size_limit=\"Point(-1,-1)\"\r\n"
					+ "		zoom_level_count=\"5\"\r\n" + "		min_meter_per_pixel=\"4\"\r\n"
					+ "		max_meter_per_pixel=\"100\"\r\n" + "	/>\r\n"
					+ "	<BitmapView bitmap_gfx=\"../../Customized/gfx/minimap/minimap.png\"/>\r\n"
					+ "	<Button name=\"MenuButton\" template:source=\"ClearButton\" label=\"M\" label_font=\"SC_LARGE_BOLD\" v_local_alignment=\"TOP\"/>\r\n"
					+ "	<View view_layout=\"vertical\" v_local_alignment=\"TOP\" h_local_alignment=\"RIGHT\" h_alignment=\"RIGHT\">\r\n"
					+ "		<BitmapView name=\"NewMailButton\"\r\n"
					+ "			bitmap_gfx=\"../../Customized/gfx/icons/mail.png\"\r\n"
					+ "			view_tooltip_text=\"&lt;localized token=YouVeGotNewMail category=Tradepost /&gt;\"\r\n"
					+ "			view_flags=\"WID_IGNORE_WHEN_HIDDEN\"\r\n" + "		/>\r\n"
					+ "		<Button name=\"PendingQuestReward\"\r\n"
					+ "			gfxid_raised=\"../../Customized/gfx/icons/pending.png\"\r\n"
					+ "			gfxid_highlight=\"../../Customized/gfx/icons/pending_hover.png\"\r\n"
					+ "			view_tooltip_text=\"Inventory is full\"\r\n" + "		/>\r\n" + "	</View>\r\n"
					+ "</View>";
		} else {
			minimapView_code = "<View view_layout=\"vertical\" h_alignment=\"RIGHT\">\r\n"
					+ "	<Button name=\"MenuButton\" template:source=\"ClearButton\" label=\"Instance\" label_font=\"SC_BOLD\" layout_borders=\"Rect(-17,0,-16,0)\" interaction_borders=\"Rect(17,0,16,0)\"/>\r\n"
					+ "	<BitmapView name=\"NewMailButton\"\r\n"
					+ "		bitmap_gfx=\"../../Customized/gfx/icons/mail.png\"\r\n"
					+ "		view_tooltip_text=\"&lt;localized token=YouVeGotNewMail category=Tradepost /&gt;\"\r\n"
					+ "		view_flags=\"WID_IGNORE_WHEN_HIDDEN\"\r\n" + "		layout_borders=\"Rect(0,0,5,0)\"\r\n"
					+ "	/>\r\n" + "	<Button name=\"PendingQuestReward\"\r\n"
					+ "		gfxid_raised=\"../../Customized/gfx/icons/pending.png\"\r\n"
					+ "		gfxid_highlight=\"../../Customized/gfx/icons/pending_hover.png\"\r\n"
					+ "		view_tooltip_text=\"Inventory is full\"\r\n" + "	/>\r\n" + "</View>";
		}

		content = content.replaceAll("var_minimapView_code", minimapView_code);

		FileManager.stringToFile(targetDir, content);

	}
}
