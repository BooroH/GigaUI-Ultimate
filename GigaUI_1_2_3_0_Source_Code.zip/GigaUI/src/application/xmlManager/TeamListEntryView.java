package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class TeamListEntryView {

	public static void readTeamListEntryView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListEntryView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		// 레이드체력색 추출
		if (content.contains("_red"))
			settings.setRaidHPColor(1);
		else if (content.contains("_auqa"))
			settings.setRaidHPColor(2);
		else if (content.contains("_blue"))
			settings.setRaidHPColor(3);
		else if (content.contains("_grass"))
			settings.setRaidHPColor(4);
		else if (content.contains("_green"))
			settings.setRaidHPColor(5);
		else if (content.contains("_lemon"))
			settings.setRaidHPColor(6);
		else if (content.contains("_orange"))
			settings.setRaidHPColor(7);
		else if (content.contains("_peach"))
			settings.setRaidHPColor(8);
		else if (content.contains("_pink"))
			settings.setRaidHPColor(9);
		else if (content.contains("_purple"))
			settings.setRaidHPColor(10);
		else if (content.contains("_sky"))
			settings.setRaidHPColor(11);
		else if (content.contains("_vanilla"))
			settings.setRaidHPColor(12);
		else if (content.contains("_white"))
			settings.setRaidHPColor(13);
		else if (content.contains("_wine"))
			settings.setRaidHPColor(14);

	}

	public static void writeTeamListEntryView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/TeamGUI/TeamListEntryView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			content = content.replaceAll("var_nameplate_magin_y2", "-1");
			content = content.replaceAll("var_name_margin_y1", "-1");
			content = content.replaceAll("var_name_margin_y2", "0");

		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_nameplate_magin_y2", "-2");
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");

		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_nameplate_magin_y2", "-2");
			content = content.replaceAll("var_name_margin_y1", "-2");
			content = content.replaceAll("var_name_margin_y2", "0");
		}

		// 레이드체력색
		String raid_hp_color = "";

		if (settings.getRaidHPColor() == 1)
			raid_hp_color = "_red";
		else if (settings.getRaidHPColor() == 2)
			raid_hp_color = "_aqua";
		else if (settings.getRaidHPColor() == 3)
			raid_hp_color = "_blue";
		else if (settings.getRaidHPColor() == 4)
			raid_hp_color = "_grass";
		else if (settings.getRaidHPColor() == 5)
			raid_hp_color = "_green";
		else if (settings.getRaidHPColor() == 6)
			raid_hp_color = "_lemon";
		else if (settings.getRaidHPColor() == 7)
			raid_hp_color = "_orange";
		else if (settings.getRaidHPColor() == 8)
			raid_hp_color = "_peach";
		else if (settings.getRaidHPColor() == 9)
			raid_hp_color = "_pink";
		else if (settings.getRaidHPColor() == 10)
			raid_hp_color = "_purple";
		else if (settings.getRaidHPColor() == 11)
			raid_hp_color = "_sky";
		else if (settings.getRaidHPColor() == 12)
			raid_hp_color = "_vanilla";
		else if (settings.getRaidHPColor() == 13)
			raid_hp_color = "_white";
		else if (settings.getRaidHPColor() == 14)
			raid_hp_color = "_wine";

		content = content.replaceAll("var_hp_color", raid_hp_color);

		FileManager.stringToFile(targetDir, content);

	}
}
