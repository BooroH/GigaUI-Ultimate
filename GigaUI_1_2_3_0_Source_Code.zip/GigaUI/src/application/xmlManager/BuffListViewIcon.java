package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class BuffListViewIcon {

	

	public static void readBuffListViewIcon(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/BuffGUI/BuffListViewIcon.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		// 버프 텍스트 컬러 추출
		p = Pattern.compile("<TextView\\s+[^>]*name=\"StackSizeView\"[^>]*default_color=\"(#[0-9a-fA-F]{6})\"",
				Pattern.CASE_INSENSITIVE);
		m = p.matcher(content);

		if (m.find()) {
			String colorCode = m.group(1);
			settings.setBuffTextBrightness(HexConverter.hexToInt(colorCode));
		}
	}

	public static void writeBuffListViewIcon(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/BuffGUI/BuffListViewIcon.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 버프텍스트마진
		int buff_above_margin_y1 = -1;
		int buff_above_margin_y2 = -1;
		int buff_below_margin_y1 = -1;
		int buff_below_margin_y2 = -1;
		// 버프 텍스트플레이트 크기
		String buffTextSize = new String("");

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			buff_above_margin_y1 = -2;
			buff_above_margin_y2 = -2;
			buff_below_margin_y1 = -2;
			buff_below_margin_y2 = -2;
		} else if (settings.getFontSize() == 1) {
			buff_above_margin_y1 = -3;
			buff_above_margin_y2 = -3;
			buff_below_margin_y1 = -3;
			buff_below_margin_y2 = -3;

			buffTextSize = "_2";
		} else if (settings.getFontSize() == 2) {
			buff_above_margin_y1 = -3;
			buff_above_margin_y2 = -3;
			buff_below_margin_y1 = -3;
			buff_below_margin_y2 = -3;

			buffTextSize = "_2";
		}

		content = content.replaceAll("var_buff_above_y1", String.valueOf(buff_above_margin_y1));
		content = content.replaceAll("var_buff_above_y2", String.valueOf(buff_above_margin_y2));
		content = content.replaceAll("var_buff_below_y1", String.valueOf(buff_below_margin_y1));
		content = content.replaceAll("var_buff_below_y2", String.valueOf(buff_below_margin_y2));
		content = content.replaceAll("var_buff_text_size", buffTextSize);

		// 버프 텍스트 컬러(밝기)
		content = content.replaceAll("var_text_color", HexConverter.intToHex(settings.getBuffTextBrightness()));

		FileManager.stringToFile(targetDir, content);

	}
}
