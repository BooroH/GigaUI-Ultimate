package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class FloatingPortraitView {

	public static void readFloatingPortraitView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/FloatingPortraitView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		// floating portrait nameplate alpha값 추출
		settings.setNameplate_alpha(1.0);
		p = Pattern.compile(
				"<BitmapView[^>]*bitmap_gfx=\"\\.\\./\\.\\./Customized/gfx/floatingportrait/nameplate\\.png\"[^>]*view_local_alpha=\"(\\d+(?:\\.\\d+)?)\"");
		m = p.matcher(content);

		if (m.find()) {
			String alphaValueStr = m.group(1);
			settings.setNameplate_alpha(Double.parseDouble(alphaValueStr));
		}

		// 바 알파값
		settings.setFloatingPortrait_bar_alpha(1.0);
		p = Pattern.compile("<View[^>]*name=\"StatBarsContainer\"[^>]*view_alpha=\"([0-9.]+)\"");
		m = p.matcher(content);

		if (m.find()) {
			String viewAlpha = m.group(1);
			settings.setFloatingPortrait_bar_alpha(Double.parseDouble(viewAlpha));
		}

		// 마나바
		if (content.contains("<ProgressBar name=\"ManaBar\""))
			settings.setFloatingPortrait_show_mana(true);
		else
			settings.setFloatingPortrait_show_mana(false);

		// 버프필터
		p = Pattern.compile("filter=\"([^\"]+)\"");
		m = p.matcher(content);

		if (content.contains("name=\"BuffListView\"")) {
			if (m.find()) {
				String filterValue = m.group(1); // 예: "friendly|hostile"

				boolean hasFriendly = filterValue.contains("friendly");
				boolean hasHostile = filterValue.contains("hostile");

				if (hasHostile && hasFriendly) {
					settings.setFloatingPortrait_buff_filter(3); // 둘다있음
				} else if (hasHostile) {
					settings.setFloatingPortrait_buff_filter(1); // hostile만 있음
				} else if (hasFriendly) {
					settings.setFloatingPortrait_buff_filter(2); // friendly만 있음
				}
			} else {
				settings.setFloatingPortrait_buff_filter(3); // 둘다있음
			}
		} else {
			settings.setFloatingPortrait_buff_filter(0);
		}

		// 버프사이즈
		p = Pattern.compile("icon_size=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setFloatingPortrait_buff_size(Integer.parseInt(m.group(1)));
		}

		// 버프갭
		p = Pattern.compile("icon_spacing=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setFloatingPortrait_buff_spacing(Integer.parseInt(m.group(1)));
		}

		// 버프컬럼
		p = Pattern.compile("max_columns=\"(\\d+)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setFloatingPortrait_buff_column(Integer.parseInt(m.group(1)));
		}

		// 플로팅바스타일
		p = Pattern.compile("fg_gfx=\"\\.\\./\\.\\./Customized/gfx/floatingportrait/([^\"]+)\"");
		m = p.matcher(content);

		if (m.find()) {
			String fileName = m.group(1);
			Pattern numPattern = Pattern.compile("^s(\\d+)_");
			Matcher numMatcher = numPattern.matcher(fileName);
			if (numMatcher.find()) {
				settings.setFloatingPortrait_style(Integer.parseInt(numMatcher.group(1)));
			}
		}

		// 플로팅바컬러
		if (content.contains("hp_red"))
			settings.setFloatingPortrait_hp_color(1);
		else if (content.contains("_auqa"))
			settings.setFloatingPortrait_hp_color(2);
		else if (content.contains("_blue"))
			settings.setFloatingPortrait_hp_color(3);
		else if (content.contains("_grass"))
			settings.setFloatingPortrait_hp_color(4);
		else if (content.contains("_green"))
			settings.setFloatingPortrait_hp_color(5);
		else if (content.contains("_lemon"))
			settings.setFloatingPortrait_hp_color(6);
		else if (content.contains("_orange"))
			settings.setFloatingPortrait_hp_color(7);
		else if (content.contains("_peach"))
			settings.setFloatingPortrait_hp_color(8);
		else if (content.contains("_pink"))
			settings.setFloatingPortrait_hp_color(9);
		else if (content.contains("_purple"))
			settings.setFloatingPortrait_hp_color(10);
		else if (content.contains("_sky"))
			settings.setFloatingPortrait_hp_color(11);
		else if (content.contains("_vanilla"))
			settings.setFloatingPortrait_hp_color(12);
		else if (content.contains("_white"))
			settings.setFloatingPortrait_hp_color(13);
		else if (content.contains("_wine"))
			settings.setFloatingPortrait_hp_color(14);
		else if (content.contains("_yellow"))
			settings.setFloatingPortrait_hp_color(15);

		// 플로팅바 두꼐
		p = Pattern.compile(
				"<ProgressBar[^>]*name=\"HealthBar\"[\\s\\S]*?max_size_limit=\"Point\\((\\d+),(\\d+)\\)\"[\\s\\S]*?>",
				Pattern.CASE_INSENSITIVE);
		m = p.matcher(content);

		if (m.find()) {
			int width = Integer.parseInt(m.group(1));
			int height = Integer.parseInt(m.group(2));

			settings.setFloatingPortrait_hp_thickness(height);
		}

	}

	public static void writeFloatingPortraitView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/FloatingPortraitView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String fp_hp_left_margin = "";
		String fp_hp_right_margin = "";
		String fp_debuff_layout_x1 = "0";
		String fp_debuff_layout_x2 = "0";
		String fp_debuff_layout_y1 = "0";

		content = content.replaceAll("var_style", "s" + String.valueOf(settings.getFloatingPortrait_style()) + "_");

		if (settings.getFloatingPortrait_style() == 1) {
			settings.setFloatingPortrait_show_mana(false);
			content = content.replaceAll("var_nameplate_margin", " layout_borders=\"Rect(0,0,0,-3)\"");
			if (settings.getFloatingPortrait_hp_thickness() == 33) {
				content = content.replaceAll("var_hp_thickness", "");
			}
			content = content.replaceAll("var_hp_thickness", "max_size_limit=\"Point(218,"
					+ String.valueOf(settings.getFloatingPortrait_hp_thickness()) + ")\"");
			fp_hp_left_margin = "left_margin=\"3\"";
			fp_hp_right_margin = "right_margin=\"3\"";

			fp_debuff_layout_x1 = "4";
			fp_debuff_layout_x2 = "4";
			fp_debuff_layout_y1 = "0";
		} else {
			content = content.replaceAll("var_nameplate_margin", "");
			content = content.replaceAll("var_hp_thickness", "");

			fp_debuff_layout_x1 = "0";
			fp_debuff_layout_x2 = "0";
			fp_debuff_layout_y1 = "1";
		}

		content = content.replaceAll("var_hp_left_margin", fp_hp_left_margin);
		content = content.replaceAll("var_hp_right_margin", fp_hp_right_margin);

		// 디법창
		if (settings.getFloatingPortrait_buff_filter() == 0) {
			content = content.replaceAll("var_buff_view", "");
		} else if (settings.getFloatingPortrait_buff_filter() == 1) {
			content = content.replaceAll("var_buff_view",
					"<BuffListView name=\"BuffListView\"\r\n" + "		layout_borders=\"Rect(" + fp_debuff_layout_x1
							+ "," + fp_debuff_layout_y1 + "," + fp_debuff_layout_x2 + ",0)\"\r\n"
							+ "		h_local_alignment=\"LEFT\"\r\n" + "		filter=\"hostile\"\r\n"
							+ "		icon_size=\"Point(" + String.valueOf(settings.getFloatingPortrait_buff_size()) + ","
							+ String.valueOf(settings.getFloatingPortrait_buff_size()) + ")\"\r\n"
							+ "		full_size_limit=\"0\"\r\n" + "		icon_spacing=\"Point("
							+ String.valueOf(settings.getFloatingPortrait_buff_spacing()) + ","
							+ String.valueOf(settings.getFloatingPortrait_buff_spacing()) + ")\"\r\n"
							+ "		max_columns=\"" + settings.getFloatingPortrait_buff_column() + "\"\r\n" + "	/>");
		}

		// 네임플레이트알파
		if (settings.getNameplate_alpha() == 1.0) {
			content = content.replaceAll("var_nameplate_alpha", "");
		} else {
			content = content.replaceAll("var_nameplate_alpha",
					" view_local_alpha=\"" + String.valueOf(settings.getNameplate_alpha()) + "\"");
		}
		// 바알파
		if (settings.getFloatingPortrait_bar_alpha() == 1.0) {
			content = content.replaceAll("var_bar_alpha", "");
		} else {
			content = content.replaceAll("var_bar_alpha",
					" view_alpha=\"" + String.valueOf(settings.getFloatingPortrait_bar_alpha()) + "\"");
		}

		if (settings.isFloatingPortrait_show_mana()) {
			content = content.replaceAll("var_mana_template",
					"<template:ProgressBar template:name=\"ManaBarShort\"\r\n"
							+ "		bg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "mana_short_bg.png\"\r\n"
							+ "		fg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "mana_short.png\"\r\n"
							+ "	/>\r\n" + "	<template:ProgressBar template:name=\"ManaBarLong\"\r\n"
							+ "		bg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "mana_bg.png\"\r\n"
							+ "		fg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "mana.png\"\r\n" + "	/>\r\n"
							+ "	<template:ProgressBar template:name=\"StaminaBarShort\"\r\n"
							+ "		bg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "stam_short_bg.png\"\r\n"
							+ "		fg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "stam_short.png\"\r\n"
							+ "	/>\r\n" + "	<template:ProgressBar template:name=\"StaminaBarLong\"\r\n"
							+ "		bg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "stam_bg.png\"\r\n"
							+ "		fg_gfx=\"../../Customized/gfx/floatingportrait/" + "s"
							+ String.valueOf(settings.getFloatingPortrait_style()) + "_" + "stam.png\"\r\n" + "	/>");
			content = content.replaceAll("var_mana_bar", "<View view_layout=\"horizontal\">\r\n"
					+ "			<ProgressBar name=\"StaminaBar\"\r\n" + "				flash_on_reduce=\"false\"\r\n"
					+ "				view_flags=\"WID_IGNORE_WHEN_HIDDEN\"\r\n"
					+ "				label_color=\"#000000\"\r\n" + "				label_offset=\"Point(0,15)\"\r\n"
					+ "			/>\r\n" + "			<ProgressBar name=\"ManaBar\"\r\n"
					+ "				flash_on_reduce=\"false\"\r\n"
					+ "				view_flags=\"WID_IGNORE_WHEN_HIDDEN\"\r\n"
					+ "				label_color=\"#000000\"\r\n" + "				label_offset=\"Point(0,15)\"\r\n"
					+ "			/>\r\n" + "		</View>");
		} else {
			content = content.replaceAll("var_mana_template", "");
			content = content.replaceAll("var_mana_bar", "");
		}

		String fp_hp_color = new String("");
		if (settings.getFloatingPortrait_style() == 1) {
			if (settings.getFloatingPortrait_hp_color() == 1)
				fp_hp_color = "_red";
			else if (settings.getFloatingPortrait_hp_color() == 2)
				fp_hp_color = "_aqua";
			else if (settings.getFloatingPortrait_hp_color() == 3)
				fp_hp_color = "_blue";
			else if (settings.getFloatingPortrait_hp_color() == 4)
				fp_hp_color = "_grass";
			else if (settings.getFloatingPortrait_hp_color() == 5)
				fp_hp_color = "_green";
			else if (settings.getFloatingPortrait_hp_color() == 6)
				fp_hp_color = "_lemon";
			else if (settings.getFloatingPortrait_hp_color() == 7)
				fp_hp_color = "_orange";
			else if (settings.getFloatingPortrait_hp_color() == 8)
				fp_hp_color = "_peach";
			else if (settings.getFloatingPortrait_hp_color() == 9)
				fp_hp_color = "_pink";
			else if (settings.getFloatingPortrait_hp_color() == 10)
				fp_hp_color = "_purple";
			else if (settings.getFloatingPortrait_hp_color() == 11)
				fp_hp_color = "_sky";
			else if (settings.getFloatingPortrait_hp_color() == 12)
				fp_hp_color = "_vanilla";
			else if (settings.getFloatingPortrait_hp_color() == 13)
				fp_hp_color = "_white";
			else if (settings.getFloatingPortrait_hp_color() == 14)
				fp_hp_color = "_wine";
			else if (settings.getFloatingPortrait_hp_color() == 15)
				fp_hp_color = "_yellow";
		}

		content = content.replaceAll("var_color", fp_hp_color);

		int fp_nameplate_height = 18;

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			if (settings.getFloatingPortrait_style() == 1) {
				fp_nameplate_height = 17;
			}
			content = content.replaceAll("var_name_margin", " layout_borders=\"Rect(0,0,0,0)\"");
		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_name_margin", " layout_borders=\"Rect(0,-1,0,0)\"");
		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_name_margin", " layout_borders=\"Rect(0,-2,0,0)\"");
		}

		if (fp_nameplate_height == 18) {
			content = content.replaceAll("var_nameplate_size", "");
		} else {
			content = content.replaceAll("var_nameplate_size",
					" max_size_limit=\"Point(210," + String.valueOf(fp_nameplate_height) + ")\"");
		}

		// 체력바 폰트 볼드
		if (settings.isHPLabelBold()) {
			content = content.replaceAll("var_label_font", "label_font=\"NORMAL_BOLD\"");
		} else {
			content = content.replaceAll("var_label_font", "");
		}

		// HP 라벨 컬러(밝기)
		content = content.replaceAll("var_label_color", HexConverter.intToHex(settings.getHPLabelBrightness()));

		FileManager.stringToFile(targetDir, content);

	}
}
