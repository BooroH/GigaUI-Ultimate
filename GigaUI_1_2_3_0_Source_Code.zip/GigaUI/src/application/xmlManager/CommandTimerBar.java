package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;

public class CommandTimerBar {

	public static void readCommandTimerBar(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/CommandTimerBar.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		if (content.contains("s2_")) {
			settings.setCastBar_style(2);
		} else {
			settings.setCastBar_style(1);

			// 텍스트위치
			if (content.contains("_top")) {
				settings.setCastBar_text_location(1);
			} else if (content.contains("_mid")) {
				settings.setCastBar_text_location(2);
			} else if (content.contains("_bot")) {
				settings.setCastBar_text_location(3);
			}

			// 색깔
			if (content.contains("_yellow"))
				settings.setCastBar_color(1);
			else if (content.contains("_aqua"))
				settings.setCastBar_color(2);
			else if (content.contains("_blue"))
				settings.setCastBar_color(3);
			else if (content.contains("_grass"))
				settings.setCastBar_color(4);
			else if (content.contains("_green"))
				settings.setCastBar_color(5);
			else if (content.contains("_lemon"))
				settings.setCastBar_color(6);
			else if (content.contains("_orange"))
				settings.setCastBar_color(7);
			else if (content.contains("_peach"))
				settings.setCastBar_color(8);
			else if (content.contains("_pink"))
				settings.setCastBar_color(9);
			else if (content.contains("_purple"))
				settings.setCastBar_color(10);
			else if (content.contains("_sky"))
				settings.setCastBar_color(11);
			else if (content.contains("_vanilla"))
				settings.setCastBar_color(12);
			else if (content.contains("_white"))
				settings.setCastBar_color(13);
			else if (content.contains("_wine"))
				settings.setCastBar_color(14);

		}

		// 캐스팅바 알파값추출
		settings.setCastBar_alpha(1.0);
		p = Pattern.compile("view_alpha=\"([0-9]*\\.?[0-9]+)\"");
		m = p.matcher(content);

		if (m.find()) {
			double alpha = Double.parseDouble(m.group(1));
			settings.setCastBar_alpha(alpha);
		}

	}

	public static void writeCommandTimerBar(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/CommandTimerBar.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 캐스팅바
		String castBar_colorname = "";
		String castBar_Stylename = "";
		String castBarTextLocation = ""; // 탑인지 바텀인지
		String castBarTextLayout = "";
		String castBarBgThickness = "";
		String castBar_left_margin = "";
		String castBar_right_margin = "";
		String alignment = "";
		if (settings.getCastBar_style() == 1) {
			castBar_left_margin = "left_margin=\"3\"";
			castBar_right_margin = "right_margin=\"3\"";
			if (settings.getCastBar_text_location() == 1) {
				castBarTextLocation = "_top";
				alignment = " v_alignment=\"TOP\"";
				if(settings.getFontSize()==1)
					castBarTextLayout = "layout_borders=\"Rect(0,-2,0,0)\"";
				else if(settings.getFontSize()==2)
					castBarTextLayout = "layout_borders=\"Rect(0,-2,0,0)\"";
			} else if (settings.getCastBar_text_location() == 2) {
				castBarTextLocation = "_mid";
			} else if (settings.getCastBar_text_location() == 3) {
				castBarTextLocation = "_bot";
				alignment = " v_alignment=\"BOTTOM\"";
				if(settings.getFontSize()==0)
					castBarTextLayout = "layout_borders=\"Rect(0,0,0,-2)\"";
				else if(settings.getFontSize()==1)
					castBarTextLayout = "layout_borders=\"Rect(0,0,0,-3)\"";
				else if(settings.getFontSize()==2)
					castBarTextLayout = "layout_borders=\"Rect(0,0,0,-4)\"";
			}

			// 색깔
			if (settings.getCastBar_color() == 1)
				castBar_colorname = "_yellow";
			else if (settings.getCastBar_color() == 2)
				castBar_colorname = "_aqua";
			else if (settings.getCastBar_color() == 3)
				castBar_colorname = "_blue";
			else if (settings.getCastBar_color() == 4)
				castBar_colorname = "_grass";
			else if (settings.getCastBar_color() == 5)
				castBar_colorname = "_green";
			else if (settings.getCastBar_color() == 6)
				castBar_colorname = "_lemon";
			else if (settings.getCastBar_color() == 7)
				castBar_colorname = "_orange";
			else if (settings.getCastBar_color() == 8)
				castBar_colorname = "_peach";
			else if (settings.getCastBar_color() == 9)
				castBar_colorname = "_pink";
			else if (settings.getCastBar_color() == 10)
				castBar_colorname = "_purple";
			else if (settings.getCastBar_color() == 11)
				castBar_colorname = "_sky";
			else if (settings.getCastBar_color() == 12)
				castBar_colorname = "_vanilla";
			else if (settings.getCastBar_color() == 13)
				castBar_colorname = "_white";
			else if (settings.getCastBar_color() == 14)
				castBar_colorname = "_wine";

		} else if (settings.getCastBar_style() == 2) {
			castBar_Stylename = "s2_";
		}

		content = content.replaceAll("var_left_margin", castBar_left_margin);
		content = content.replaceAll("var_right_margin", castBar_right_margin);

		// 캐스팅바 알파
		if (settings.getCastBar_alpha() == 1.0) {
			content = content.replaceAll("var_bar_alpha", "");
		} else {
			content = content.replaceAll("var_bar_alpha",
					"view_alpha=\"" + String.valueOf(settings.getCastBar_alpha()) + "\"");
		}

		content = content.replaceAll("var_color", castBar_colorname);
		content = content.replaceAll("var_castbar_style", castBar_Stylename);
		content = content.replaceAll("var_text_location", castBarTextLocation);
		content = content.replaceAll("var_name_position", castBarTextLayout);
		content = content.replaceAll("var_bg_thickness", castBarBgThickness);
		content = content.replaceAll("var_alignment", alignment);

		FileManager.stringToFile(targetDir, content);

	}
}
