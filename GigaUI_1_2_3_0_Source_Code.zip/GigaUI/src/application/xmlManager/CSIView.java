package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class CSIView {

	public static void readCSIView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/ComboSequenceIndicator/CSIView.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		if (content.contains("dir_h.png")) {
			settings.setIsCSIHorizontal(1);
		} else {
			settings.setIsCSIHorizontal(0);
		}

	}

	public static void writeCSIView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/ComboSequenceIndicator/CSIView.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String csi_layout;
		String csi_dir_type;
		String csi_inner_borders_x;
		String csi_inner_borders_y;
		String csi_last_img;

		if (settings.getIsCSIHorizontal() == 0) {
			csi_layout = new String("vertical");
			csi_dir_type = new String("v");
			csi_inner_borders_x = new String("0");
			csi_inner_borders_y = new String("6");
			csi_last_img = new String("bottom");
		} else {
			csi_layout = new String("horizontal");
			csi_dir_type = new String("h");
			csi_inner_borders_x = new String("6");
			csi_inner_borders_y = new String("0");
			csi_last_img = new String("right");
		}

		content = content.replaceAll("var_csi_layout", csi_layout);
		content = content.replaceAll("var_csi_type", csi_dir_type);
		content = content.replaceAll("var_csi_inner_borders_x", csi_inner_borders_x);
		content = content.replaceAll("var_csi_inner_borders_y", csi_inner_borders_y);
		content = content.replaceAll("var_csi_last_img", csi_last_img);

		FileManager.stringToFile(targetDir, content);
	}
}
