package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CSIWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider csiSlider;
	private Label csiLabel;

	private Button okButton;
	private Button backButton;

	public CSIWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}
	
	@Override
	protected void initComponents() {
		int csiType = manager.getSettings().getIsCSIHorizontal();
		
		csiSlider = createSlider(0, 1, csiType, 1, 100);
		csiLabel = new Label("");
		
		if(csiType==0)
			csiLabel.setText("Vertical");
		else if(csiType==1)
			csiLabel.setText("Horizontal");
	}

	@Override
	protected Parent createView() {
		BorderPane root = new BorderPane();

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));

		HBox csiBox = new HBox(10, new Label("Combo Sequencer Type"), csiSlider, csiLabel);

		backButton = new Button("Back");
		okButton = new Button("OK");

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		centerBox.getChildren().addAll(csiBox);

		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		csiSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			csiSlider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				csiLabel.setText("Vertical");
			else if(newVal.intValue()==1)
				csiLabel.setText("Horizontal");
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setIsCSIHorizontal((int)csiSlider.getValue());
			manager.showAdvanced(stage);
		});
	}
	
	@Override
	protected double getWidth() {
		return 450;
	}

	@Override
	protected double getHeight() {
		return 250;
	}

	@Override
	protected String getTitle() {
		return "Combo Sequencer";
	}

}