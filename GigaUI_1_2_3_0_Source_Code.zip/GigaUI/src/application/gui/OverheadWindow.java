package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class OverheadWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider hpSizeSlider;
	private Label hpSizeLabel;
	private Slider hpColorSlider;
	private Label hpColorLabel;
	private Slider hpAlphaSlider;
	private Label hpAlphaLabel;
	private Slider fontWeightSlider;
	private Label fontWeightLabel;
	private Slider fontSizeSlider;
	private Label fontSizeLabel;

	private Button okButton;
	private Button backButton;

	public OverheadWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int hpSize = manager.getSettings().getOverheadHPSize();
		int hpColor = manager.getSettings().getOverheadHPColor();
		int hpAlpha = (int) (manager.getSettings().getOverheadHPAlpha() * 100);
		String fontWeight = manager.getSettings().getOverheadFontWeight();
		int fontSize = manager.getSettings().getOverheadFontSize();

		int weightNum = 2;
		fontWeightLabel = new Label("");
		if (fontWeight.equals("GG Regular")) {
			weightNum = 1;
			fontWeightLabel.setText("Regular");
		} else if (fontWeight.equals("GG Medium")) {
			weightNum = 2;
			fontWeightLabel.setText("Medium");
		} else if (fontWeight.equals("GG Bold")) {
			weightNum = 3;
			fontWeightLabel.setText("Bold");
		} else if (fontWeight.equals("GG Comic Black")) {
			weightNum = 4;
			fontWeightLabel.setText("Black");
		}

		hpSizeSlider = createSlider(1, 2, hpSize, 1, 100);
		hpSizeLabel = new Label(String.valueOf(hpSize));

		hpColorSlider = createSlider(1, 14, hpColor, 1, 300);
		hpColorLabel = new Label("");

		hpAlphaSlider = createSlider(80, 100, hpAlpha, 1, 300);
		hpAlphaLabel = new Label(String.valueOf(hpAlpha));

		fontWeightSlider = createSlider(1, 4, weightNum, 1, 150);

		fontSizeSlider = createSlider(32, 48, fontSize, 1, 300);
		fontSizeLabel = new Label(String.valueOf(fontSize));

		if (hpColor == 1)
			hpColorLabel.setText("Red");
		else if (hpColor == 2)
			hpColorLabel.setText("Aqua");
		else if (hpColor == 3)
			hpColorLabel.setText("Blue");
		else if (hpColor == 4)
			hpColorLabel.setText("Grass");
		else if (hpColor == 5)
			hpColorLabel.setText("Green");
		else if (hpColor == 16)
			hpColorLabel.setText("Lemon");
		else if (hpColor == 7)
			hpColorLabel.setText("Orange");
		else if (hpColor == 8)
			hpColorLabel.setText("Peach");
		else if (hpColor == 9)
			hpColorLabel.setText("Pink");
		else if (hpColor == 10)
			hpColorLabel.setText("Purple");
		else if (hpColor == 11)
			hpColorLabel.setText("Sky");
		else if (hpColor == 12)
			hpColorLabel.setText("Vanilla");
		else if (hpColor == 13)
			hpColorLabel.setText("White");
		else if (hpColor == 14)
			hpColorLabel.setText("Wine");


		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox hpSizeBox = new HBox(10, new Label("Size"), hpSizeSlider, hpSizeLabel);
		HBox hpColorBox = new HBox(10, new Label("Color"), hpColorSlider, hpColorLabel);
		HBox hpAlphaBox = new HBox(10, new Label("Alpha"), hpAlphaSlider, hpAlphaLabel);
		HBox fontWeightBox = new HBox(10, new Label("Weight"), fontWeightSlider, fontWeightLabel);
		HBox fontSizeBox = new HBox(10, new Label("Size"), fontSizeSlider, fontSizeLabel);

		Label textLabel = new Label("TEXT");
		VBox.setMargin(textLabel, new Insets(20, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(new Label("HEALTH BAR"), hpSizeBox, hpColorBox, hpAlphaBox, textLabel,
				fontWeightBox, fontSizeBox);

		Region spacer = new Region();
		HBox.setHgrow(spacer, Priority.ALWAYS);
		HBox bottomButtons = new HBox(10, new Label("Restart the game to apply change"), spacer, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);
		
		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		hpColorSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			hpColorSlider.setValue(newVal.intValue());

			if (newVal.intValue() == 1)
				hpColorLabel.setText("Red");
			else if (newVal.intValue() == 2)
				hpColorLabel.setText("Aqua");
			else if (newVal.intValue() == 3)
				hpColorLabel.setText("Blue");
			else if (newVal.intValue() == 4)
				hpColorLabel.setText("Grass");
			else if (newVal.intValue() == 5)
				hpColorLabel.setText("Green");
			else if (newVal.intValue() == 16)
				hpColorLabel.setText("Lemon");
			else if (newVal.intValue() == 7)
				hpColorLabel.setText("Orange");
			else if (newVal.intValue() == 8)
				hpColorLabel.setText("Peach");
			else if (newVal.intValue() == 9)
				hpColorLabel.setText("Pink");
			else if (newVal.intValue() == 10)
				hpColorLabel.setText("Purple");
			else if (newVal.intValue() == 11)
				hpColorLabel.setText("Sky");
			else if (newVal.intValue() == 12)
				hpColorLabel.setText("Vanilla");
			else if (newVal.intValue() == 13)
				hpColorLabel.setText("White");
			else if (newVal.intValue() == 14)
				hpColorLabel.setText("Wine");

		});

		hpAlphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			hpAlphaSlider.setValue(newVal.intValue());
			hpAlphaLabel.setText(String.valueOf(newVal.intValue()));
		});
		fontWeightSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			fontWeightSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1) {
				fontWeightLabel.setText("Regular");
			} else if (newVal.intValue() == 2) {
				fontWeightLabel.setText("Medium");
			} else if (newVal.intValue() == 3) {
				fontWeightLabel.setText("Bold");
			} else if (newVal.intValue() == 4) {
				fontWeightLabel.setText("Black");
			}
		});
		fontSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			fontSizeSlider.setValue(newVal.intValue());
			fontSizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		hpSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			hpSizeSlider.setValue(newVal.intValue());
			hpSizeLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setOverheadHPSize((int) hpSizeSlider.getValue());
			manager.getSettings().setOverheadHPColor((int) hpColorSlider.getValue());
			manager.getSettings().setOverheadHPAlpha(hpAlphaSlider.getValue() / 100);
			String fontType = "GG Medium";
			if (((int) fontWeightSlider.getValue()) == 1) {
				fontType = "GG Regular";
			} else if (((int) fontWeightSlider.getValue()) == 2) {
				fontType = "GG Medium";
			} else if (((int) fontWeightSlider.getValue()) == 3) {
				fontType = "GG Bold";
			} else if (((int) fontWeightSlider.getValue()) == 4) {
				fontType = "GG Comic Black";
			}
			manager.getSettings().setOverheadFontWeight(fontType);
			manager.getSettings().setOverheadFontSize((int) fontSizeSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Overhead";
	}
}