package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;

public class MainSplitView {
	
	public static void readMainSplitView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MainGUI/MainSplitView.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		// <!-- Menu --> 위치 찾기
		int menuIndex = content.indexOf("<!-- Menu -->");

		if (menuIndex != -1) {

		    // Menu 이후 부분만 잘라냄
		    String menuSection = content.substring(menuIndex);

		    Pattern pattern = Pattern.compile(
		        "view_layout=\"([^\"]+)\".*?h_local_alignment=\"([^\"]+)\"",
		        Pattern.DOTALL
		    );

		    Matcher matcher = pattern.matcher(menuSection);

		    if (matcher.find()) {
		        String viewLayout = matcher.group(1);
		        String hAlign = matcher.group(2);
		        
		        if(viewLayout.equals("horizontal"))
		        	settings.setMenuIcon_horizontal(true);
		        else
		        	settings.setMenuIcon_horizontal(false);
		        
		        if(hAlign.equals("RIGHT"))
		        	settings.setMenuIcon_right(true);
		        else
		        	settings.setMenuIcon_right(false);
		    }
		}

	}

	public static void writeMainSplitView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MainGUI/MainSplitView.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 인벤토리 레이아웃별 사이드패널 사이즈
		int mainSplit_panel_size_x = 389;
		int mainSplit_panel_size_y = 644;
		if (settings.getInventory_layout() == 1) {
			mainSplit_panel_size_x = 389;
			mainSplit_panel_size_y = 644;
		} else if (settings.getInventory_layout() == 2) {
			mainSplit_panel_size_x = 405;
			mainSplit_panel_size_y = 684;
		} else if (settings.getInventory_layout() == 3) {
			mainSplit_panel_size_x = 413;
			mainSplit_panel_size_y = 674;
		}

		content = content.replaceAll("var_panel_size_x", String.valueOf(mainSplit_panel_size_x));
		content = content.replaceAll("var_panel_size_y", String.valueOf(mainSplit_panel_size_y));
		
		String menu_layout;
		String menu_location_h;
		String shop_layout_borders;
		String inventory_layout_borders;
		
		if(settings.isMenuIcon_horizontal()) {
			menu_layout="horizontal";
			shop_layout_borders="layout_borders=\"Rect(-2,0,0,0)\"";
		}
		else {
			menu_layout="vertical";
			shop_layout_borders="layout_borders=\"Rect(1,0,-1,0)\"";
		}
		
		if(!settings.isMenuIcon_right()) {
			menu_location_h="LEFT";
			if(settings.isMenuIcon_horizontal())
				inventory_layout_borders="layout_borders=\"Rect(2,0,-1,0)\"";
			else
				inventory_layout_borders="layout_borders=\"Rect(0,0,-1,1)\"";
		}
		else {
			menu_location_h="RIGHT";
			if(settings.isMenuIcon_horizontal())
				inventory_layout_borders="layout_borders=\"Rect(0,0,-1,0)\"";
			else
				inventory_layout_borders="layout_borders=\"Rect(0,0,-1,1)\"";
		}
		
		content = content.replaceAll("var_menu_layout", menu_layout);
		content = content.replaceAll("var_menu_location_h", menu_location_h);
		content = content.replaceAll("var_shop_layout_borders", shop_layout_borders);
		content = content.replaceAll("var_inventory_layout_borders", inventory_layout_borders);

		FileManager.stringToFile(targetDir, content);

	}

}
