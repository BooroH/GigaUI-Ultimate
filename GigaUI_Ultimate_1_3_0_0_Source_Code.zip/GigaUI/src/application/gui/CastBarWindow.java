package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CastBarWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider colorSlider;
	private Label colorLabel;
	private Slider textLocSlider;
	private Label textLocLabel;
	private Slider thicknessSlider;
	private Label thicknessLabel;
	private Slider alphaSlider;
	private Label alphaLabel;

	private Button okButton;
	private Button backButton;

	public CastBarWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int color = manager.getSettings().getCastBar_color();
		int textLoc = manager.getSettings().getCastBar_text_location();
		int thickness = manager.getSettings().getCastBar_thickness();
		int alpha = (int) (manager.getSettings().getCastBar_alpha() * 100);

		colorSlider = createSlider(1, 14, color, 1, 300);
		colorLabel = new Label("");

		textLocSlider = createSlider(1, 3, textLoc, 1, 120);
		textLocLabel = new Label("");

		thicknessSlider = createSlider(1, 3, thickness, 1, 100);
		thicknessLabel = new Label(String.valueOf(thickness));

		alphaSlider = createSlider(80, 100, alpha, 1, 300);
		alphaLabel = new Label(String.valueOf(alpha));

		if (textLoc == 1) {
			textLocLabel.setText("Top");

		} else if (textLoc == 2) {
			textLocLabel.setText("Inside");

			thicknessSlider.setDisable(true);
			thicknessLabel.setText("");
		} else if (textLoc == 3) {
			textLocLabel.setText("Bottom");

		}

		// 색깔
		if (color == 1)
			colorLabel.setText("Yellow");
		else if (color == 2)
			colorLabel.setText("Aqua");
		else if (color == 3)
			colorLabel.setText("Blue");
		else if (color == 4)
			colorLabel.setText("Grass");
		else if (color == 5)
			colorLabel.setText("Green");
		else if (color == 6)
			colorLabel.setText("Lemon");
		else if (color == 7)
			colorLabel.setText("Orange");
		else if (color == 8)
			colorLabel.setText("Peach");
		else if (color == 9)
			colorLabel.setText("Pink");
		else if (color == 10)
			colorLabel.setText("Purple");
		else if (color == 11)
			colorLabel.setText("Sky");
		else if (color == 12)
			colorLabel.setText("Vanilla");
		else if (color == 13)
			colorLabel.setText("White");
		else if (color == 14)
			colorLabel.setText("Wine");

		
		backButton = new Button("Back");
		okButton = new Button("OK");
		
	}

	@Override
	protected Parent createView() {
		HBox colorBox = new HBox(10, new Label("Color"), colorSlider, colorLabel);
		HBox textLocBox = new HBox(10, new Label("Text Location"), textLocSlider, textLocLabel);
		HBox thicknessBox = new HBox(10, new Label("Castbar Thickness"), thicknessSlider, thicknessLabel);
		HBox alphaBox = new HBox(10, new Label("Alpha"), alphaSlider, alphaLabel);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(colorBox, textLocBox, thicknessBox, alphaBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		alphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			alphaSlider.setValue(newVal.intValue());
			alphaLabel.setText(String.valueOf(newVal.intValue()));
		});
		textLocSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			textLocSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1) {
				textLocLabel.setText("Top");

				thicknessSlider.setDisable(false);
				thicknessLabel.setText(String.valueOf((int) thicknessSlider.getValue()));
			} else if (newVal.intValue() == 2) {
				textLocLabel.setText("Inside");

				thicknessSlider.setDisable(true);
				thicknessLabel.setText("");
			} else if (newVal.intValue() == 3) {
				textLocLabel.setText("Bottom");

				thicknessSlider.setDisable(false);
				thicknessLabel.setText(String.valueOf((int) thicknessSlider.getValue()));
			} else {
				textLocLabel.setText("");

				thicknessSlider.setDisable(true);
				thicknessLabel.setText("");
			}
		});
		colorSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			colorSlider.setValue(newVal.intValue());

			if (newVal.intValue() == 1)
				colorLabel.setText("Yellow");
			else if (newVal.intValue() == 2)
				colorLabel.setText("Aqua");
			else if (newVal.intValue() == 3)
				colorLabel.setText("Blue");
			else if (newVal.intValue() == 4)
				colorLabel.setText("Grass");
			else if (newVal.intValue() == 5)
				colorLabel.setText("Green");
			else if (newVal.intValue() == 6)
				colorLabel.setText("Lemon");
			else if (newVal.intValue() == 7)
				colorLabel.setText("Orange");
			else if (newVal.intValue() == 8)
				colorLabel.setText("Peach");
			else if (newVal.intValue() == 9)
				colorLabel.setText("Pink");
			else if (newVal.intValue() == 10)
				colorLabel.setText("Purple");
			else if (newVal.intValue() == 11)
				colorLabel.setText("Sky");
			else if (newVal.intValue() == 12)
				colorLabel.setText("Vanilla");
			else if (newVal.intValue() == 13)
				colorLabel.setText("White");
			else if (newVal.intValue() == 14)
				colorLabel.setText("Wine");

		});
		thicknessSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			thicknessSlider.setValue(newVal.intValue());
			thicknessLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setCastBar_color((int) colorSlider.getValue());
			manager.getSettings().setCastBar_text_location((int) textLocSlider.getValue());
			manager.getSettings().setCastBar_alpha(alphaSlider.getValue() / 100);
			manager.getSettings().setCastBar_thickness((int) thicknessSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Castbar";
	}

}
