package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class InventoryWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider sidePanelSizeSlider;
	private Label sidePanelSizeLabel;

	private Slider invenSlider;
	private Label invenLabel;

	private Slider traderSlider;
	private Label traderLabel;

	private Button okButton;
	private Button backButton;

	public InventoryWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int inven = manager.getSettings().getInventory_layout();
		int trader = manager.getSettings().getTrader_layout();
		int sidePanelSize;

		if (manager.getSettings().getSidePanelWidth() < 469) {
			sidePanelSize = 1;
		} else if (manager.getSettings().getSidePanelWidth() < 525) {
			sidePanelSize = 2;
		} else {
			sidePanelSize = 3;
		}
		sidePanelSizeSlider = createSlider(1, 3, sidePanelSize, 1, 200);
		sidePanelSizeLabel = new Label(String.valueOf(25 + 25 * sidePanelSize) + "%");

		invenSlider = createSlider(1, 3, inven, 1, 200);
		invenLabel = new Label("");

		traderSlider = createSlider(1, 2, trader, 1, 200);
		traderLabel = new Label("");

		if (inven == 1)
			invenLabel.setText("8 x 10");
		else if (inven == 2)
			invenLabel.setText("10 x 13");
		else if (inven == 3)
			invenLabel.setText("12 x 15");

		if (trader == 1)
			traderLabel.setText("10 x 5");
		else if (trader == 2)
			traderLabel.setText("15 x 7");

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox sidePanelSizeBox = new HBox(10, new Label("Size (beta)"), sidePanelSizeSlider, sidePanelSizeLabel);
		HBox invenBox = new HBox(10, new Label("Layout"), invenSlider, invenLabel);
		HBox traderBox = new HBox(10, new Label("Layout"), traderSlider, traderLabel);
		
		Label sidePanelLabel = new Label("Side Panel");
		Label InventoryLabel = new Label("Inventory");
		VBox.setMargin(InventoryLabel, new Insets(10, 0, 0, 0));
		Label TraderLabel = new Label("Trader");
		VBox.setMargin(TraderLabel, new Insets(10, 0, 0, 0));

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(sidePanelLabel, sidePanelSizeBox, InventoryLabel,invenBox, TraderLabel,traderBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		sidePanelSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			sidePanelSizeSlider.setValue(newVal.intValue());
			sidePanelSizeLabel.setText(String.valueOf(25 + 25 * newVal.intValue()) + "%");
		});
		invenSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			invenSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1)
				invenLabel.setText("8 x 10");
			else if (newVal.intValue() == 2)
				invenLabel.setText("10 x 13");
			else if (newVal.intValue() == 3)
				invenLabel.setText("12 x 15");
		});

		traderSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			traderSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1)
				traderLabel.setText("10 x 5");
			else if (newVal.intValue() == 2)
				traderLabel.setText("15 x 7");
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setInventory_layout((int) invenSlider.getValue());
			manager.getSettings().setTrader_layout((int) traderSlider.getValue());
			if ((int) sidePanelSizeSlider.getValue() == 1) {
				manager.getSettings().setSidePanelWidth(389);
			} else if ((int) sidePanelSizeSlider.getValue() == 2) {
				manager.getSettings().setSidePanelWidth(469);
			} else {
				manager.getSettings().setSidePanelWidth(525);
			}
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() {
		return 480;
	}

	@Override
	protected double getHeight() {
		return 360;
	}

	@Override
	protected String getTitle() {
		return "Side Panel & Inventory";
	}

}