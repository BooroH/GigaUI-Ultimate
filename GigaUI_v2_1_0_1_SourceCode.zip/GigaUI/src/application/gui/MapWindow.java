package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MapWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider minimapSlider;
	private Label minimapLabel;
	
	private Slider minimapSizeSlider;
	private Label minimapSizeLabel;
	
	private Slider minimalMapSlider;
	private Label minimalMapLabel;

	private Button okButton;
	private Button backButton;

	public MapWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int minimap = manager.getSettings().getShowMiniMap();
		int minimalMap = manager.getSettings().getIsSimpleMap();
		int minimapSize = manager.getSettings().getMinimap_size();
		
		minimapSlider = createSlider(0, 1, minimap, 1, 150);
		minimapLabel = new Label("");
		
		minimapSizeSlider = createSlider(228, 404, minimapSize, 2, 300);
		minimapSizeLabel = new Label(String.valueOf(minimapSize));
		
		minimalMapSlider = createSlider(0, 1, minimalMap, 1, 150);
		minimalMapLabel = new Label("");
		
		if(minimap==0)
			minimapLabel.setText("No");
		else if(minimap==1)
			minimapLabel.setText("Yes");
		
		if(minimalMap==0)
			minimalMapLabel.setText("No");
		else if(minimalMap==1)
			minimalMapLabel.setText("Yes");
		
		backButton = new Button("Back");
		okButton = new Button("OK");
	}
	
	@Override
	protected Parent createView() {
		HBox minimapBox = new HBox(10, new Label("Show Minimap"), minimapSlider, minimapLabel);
		HBox minimapSizeBox = new HBox(10, new Label("Minimap Size"), minimapSizeSlider, minimapSizeLabel);
		HBox minimalMapBox = new HBox(10, new Label("Minimal Map"), minimalMapSlider, minimalMapLabel);
		
		Label minimapLabel = new Label("Minimap");
		Label mapWindowLabel = new Label("Map Window");
		VBox.setMargin(mapWindowLabel, new Insets(20, 0, 0, 0));
		
		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(minimapLabel,minimapBox,minimapSizeBox,mapWindowLabel,minimalMapBox);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		minimapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			minimapSlider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				minimapLabel.setText("No");
			else if(newVal.intValue()==1)
				minimapLabel.setText("Yes");
		});
		minimapSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			minimapSizeSlider.setValue(newVal.intValue());
			minimapSizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		minimalMapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			minimalMapSlider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				minimalMapLabel.setText("No");
			else if(newVal.intValue()==1)
				minimalMapLabel.setText("Yes");
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setShowMiniMap((int)minimapSlider.getValue());
			manager.getSettings().setMinimap_size((int)minimapSizeSlider.getValue());
			manager.getSettings().setIsSimpleMap((int)minimalMapSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() { return 480; }  
	@Override
    protected double getHeight() { return 300; }  
	@Override
	protected String getTitle() {
		return "Map";
	}

}