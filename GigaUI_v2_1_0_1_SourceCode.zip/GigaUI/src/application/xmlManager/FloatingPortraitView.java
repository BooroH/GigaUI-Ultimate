package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;
import application.util.ImageManager;
import application.util.ImageManagerV2;

public class FloatingPortraitView {

	public static void readFloatingPortraitView(String customizedDir) {

		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/FloatingPortraitView.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		// 사이즈
		p = Pattern.compile(
				"<ProgressBar[^>]*name=\"HealthBar\"[\\s\\S]*?max_size_limit=\"Point\\((\\d+),(\\d+)\\)\"[\\s\\S]*?>",
				Pattern.CASE_INSENSITIVE);
		m = p.matcher(content);

		if (m.find()) {
			int width = Integer.parseInt(m.group(1));
			int height = Integer.parseInt(m.group(2));

			settings.setFloatingPortrait_width(width);
		}

		// floating portrait nameplate alpha값 추출
		settings.setNameplate_alpha(1.0);
		p = Pattern.compile("<BitmapView[^>]*nameplate[^>]*view_local_alpha=\"(\\d+(?:\\.\\d+)?)\"");
		m = p.matcher(content);

		if (m.find()) {
			String alphaValueStr = m.group(1);
			settings.setNameplate_alpha(Double.parseDouble(alphaValueStr));
		}

		// 바 알파값
		settings.setFloatingPortrait_bar_alpha(1.0);
		p = Pattern.compile("<View[^>]*name=\"StatBarsContainer\"[^>]*view_alpha=\"([0-9.]+)\"");
		m = p.matcher(content);

		if (m.find()) {
			String viewAlpha = m.group(1);
			settings.setFloatingPortrait_bar_alpha(Double.parseDouble(viewAlpha));
		}

		// 마나바
		if (content.contains("<ProgressBar name=\"ManaBar\""))
			settings.setFloatingPortrait_show_mana(true);
		else
			settings.setFloatingPortrait_show_mana(false);

		// 버프필터
		p = Pattern.compile("filter=\"([^\"]+)\"");
		m = p.matcher(content);

		if (content.contains("name=\"BuffListView\"")) {
			if (m.find()) {
				String filterValue = m.group(1); // 예: "friendly|hostile"

				boolean hasFriendly = filterValue.contains("friendly");
				boolean hasHostile = filterValue.contains("hostile");

				if (hasHostile && hasFriendly) {
					settings.setFloatingPortrait_buff_filter(3); // 둘다있음
				} else if (hasHostile) {
					settings.setFloatingPortrait_buff_filter(1); // hostile만 있음
				} else if (hasFriendly) {
					settings.setFloatingPortrait_buff_filter(2); // friendly만 있음
				}
			} else {
				settings.setFloatingPortrait_buff_filter(3); // 둘다있음
			}
		} else {
			settings.setFloatingPortrait_buff_filter(0);
		}

		// 버프사이즈
		p = Pattern.compile("icon_size=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setFloatingPortrait_buff_size(Integer.parseInt(m.group(1)));
		}

		// 버프갭
		p = Pattern.compile("icon_spacing=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setFloatingPortrait_buff_spacing(Integer.parseInt(m.group(1)));
		}

		// 버프컬럼
		p = Pattern.compile("max_columns=\"(\\d+)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setFloatingPortrait_buff_column(Integer.parseInt(m.group(1)));
		}

		p = Pattern.compile("fg_gfx=\"[^\"]*color_(\\d+)_(\\d+)_(\\d+)\\.png\"");
		m = p.matcher(content);

		if (m.find()) {
			double hue = Double.parseDouble(m.group(1));
			double chroma = Double.parseDouble(m.group(2));
			double lightness = Double.parseDouble(m.group(3));

			settings.setFloatingPortrait_hp_hue(hue);
			settings.setFloatingPortrait_hp_chroma(chroma);
			settings.setFloatingPortrait_hp_lightness(lightness);
		}

		// 다크모드 컬러
		p = Pattern
				.compile("bg_gfx=\"../../Customized/gfx/portrait/r_hp_bg[^\"]*_c_(-?\\d+)_(-?\\d+)_(-?\\d+)\\.png\"");
		m = p.matcher(content);

		if (m.find()) {
			int hue = Integer.parseInt(m.group(1));
			int chroma = Integer.parseInt(m.group(2));
			int lightness = Integer.parseInt(m.group(3));

			settings.setFloatingPortrait_bg_lightness(lightness);
		} else {
			settings.setFloatingPortrait_bg_lightness(0);
		}

	}

	public static void writeFloatingPortraitView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/FloatingPortraitView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		String fp_left_margin = "7";
		String fp_right_margin = "7";
		String hp_size = "";
		String mana_size = "";
		String nameplate_size = "";
		String layout_adjust = "28";
		String mana_template = "";
		String mana_bar = "";
		String buffListView = "";
		String label_color = "ffffff";
		String label_font = "";
		String nameplate_alpha = "";
		String bar_alpha = "";

		// bg 다크모드 컬러
		String bg_chroma_code = "";

		String hp_bg_souceImgDir = customizedDir + "/gfx/portrait/r_hp_bg.png";
		String hp_bg_customImgDir = customizedDir + "/gfx/portrait/r_hp_bg.png";

		String stam_bg_souceImgDir = customizedDir + "/gfx/portrait/r_stam_bg.png";
		String stam_bg_customImgDir = customizedDir + "/gfx/portrait/r_stam_bg.png";

		String stam_s_bg_souceImgDir = customizedDir + "/gfx/portrait/r_stam_s_bg.png";
		String stam_s_bg_customImgDir = customizedDir + "/gfx/portrait/r_stam_s_bg.png";

		String mana_s_bg_souceImgDir = customizedDir + "/gfx/portrait/r_mana_s_bg.png";
		String mana_s_bg_customImgDir = customizedDir + "/gfx/portrait/r_mana_s_bg.png";
		
		String nameplate_souceImgDir = customizedDir + "/gfx/portrait/nameplate.png";
		String nameplate_customImgDir = customizedDir + "/gfx/portrait/nameplate.png";

		if (settings.getFloatingPortrait_bg_lightness() == 0) {
			bg_chroma_code = "";
		} else {
			bg_chroma_code = "_c_0_0_" + String.valueOf(settings.getFloatingPortrait_bg_lightness());

			hp_bg_customImgDir = customizedDir + "/gfx/portrait/r_hp_bg" + bg_chroma_code + ".png";
			stam_bg_customImgDir = customizedDir + "/gfx/portrait/r_stam_bg" + bg_chroma_code + ".png";
			stam_s_bg_customImgDir = customizedDir + "/gfx/portrait/r_stam_s_bg" + bg_chroma_code + ".png";
			mana_s_bg_customImgDir = customizedDir + "/gfx/portrait/r_mana_s_bg" + bg_chroma_code + ".png";
			nameplate_customImgDir = customizedDir + "/gfx/portrait/nameplate"+bg_chroma_code+".png";

			ImageManagerV2.process(hp_bg_souceImgDir, hp_bg_customImgDir, 0, 0,
					settings.getFloatingPortrait_bg_lightness());
			ImageManagerV2.process(stam_bg_souceImgDir, stam_bg_customImgDir, 0, 0,
					settings.getFloatingPortrait_bg_lightness());
			ImageManagerV2.process(stam_s_bg_souceImgDir, stam_s_bg_customImgDir, 0, 0,
					settings.getFloatingPortrait_bg_lightness());
			ImageManagerV2.process(mana_s_bg_souceImgDir, mana_s_bg_customImgDir, 0, 0,
					settings.getFloatingPortrait_bg_lightness());
			ImageManagerV2.process(nameplate_souceImgDir, nameplate_customImgDir, 0, 0,
					settings.getFloatingPortrait_bg_lightness());
		}
		content = content.replaceAll("var_bg_chroma", bg_chroma_code);

		if (settings.getFloatingPortrait_width() == 209) {
			hp_size = "max_size_limit=\"Point(209,28)\"";
			mana_size = " max_size_limit=\"Point(209,15)\"";
			nameplate_size = " max_size_limit=\"Point(199,26)\"";
			fp_left_margin = "6";
			fp_right_margin = "6";
			layout_adjust = "24";
		} else if (settings.getFloatingPortrait_width() == 185) {
			hp_size = "max_size_limit=\"Point(185,24)\"";
			mana_size = " max_size_limit=\"Point(185,13)\"";
			nameplate_size = " max_size_limit=\"Point(177,26)\"";
			fp_left_margin = "5";
			fp_right_margin = "5";
			layout_adjust = "21";
		}

		if (settings.isFloatingPortrait_show_mana()) {
			mana_template = "<template:ProgressBar template:name = \"ManaBarShort\"\r\n"
					+ "		bg_gfx=\"../../Customized/gfx/portrait/r_mana_s_bg"+bg_chroma_code+".png\"\r\n"
					+ "		fg_gfx=\"../../Customized/gfx/portrait/r_mana_s.png\"\r\n" + "		left_margin=\"0\"\r\n"
					+ "		right_margin=\"" + fp_right_margin + "\"\r\n" + "	/>\r\n"
					+ "	<template:ProgressBar template:name = \"ManaBarLong\"\r\n"
					+ "		bg_gfx=\"../../Customized/gfx/portrait/r_stam_bg"+bg_chroma_code+".png\"\r\n"
					+ "		fg_gfx=\"../../Customized/gfx/portrait/r_mana.png\"\r\n" + "		left_margin=\""
					+ fp_left_margin + "\"\r\n" + "		right_margin=\"" + fp_right_margin + "\"\r\n" + "	/>\r\n"
					+ "	<template:ProgressBar template:name = \"StaminaBarShort\"\r\n"
					+ "		bg_gfx=\"../../Customized/gfx/portrait/r_stam_s_bg"+bg_chroma_code+".png\"\r\n"
					+ "		fg_gfx=\"../../Customized/gfx/portrait/r_stam_s.png\"\r\n" + "		left_margin=\""
					+ fp_left_margin + "\"\r\n" + "		right_margin=\"0\"\r\n" + "	/>\r\n"
					+ "	<template:ProgressBar template:name = \"StaminaBarLong\"\r\n"
					+ "		bg_gfx=\"../../Customized/gfx/portrait/r_stam_bg"+bg_chroma_code+".png\"\r\n"
					+ "		fg_gfx=\"../../Customized/gfx/portrait/r_stam.png\"\r\n" + "		left_margin=\""
					+ fp_left_margin + "\"\r\n" + "		right_margin=\"" + fp_right_margin + "\"\r\n" + "	/>";
			mana_bar = "<View view_layout=\"horizontal\" layout_borders=\"Rect(0," + layout_adjust + ",0,0)\""
					+ mana_size + ">\r\n" + "			<ProgressBar name=\"StaminaBar\"\r\n"
					+ "				flash_on_reduce=\"false\"\r\n" + "				slide_down_time=\"0.1\"\r\n"
					+ "				view_flags=\"WID_IGNORE_WHEN_HIDDEN\"\r\n"
					+ "				label_color=\"#000000\"\r\n" + "				label_offset=\"Point(0,20)\"\r\n"
					+ "			/>\r\n" + "			<ProgressBar name=\"ManaBar\"\r\n"
					+ "				flash_on_reduce=\"false\"\r\n" + "				slide_down_time=\"0.1\"\r\n"
					+ "				view_flags=\"WID_IGNORE_WHEN_HIDDEN\"\r\n"
					+ "				label_color=\"#000000\"\r\n" + "				label_offset=\"Point(0,20)\"\r\n"
					+ "			/>\r\n" + "		</View>";
		}

		// 디법창
		if (settings.getFloatingPortrait_buff_filter() == 1) {
			buffListView = "<BuffListView name=\"BuffListView\"\r\n" + "		layout_borders=\"Rect(5,0,0,0)\"\r\n"
					+ "		h_local_alignment=\"LEFT\"\r\n" + "		filter=\"hostile\"\r\n" + "		icon_size=\"Point("
					+ String.valueOf(settings.getFloatingPortrait_buff_size()) + ","
					+ String.valueOf(settings.getFloatingPortrait_buff_size()) + ")\"\r\n"
					+ "		full_size_limit=\"0\"\r\n" + "		icon_spacing=\"Point("
					+ String.valueOf(settings.getFloatingPortrait_buff_spacing()) + ","
					+ String.valueOf(settings.getFloatingPortrait_buff_spacing()) + ")\"\r\n" + "		max_columns=\""
					+ settings.getFloatingPortrait_buff_column() + "\"\r\n" + "	/>";
		}

		// 체력바 폰트 볼드
		if (settings.isHPLabelBold()) {
			label_font = "label_font=\"NORMAL_BOLD\"";
		}

		// 네임플레이트알파
		if (settings.getNameplate_alpha() == 1.0) {
			nameplate_alpha = "";
		} else {
			nameplate_alpha = " view_local_alpha=\"" + String.valueOf(settings.getNameplate_alpha()) + "\"";
		}
		// 바알파
		if (settings.getFloatingPortrait_bar_alpha() == 1.0) {
			bar_alpha = "";
		} else {
			bar_alpha = " view_alpha=\"" + String.valueOf(settings.getFloatingPortrait_bar_alpha()) + "\"";
		}

		// hp 텍스트 컬러
		label_color = HexConverter.intToHex(settings.getHPLabelBrightness());

		content = content.replaceAll("var_hp_size", hp_size);
		content = content.replaceAll("var_nameplate_size", nameplate_size);
		content = content.replaceAll("var_hp_left_margin", fp_left_margin);
		content = content.replaceAll("var_hp_right_margin", fp_right_margin);
		content = content.replaceAll("var_mana_template", mana_template);
		content = content.replaceAll("var_mana_bar", mana_bar);
		content = content.replaceAll("var_buff_view", buffListView);
		content = content.replaceAll("var_label_font", label_font);
		content = content.replaceAll("var_nameplate_alpha", nameplate_alpha);
		content = content.replaceAll("var_bar_alpha", bar_alpha);
		content = content.replaceAll("var_label_color", label_color);

		FileManager.stringToFile(targetDir, content);

	}
}
