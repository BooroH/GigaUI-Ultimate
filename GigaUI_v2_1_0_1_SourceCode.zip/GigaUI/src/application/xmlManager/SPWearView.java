package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class SPWearView {
	public static void writeSPWearView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MainGUI/SPWearView.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 사이드패널 사이즈별 아이콘 크기
		int sidePanelWidth = settings.getSidePanelWidth();
		int iconSize1;
		int iconSize2;
		if (sidePanelWidth < 469) {
			iconSize1 = 63;
			iconSize2 = 58;
		} else if (sidePanelWidth < 525) {
			iconSize1 = 73;
			iconSize2 = 68;
		} else {
			iconSize1 = 83;
			iconSize2 = 78;
		}

		content = content.replaceAll("var_icon_size_1", String.valueOf(iconSize1));
		content = content.replaceAll("var_icon_size_2", String.valueOf(iconSize2));

		FileManager.stringToFile(targetDir, content);

	}
}
