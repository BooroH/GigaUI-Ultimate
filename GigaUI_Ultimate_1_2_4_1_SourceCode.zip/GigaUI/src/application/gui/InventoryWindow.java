package application.gui;

import application.setting.Settings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class InventoryWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider invenSlider;
	private Label invenLabel;
	
	private Slider traderSlider;
	private Label traderLabel;

	private Button okButton;
	private Button backButton;

	public InventoryWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int inven = manager.getSettings().getInventory_layout();
		int trader = manager.getSettings().getTrader_layout();
		
		invenSlider = createSlider(1, 3, inven, 1, 140);
		invenLabel = new Label("");
		
		traderSlider = createSlider(1, 2, trader, 1, 140);
		traderLabel = new Label("");
		
		if(inven==1)
			invenLabel.setText("8x10");
		else if(inven==2)
			invenLabel.setText("10x13");
		else if(inven==3)
			invenLabel.setText("12x15");
		
		if(trader==1)
			traderLabel.setText("10x5");
		else if(trader==2)
			traderLabel.setText("15x7");
		
		backButton = new Button("Back");
		okButton = new Button("OK");
	}
	@Override
	protected Parent createView() {
		HBox invenBox = new HBox(10, new Label("Inventory Layout"), invenSlider, invenLabel);
		HBox traderBox = new HBox(10, new Label("Trader Layout"), traderSlider, traderLabel);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(invenBox, traderBox);
		
		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {	
		invenSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			invenSlider.setValue(newVal.intValue());
			if(newVal.intValue()==1)
				invenLabel.setText("8x10");
			else if(newVal.intValue()==2)
				invenLabel.setText("10x13");
			else if(newVal.intValue()==3)
				invenLabel.setText("12x15");
		});
		
		traderSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			traderSlider.setValue(newVal.intValue());
			if(newVal.intValue()==1)
				traderLabel.setText("10x5");
			else if(newVal.intValue()==2)
				traderLabel.setText("15x7");
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setInventory_layout((int)invenSlider.getValue());
			manager.getSettings().setTrader_layout((int)traderSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() { return 450; }  
	@Override
    protected double getHeight() { return 250; }  
	@Override
	protected String getTitle() {
		return "Inventory";
	}

}