package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class CharPortraitLeft {

	public static void readLeftPortrait(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/CharPortraitLeft.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		p = Pattern.compile("icon_size=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setLP_buff_size(Integer.parseInt(m.group(1)));
		}

		p = Pattern.compile("icon_spacing=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setLP_buff_spacing(Integer.parseInt(m.group(1)));
		}

		p = Pattern.compile("max_columns=\"(\\d+)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setLP_buff_column(Integer.parseInt(m.group(1)));
		}

		// leftportrait에서 체력바 폰트 볼드인지 확인
		if (content.contains("NORMAL_BOLD")) {
			settings.setHPLabelBold(true);
		} else {
			settings.setHPLabelBold(false);
		}

		// 체력폰트컬러추출
		p = Pattern.compile("<ProgressBar[^>]*name=\"HealthBar\"[\\s\\S]*?label_color=\"(#[0-9a-fA-F]{6})\"[\\s\\S]*?>",
				Pattern.CASE_INSENSITIVE);
		m = p.matcher(content);

		if (m.find()) {
			String colorCode = m.group(1);
			settings.setHPLabelBrightness(HexConverter.hexToInt(colorCode));
		}
	}

	public static void writeCharPortraitLeft(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/CharPortraitLeft.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		content = content.replaceAll("var_icon_size", String.valueOf(settings.getLP_buff_size()));
		content = content.replaceAll("var_icon_spacing", String.valueOf(settings.getLP_buff_spacing()));
		content = content.replaceAll("var_max_columns", String.valueOf(settings.getLP_buff_column()));

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,1)\"");
		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_label_offset", "");
		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,1)\"");
		}

		// 체력바 폰트 볼드
		if (settings.isHPLabelBold()) {
			content = content.replaceAll("var_label_font", "label_font=\"NORMAL_BOLD\"");
		} else {
			content = content.replaceAll("var_label_font", "");
		}

		// 체력폰트밝기
		content = content.replaceAll("var_label_color", HexConverter.intToHex(settings.getHPLabelBrightness()));
		
		FileManager.stringToFile(targetDir, content);
	}
}
