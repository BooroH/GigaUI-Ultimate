package application.gui;

import java.io.File;

import application.installer.Installer;
import application.setting.SettingManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class CustomWindow extends BaseWindow {
	private WindowManager manager;

	private Button saveButton;
	private Button backButton;
	private Button advancedButton;
	private Button importButton;
	private Button exportButton;

	private ToggleGroup resGroup;
	private RadioButton customButton;
	private RadioButton fhdButton;
	private RadioButton qhdButton;
	private RadioButton uhdButton;

	private ToggleGroup themeGroup;
	private RadioButton gigaThemeButton;
	private RadioButton darkThemeButton;

	public CustomWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		SettingManager.loadSettings(manager.getAoCDir());

		resGroup = new ToggleGroup();
		fhdButton = new RadioButton("1920x1080");
		qhdButton = new RadioButton("2560x1440 ");
		uhdButton = new RadioButton("3840x2160");
		customButton = new RadioButton("Custom");
		fhdButton.setToggleGroup(resGroup);
		qhdButton.setToggleGroup(resGroup);
		uhdButton.setToggleGroup(resGroup);
		customButton.setToggleGroup(resGroup);

		themeGroup = new ToggleGroup();
		gigaThemeButton = new RadioButton("Giga");
		darkThemeButton = new RadioButton("Dark");

		gigaThemeButton.setToggleGroup(themeGroup);
		darkThemeButton.setToggleGroup(themeGroup);

		importButton = new Button("Import");
		exportButton = new Button("Export");
		advancedButton = new Button("Advanced");
		backButton = new Button("Back");
		saveButton = new Button("Save");
	}

	@Override
	protected Parent createView() {
		Label quickSetup = new Label("Quick Setup");
		Label resLabel = new Label("Resolution");
		Label themeLabel = new Label("Theme");
		VBox.setMargin(themeLabel, new Insets(20, 0, 0, 0));

		VBox resBox = new VBox(10, fhdButton, qhdButton, uhdButton, customButton);
		HBox themeBox = new HBox(10, gigaThemeButton, darkThemeButton);

		HBox topRow = new HBox(10);
		topRow.setAlignment(Pos.CENTER_LEFT);
		Region spacer = new Region();
		HBox.setHgrow(spacer, Priority.ALWAYS);
		topRow.getChildren().addAll(quickSetup, spacer, importButton, exportButton);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(topRow, resLabel, resBox, themeLabel, themeBox);

		Region spacer2 = new Region();
		HBox.setHgrow(spacer2, Priority.ALWAYS);

		HBox bottomButtons = new HBox(10, advancedButton, spacer2, backButton, saveButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		resGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
			if (fhdButton.isSelected()) {
				SettingManager.loadProfile(new File("profile/fhd.txt"));
				gigaThemeButton.setSelected(true);
			} else if (qhdButton.isSelected()) {
				SettingManager.loadProfile(new File("profile/qhd.txt"));
				gigaThemeButton.setSelected(true);
			} else if (uhdButton.isSelected()) {
				SettingManager.loadProfile(new File("profile/uhd.txt"));
				gigaThemeButton.setSelected(true);
			} else {

			}
		});
		themeGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
			if (gigaThemeButton.isSelected()) {
				manager.getSettings().setSlot_bg_lightness(0);
				manager.getSettings().setCastbar_bg_lightness(0);
				manager.getSettings().setMainPortrait_bg_lightness(0);
				manager.getSettings().setFloatingPortrait_bg_lightness(0);
				manager.getSettings().setMinimap_bg_lightness(0);
				manager.getSettings().setCsi_bg_lightness(0);
				manager.getSettings().setSoulshard_bg_lightness(0);
				manager.getSettings().setWindows_bg_lightness(0);
			} else if (darkThemeButton.isSelected()) {
				manager.getSettings().setSlot_bg_lightness(-64);
				manager.getSettings().setCastbar_bg_lightness(-70);
				manager.getSettings().setMainPortrait_bg_lightness(-85);
				manager.getSettings().setFloatingPortrait_bg_lightness(-85);
				manager.getSettings().setMinimap_bg_lightness(-79);
				manager.getSettings().setCsi_bg_lightness(-67);
				manager.getSettings().setSoulshard_bg_lightness(-68);
				manager.getSettings().setWindows_bg_lightness(-67);
			} else {

			}
		});

		saveButton.setOnAction(e -> {
			if (Installer.runEditor(manager.getAoCDir())) {
				ShowAlert.showInfo("Complete", "Customizing Done");
			}
		});
		backButton.setOnAction(e -> {
			manager.showInstallTypeWindow();
		});
		importButton.setOnAction(e -> {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Import Profile");
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));

			// 🔹 초기 경로를 바탕화면으로 설정
			File desktopDir = new File(System.getProperty("user.home"), "Desktop");
			if (desktopDir.exists()) {
				fileChooser.setInitialDirectory(desktopDir);
			}

			File file = fileChooser.showOpenDialog(stage.getScene().getWindow());
			if (file != null) {
				if (SettingManager.loadProfile(file)) {
					customButton.setSelected(true);
					ShowAlert.showInfo("Complete", "Profile is successfully loaded");
				} else {
					ShowAlert.showError("Error", "Wrong file");
				}
			}
		});
		exportButton.setOnAction(e -> {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Export Settings");
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
			fileChooser.setInitialFileName("profile.txt");

			// 🔹 초기 경로를 바탕화면으로 설정
			File desktopDir = new File(System.getProperty("user.home"), "Desktop");
			if (desktopDir.exists()) {
				fileChooser.setInitialDirectory(desktopDir);
			}

			File file = fileChooser.showSaveDialog(stage.getScene().getWindow());
			if (file != null) {
				SettingManager.saveProfile(file);
				ShowAlert.showInfo("Complete", "Your profile has been successfully saved");
			}

		});
		advancedButton.setOnAction(e -> {
			customButton.setSelected(true);
			manager.showAdvanced();
		});
	}
}
