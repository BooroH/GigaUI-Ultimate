package application.xmlManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import application.setting.Settings;
import application.util.FileManager;
import application.util.HexConverter;

public class CharPortraitRight {

	public static void readRightPortrait(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/CharPortraitRight.xml";

		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		Matcher m;
		Pattern p;

		p = Pattern.compile("icon_size=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setRP_buff_size(Integer.parseInt(m.group(1)));
		}

		p = Pattern.compile("icon_spacing=\"Point\\((\\d+),(\\d+)\\)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setRP_buff_spacing(Integer.parseInt(m.group(1)));
		}

		p = Pattern.compile("max_columns=\"(\\d+)\"");
		m = p.matcher(content);
		if (m.find()) {
			settings.setRP_buff_column(Integer.parseInt(m.group(1)));
		}
		p = Pattern.compile("filter=\"([^\"]+)\"");
		m = p.matcher(content);

		if (content.contains("name=\"BuffListView\"")) {
			if (m.find()) {
				String filterValue = m.group(1); // 예: "friendly|hostile"

				boolean hasFriendly = filterValue.contains("friendly");
				boolean hasHostile = filterValue.contains("hostile");

				if (hasHostile && hasFriendly) {
					settings.setRP_buff_filter(3); // 둘다있음
				} else if (hasHostile) {
					settings.setRP_buff_filter(1); // hostile만 있음
				} else if (hasFriendly) {
					settings.setRP_buff_filter(2); // friendly만 있음
				}
			} else {
				settings.setRP_buff_filter(3); // 둘다있음
			}
		} else {
			settings.setRP_buff_filter(0);
		}

		// 타겟의타겟
		p = Pattern.compile("<View[^>]*name=\"TargetContainerView\"[^>]*>", Pattern.DOTALL);
		m = p.matcher(content);

		while (m.find()) {
			String targetBlock = m.group();

			Pattern borderPattern = Pattern.compile("layout_borders=\"Rect\\((\\d+),(\\d+),(\\d+),(\\d+)\\)\"");
			Matcher borderMatcher = borderPattern.matcher(targetBlock);

			while (borderMatcher.find()) {
				int left = Integer.parseInt(borderMatcher.group(1));
				int top = Integer.parseInt(borderMatcher.group(2));
				int right = Integer.parseInt(borderMatcher.group(3));
				int bottom = Integer.parseInt(borderMatcher.group(4));

				settings.setTargetOfTargetX(left - right);
				settings.setTargetOfTargetY(bottom);
			}
		}

		// 타겟의타겟 y1 (스탯바에서 추출)
		p = Pattern.compile("<BitmapView[^>]*name=\"StatBarsContainer\"[^>]*>", Pattern.DOTALL);
		m = p.matcher(content);

		while (m.find()) {
			String targetBlock = m.group();

			Pattern borderPattern = Pattern.compile("layout_borders=\"Rect\\((\\d+),(\\d+),(\\d+),(\\d+)\\)\"");
			Matcher borderMatcher = borderPattern.matcher(targetBlock);

			while (borderMatcher.find()) {
				int left = Integer.parseInt(borderMatcher.group(1));
				int top = Integer.parseInt(borderMatcher.group(2));
				int right = Integer.parseInt(borderMatcher.group(3));
				int bottom = Integer.parseInt(borderMatcher.group(4));

				settings.setTargetOfTargetYMinus(23-bottom);;
			}
		}

	}

	public static void writeCharPortraitRight(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/HUD/CharPortraitRight.xml";

		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// right portrait
		if (settings.getRP_buff_filter() == 0) {
			content = content.replaceAll("<BuffListView[^>]*/>", "");
		} else {
			content = content.replaceAll("var_icon_size", String.valueOf(settings.getRP_buff_size()));
			content = content.replaceAll("var_icon_spacing", String.valueOf(settings.getRP_buff_spacing()));
			content = content.replaceAll("var_max_columns", String.valueOf(settings.getRP_buff_column()));
			if (settings.getRP_buff_filter() == 1) {
				content = content.replaceAll("var_buff_filter", "hostile");
			} else if (settings.getRP_buff_filter() == 2) {
				content = content.replaceAll("var_buff_filter", "friendly");
			} else if (settings.getRP_buff_filter() == 3) {
				content = content.replaceAll("filter=\"[^\"]*\"", "");
			}
		}

		// 폰트사이즈별 최적화
		if (settings.getFontSize() == 0) {
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,-1)\"");
		} else if (settings.getFontSize() == 1) {
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,-2)\"");
		} else if (settings.getFontSize() == 2) {
			content = content.replaceAll("var_label_offset", "label_offset=\"Point(0,-1)\"");
		}

		// 체력바 폰트 볼드
		if (settings.isHPLabelBold()) {
			content = content.replaceAll("var_label_font", "label_font=\"NORMAL_BOLD\"");
		} else {
			content = content.replaceAll("var_label_font", "");
		}

		// HP 라벨 컬러(밝기)
		content = content.replaceAll("var_label_color", HexConverter.intToHex(settings.getHPLabelBrightness()));

		// 타겟의타겟
		if (settings.getTargetOfTargetX() < 0) {
			content = content.replaceAll("var_tt_x1", String.valueOf(0));
			content = content.replaceAll("var_tt_x2", String.valueOf(-settings.getTargetOfTargetX()));
		} else if (settings.getTargetOfTargetX() > 0) {
			content = content.replaceAll("var_tt_x1", String.valueOf(settings.getTargetOfTargetX()));
			content = content.replaceAll("var_tt_x2", String.valueOf(0));
		} else {
			content = content.replaceAll("var_tt_x1", String.valueOf(0));
			content = content.replaceAll("var_tt_x2", String.valueOf(0));
		}

		content = content.replaceAll("var_tt_y2", String.valueOf(settings.getTargetOfTargetY()));
		content = content.replaceAll("var_stat_y2", String.valueOf(23 - settings.getTargetOfTargetYMinus()));
		content = content.replaceAll("var_energy_y2", String.valueOf(28 - settings.getTargetOfTargetYMinus()));

		FileManager.stringToFile(targetDir, content);
	}
}
