package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class MapWindowSkin {

	public static void readMapWindowSkin(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MapGUI/MapWindowSkin.xml";
		
		String fullDir = customizedDir + defaultDir;
		String content = FileManager.fileToString(fullDir);

		// 심플맵
		if (content.contains("name=\"CoordinatesView\"")) {
			settings.setIsSimpleMap(0);
		} else {
			settings.setIsSimpleMap(1);
		}

	}

	public static void writeMapWindowSkin(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MapGUI/MapWindowSkin.xml";
		
		String sourceDir;
		String targetDir = customizedDir + defaultDir;

		if (settings.getIsSimpleMap() == 0) {
			sourceDir = "Data/format/Views/MapGUI/MapWindowSkins/DefaultMap/MapWindowSkin.xml";
		} else {
			sourceDir = "Data/format/Views/MapGUI/MapWindowSkins/MinimalMap/MapWindowSkin.xml";
		}

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 타이틀마진
		String mapTitleMargin = new String(String.valueOf(11 - settings.getFontSize()));
		content = content.replaceAll("var_title_margin", mapTitleMargin);

		FileManager.stringToFile(targetDir, content);

	}
}
