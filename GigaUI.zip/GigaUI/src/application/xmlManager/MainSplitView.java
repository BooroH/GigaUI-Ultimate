package application.xmlManager;

import application.setting.Settings;
import application.util.FileManager;

public class MainSplitView {

	public static void writeMainSplitView(String customizedDir) {
		Settings settings = Settings.getInstance();
		String defaultDir = "/Views/MainGUI/MainSplitView.xml";
		
		String sourceDir = "Data/format" + defaultDir;
		String targetDir = customizedDir + defaultDir;

		FileManager.copyFile(sourceDir, targetDir);
		String content = FileManager.fileToString(targetDir);

		// 인벤토리 레이아웃별 사이드패널 사이즈
		int mainSplit_panel_size_x = 389;
		int mainSplit_panel_size_y = 644;
		if (settings.getInventory_layout() == 1) {
			mainSplit_panel_size_x = 389;
			mainSplit_panel_size_y = 644;
		} else if (settings.getInventory_layout() == 2) {
			mainSplit_panel_size_x = 405;
			mainSplit_panel_size_y = 684;
		} else if (settings.getInventory_layout() == 3) {
			mainSplit_panel_size_x = 413;
			mainSplit_panel_size_y = 674;
		}

		content = content.replaceAll("var_panel_size_x", String.valueOf(mainSplit_panel_size_x));
		content = content.replaceAll("var_panel_size_y", String.valueOf(mainSplit_panel_size_y));

		FileManager.stringToFile(targetDir, content);

	}

}
