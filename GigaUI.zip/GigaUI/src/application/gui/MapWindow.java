package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MapWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider minimapSlider;
	private Label minimapLabel;
	
	private Slider minimalMapSlider;
	private Label minimalMapLabel;

	private Button okButton;
	private Button backButton;

	public MapWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int minimap = manager.getSettings().getShowMiniMap();
		int minimalMap = manager.getSettings().getIsSimpleMap();
		
		minimapSlider = createSlider(0, 1, minimap, 1, 130);
		minimapLabel = new Label("");
		
		minimalMapSlider = createSlider(0, 1, minimalMap, 1, 130);
		minimalMapLabel = new Label("");
		
		if(minimap==0)
			minimapLabel.setText("No");
		else if(minimap==1)
			minimapLabel.setText("Yes");
		
		if(minimalMap==0)
			minimalMapLabel.setText("No");
		else if(minimalMap==1)
			minimalMapLabel.setText("Yes");
		
		backButton = new Button("Back");
		okButton = new Button("OK");
	}
	
	@Override
	protected Parent createView() {
		HBox minimapBox = new HBox(10, new Label("Show Minimap"), minimapSlider, minimapLabel);
		HBox minimalMapBox = new HBox(10, new Label("Minimal Map"), minimalMapSlider, minimalMapLabel);
		
		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(minimapBox,minimalMapBox);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		minimapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			minimapSlider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				minimapLabel.setText("No");
			else if(newVal.intValue()==1)
				minimapLabel.setText("Yes");
		});
		
		minimalMapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			minimalMapSlider.setValue(newVal.intValue());
			if(newVal.intValue()==0)
				minimalMapLabel.setText("No");
			else if(newVal.intValue()==1)
				minimalMapLabel.setText("Yes");
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setShowMiniMap((int)minimapSlider.getValue());
			manager.getSettings().setIsSimpleMap((int)minimalMapSlider.getValue());
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected double getWidth() { return 450; }  
	@Override
    protected double getHeight() { return 250; }  
	@Override
	protected String getTitle() {
		return "Map";
	}

}