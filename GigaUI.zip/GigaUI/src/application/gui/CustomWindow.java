package application.gui;

import java.io.File;

import application.installer.Installer;
import application.setting.SettingManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class CustomWindow extends BaseWindow {
	private WindowManager manager;

	private Slider slotSizeSlider;
	private Label slotSizeLabel;

	private Slider rowSlider;
	private Label rowLabel;

	private Slider colSlider;
	private Label colLabel;

	private Slider gapSlider;
	private Label gapLabel;

	private Slider moveYSlider;
	private Label moveYLabel;

	private CheckBox hideEmptySlotCheckBox;

	private Button saveButton;
	private Button backButton;
	private Button advancedButton;
	private Button importButton;
	private Button exportButton;

	public CustomWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		SettingManager.loadSettings(manager.getAoCDir());

		int row = manager.getSettings().getBottomBar_row();
		int col = manager.getSettings().getBottomBar_column();
		int slotSize = manager.getSettings().getSlot_size();
		int gap = manager.getSettings().getIcon_spacing();
		int moveY = manager.getSettings().getBottomBar_Pos_Y();

		rowSlider = createSlider(2, 3, row, 1, 90);
		rowLabel = new Label(String.valueOf(row));

		colSlider = createSlider(15, 29, col, 2, 300);
		colLabel = new Label(String.valueOf(col));

		slotSizeSlider = createSlider(51, 65, slotSize, 2, 400);
		slotSizeLabel = new Label(String.valueOf(slotSize));

		gapSlider = createSlider(-7, 0, gap, 1, 400);
		gapLabel = new Label(String.valueOf(gap));

		moveYSlider = createSlider(0, 800, moveY, 1, 400);
		moveYLabel = new Label(String.valueOf(moveY));

		hideEmptySlotCheckBox = new CheckBox();
		hideEmptySlotCheckBox.setSelected(manager.getSettings().isHideEmptySlots());

		importButton = new Button("Import");
		exportButton = new Button("Export");
		advancedButton = new Button("Advanced");
		backButton = new Button("Back");
		saveButton = new Button("Save");
	}

	@Override
	protected Parent createView() {
		HBox rowBox = new HBox(10, new Label("Row"), rowSlider, rowLabel);
		HBox colBox = new HBox(10, new Label("Column"), colSlider, colLabel);
		HBox slotSizeBox = new HBox(10, new Label("Size"), slotSizeSlider, slotSizeLabel);
		HBox gapBox = new HBox(10, new Label("Gap"), gapSlider, gapLabel);
		HBox moveYBox = new HBox(10, new Label("Move Y"), moveYSlider, moveYLabel);
		HBox hideEmptySlotBox = new HBox(10, new Label("Hide Empty Slots"), hideEmptySlotCheckBox);
		VBox.setMargin(hideEmptySlotBox, new Insets(5, 0, 0, 0));

		Label actionBar = new Label("ACTION BAR");
		HBox topRow = new HBox(10);
		topRow.setAlignment(Pos.CENTER_LEFT);
		Region spacer = new Region();
		HBox.setHgrow(spacer, Priority.ALWAYS);
		topRow.getChildren().addAll(actionBar, spacer, importButton, exportButton);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(topRow, rowBox, colBox, slotSizeBox, gapBox, moveYBox, hideEmptySlotBox);

		Region spacer2 = new Region();
		HBox.setHgrow(spacer2, Priority.ALWAYS);

		HBox bottomButtons = new HBox(10, advancedButton, spacer2, backButton, saveButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		rowSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			rowSlider.setValue(newVal.intValue());
			rowLabel.setText(String.valueOf(newVal.intValue()));

			if (newVal.intValue() > 2) {
				if (((int) colSlider.getValue()) > 19) {
					colSlider.setValue(19);
					colLabel.setText(String.valueOf((int) colSlider.getValue()));
				}
			}
		});
		colSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			colSlider.setValue(newVal.intValue());
			colLabel.setText(String.valueOf(newVal.intValue()));

			if (newVal.intValue() > 19) {
				if (((int) rowSlider.getValue()) > 2) {
					rowSlider.setValue(2);
					rowLabel.setText(String.valueOf((int) rowSlider.getValue()));
				}
			}
		});
		slotSizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			slotSizeSlider.setValue(newVal.intValue());
			slotSizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		gapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			gapSlider.setValue(newVal.intValue());
			gapLabel.setText(String.valueOf(newVal.intValue()));
		});
		moveYSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveYSlider.setValue(newVal.intValue());
			moveYLabel.setText(String.valueOf(newVal.intValue()));
		});
		saveButton.setOnAction(e -> {
			manager.getSettings().setBottomBar_row((int) rowSlider.getValue());
			manager.getSettings().setBottomBar_column((int) colSlider.getValue());
			manager.getSettings().setSlot_size((int) slotSizeSlider.getValue());
			manager.getSettings().setIcon_spacing((int) gapSlider.getValue());
			manager.getSettings().setBottomBar_Pos_Y((int) moveYSlider.getValue());
			manager.getSettings().setHideEmptySlots(hideEmptySlotCheckBox.isSelected());
			if (Installer.runEditor(manager.getAoCDir())) {
				ShowAlert.showInfo("Complete", "Customizing Done");
			}
		});
		backButton.setOnAction(e -> {
			manager.showInstallTypeWindow();
		});
		importButton.setOnAction(e -> {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Import Profile");
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));

			// 🔹 초기 경로를 바탕화면으로 설정
			File desktopDir = new File(System.getProperty("user.home"), "Desktop");
			if (desktopDir.exists()) {
				fileChooser.setInitialDirectory(desktopDir);
			}

			File file = fileChooser.showOpenDialog(stage.getScene().getWindow());
			if (file != null) {
				if (SettingManager.loadProfile(file)) {
					// 값 리프레쉬
					slotSizeSlider.setValue(manager.getSettings().getSlot_size());
					slotSizeLabel.setText(String.valueOf(manager.getSettings().getSlot_size()));
					gapSlider.setValue(manager.getSettings().getIcon_spacing());
					gapLabel.setText(String.valueOf(manager.getSettings().getIcon_spacing()));
					rowSlider.setValue(manager.getSettings().getBottomBar_row());
					rowLabel.setText(String.valueOf(manager.getSettings().getBottomBar_row()));
					colSlider.setValue(manager.getSettings().getBottomBar_column());
					colLabel.setText(String.valueOf(manager.getSettings().getBottomBar_column()));
					moveYSlider.setValue(manager.getSettings().getBottomBar_Pos_Y());
					moveYLabel.setText(String.valueOf(manager.getSettings().getBottomBar_Pos_Y()));
					hideEmptySlotCheckBox.setSelected(manager.getSettings().isHideEmptySlots());

					ShowAlert.showInfo("Complete", "Profile is successfully loaded");
				} else {
					ShowAlert.showError("Error", "Wrong file");
				}
			}
		});
		exportButton.setOnAction(e -> {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Export Settings");
			fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
			fileChooser.setInitialFileName("profile.txt");

			// 🔹 초기 경로를 바탕화면으로 설정
			File desktopDir = new File(System.getProperty("user.home"), "Desktop");
			if (desktopDir.exists()) {
				fileChooser.setInitialDirectory(desktopDir);
			}

			File file = fileChooser.showSaveDialog(stage.getScene().getWindow());
			if (file != null) {
				SettingManager.saveProfile(file);
				ShowAlert.showInfo("Complete", "Your profile has been successfully saved");
			}

		});
		advancedButton.setOnAction(e -> {
			manager.getSettings().setBottomBar_row((int) rowSlider.getValue());
			manager.getSettings().setBottomBar_column((int) colSlider.getValue());
			manager.getSettings().setSlot_size((int) slotSizeSlider.getValue());
			manager.getSettings().setIcon_spacing((int) gapSlider.getValue());
			manager.getSettings().setBottomBar_Pos_Y((int) moveYSlider.getValue());
			manager.getSettings().setHideEmptySlots(hideEmptySlotCheckBox.isSelected());
			manager.showAdvanced();
		});
	}
}
