package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MiniSlotWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider colSlider;
	private Label colLabel;
	private Slider sizeSlider;
	private Label sizeLabel;
	private Slider gapSlider;
	private Label gapLabel;
	private Slider moveXSlider;
	private Label moveXLabel;
	private Slider moveYSlider;
	private Label moveYLabel;

	private Button okButton;
	private Button backButton;

	CheckBox hideCheckBox;

	public MiniSlotWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int col = manager.getSettings().getMiniSlot_count();
		int size = manager.getSettings().getMiniSlot_size();
		int gap = manager.getSettings().getMiniSlot_spacing();
		int x = manager.getSettings().getMiniSlot_pos_x();
		int y = manager.getSettings().getMiniSlot_pos_y();
		boolean hide = manager.getSettings().isMiniSlotHide();

		colSlider = createSlider(0, 5, col, 1, 200);
		colLabel = new Label(String.valueOf(col));

		sizeSlider = createSlider(33, 53, size, 2, 400);
		sizeLabel = new Label(String.valueOf(size));

		gapSlider = createSlider(-6, 0, gap, 1, 200);
		gapLabel = new Label(String.valueOf(gap));

		moveXSlider = createSlider(-1000, 1000, x, 1, 400);
		moveXLabel = new Label(String.valueOf(x));

		moveYSlider = createSlider(0, 800, y, 1, 400);
		moveYLabel = new Label(String.valueOf(y));

		hideCheckBox = new CheckBox("");
		hideCheckBox.setSelected(hide);

		if (col == 0) {
			sizeSlider.setDisable(true);
			sizeLabel.setText("");
			gapSlider.setDisable(true);
			gapLabel.setText("");
			moveXSlider.setDisable(true);
			moveXLabel.setText("");
			moveYSlider.setDisable(true);
			moveYLabel.setText("");
			hideCheckBox.setDisable(true);
		}

		if (manager.getSettings().isHideEmptySlots()) {
			hideCheckBox.setDisable(true);
			hideCheckBox.setSelected(true);
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox colBox = new HBox(10, new Label("Column"), colSlider, colLabel);
		HBox sizeBox = new HBox(10, new Label("Size"), sizeSlider, sizeLabel);
		HBox gapBox = new HBox(10, new Label("Gap"), gapSlider, gapLabel);
		HBox moveXBox = new HBox(10, new Label("Move X"), moveXSlider, moveXLabel);
		HBox moveYBox = new HBox(10, new Label("Move Y"), moveYSlider, moveYLabel);
		HBox hideBox = new HBox(10, new Label("Hide Empty Slots"), hideCheckBox);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(colBox, sizeBox, gapBox, moveXBox, moveYBox, hideBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		colSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			colSlider.setValue(newVal.intValue());
			colLabel.setText(String.valueOf(newVal.intValue()));

			if (newVal.intValue() == 0) {
				sizeSlider.setDisable(true);
				sizeLabel.setText("");
				gapSlider.setDisable(true);
				gapLabel.setText("");
				moveXSlider.setDisable(true);
				moveXLabel.setText("");
				moveYSlider.setDisable(true);
				moveYLabel.setText("");
				if (manager.getSettings().isHideEmptySlots())
					hideCheckBox.setSelected(true);
				else
					hideCheckBox.setSelected(false);
				hideCheckBox.setDisable(true);
			} else {
				sizeSlider.setDisable(false);
				sizeLabel.setText(String.valueOf((int) sizeSlider.getValue()));
				gapSlider.setDisable(false);
				gapLabel.setText(String.valueOf((int) gapSlider.getValue()));
				moveXSlider.setDisable(false);
				moveXLabel.setText(String.valueOf((int) moveXSlider.getValue()));
				moveYSlider.setDisable(false);
				moveYLabel.setText(String.valueOf((int) moveYSlider.getValue()));
				if (manager.getSettings().isHideEmptySlots()) {
					hideCheckBox.setDisable(true);
					hideCheckBox.setSelected(true);
				} else {
					hideCheckBox.setDisable(false);
				}
			}
		});
		gapSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			gapSlider.setValue(newVal.intValue());
			gapLabel.setText(String.valueOf(newVal.intValue()));
		});
		sizeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			sizeSlider.setValue(newVal.intValue());
			sizeLabel.setText(String.valueOf(newVal.intValue()));
		});
		moveXSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveXSlider.setValue(newVal.intValue());
			moveXLabel.setText(String.valueOf(newVal.intValue()));
		});
		moveYSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			moveYSlider.setValue(newVal.intValue());
			moveYLabel.setText(String.valueOf(newVal.intValue()));
		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setMiniSlot_count((int) colSlider.getValue());
			manager.getSettings().setMiniSlot_size((int) sizeSlider.getValue());
			manager.getSettings().setMiniSlot_spacing((int) gapSlider.getValue());
			manager.getSettings().setMiniSlot_pos_x((int) moveXSlider.getValue());
			manager.getSettings().setMiniSlot_pos_y((int) moveYSlider.getValue());
			manager.getSettings().setMiniSlotHide(hideCheckBox.isSelected());
			if (((int) sizeSlider.getValue()) < 41) {
				manager.getSettings().setMiniSlot_margin(4);
			} else if (((int) sizeSlider.getValue()) > 39 && ((int) sizeSlider.getValue()) < 49) {
				manager.getSettings().setMiniSlot_margin(5);
			} else if (((int) sizeSlider.getValue()) > 47) {
				manager.getSettings().setMiniSlot_margin(6);
			}
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Mini Slots";
	}
}
