package application.gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CastBarWindow extends BaseWindow {
	private final WindowManager manager;

	private Slider styleSlider;
	private Label styleLabel;
	private Slider colorSlider;
	private Label colorLabel;
	private Slider textLocSlider;
	private Label textLocLabel;
	private Slider alphaSlider;
	private Label alphaLabel;

	private Button okButton;
	private Button backButton;

	public CastBarWindow(Stage stage, WindowManager manager) {
		super(stage);
		this.manager = manager;
	}

	@Override
	protected void initComponents() {
		int style = manager.getSettings().getCastBar_style();
		int color = manager.getSettings().getCastBar_color();
		int textLoc = manager.getSettings().getCastBar_text_location();
		int alpha = (int) (manager.getSettings().getCastBar_alpha() * 100);

		styleSlider = createSlider(1, 2, style, 1, 100);
		styleLabel = new Label("");

		colorSlider = createSlider(1, 14, color, 1, 300);
		colorLabel = new Label("");

		textLocSlider = createSlider(1, 3, textLoc, 1, 120);
		textLocLabel = new Label("");

		alphaSlider = createSlider(80, 100, alpha, 1, 300);
		alphaLabel = new Label(String.valueOf(alpha));

		if (style == 1) {
			styleLabel.setText("Style 1");
			textLocSlider.setDisable(false);

			colorSlider.setDisable(false);
			if (textLoc == 1) {
				textLocLabel.setText("Top");
			} else if (textLoc == 2) {
				textLocLabel.setText("Inside");
			} else if (textLoc == 3) {
				textLocLabel.setText("Bottom");
			}

			// 색깔
			if (color == 1)
				colorLabel.setText("Yellow");
			else if (color == 2)
				colorLabel.setText("Aqua");
			else if (color == 3)
				colorLabel.setText("Blue");
			else if (color == 4)
				colorLabel.setText("Grass");
			else if (color == 5)
				colorLabel.setText("Green");
			else if (color == 6)
				colorLabel.setText("Lemon");
			else if (color == 7)
				colorLabel.setText("Orange");
			else if (color == 8)
				colorLabel.setText("Peach");
			else if (color == 9)
				colorLabel.setText("Pink");
			else if (color == 10)
				colorLabel.setText("Purple");
			else if (color == 11)
				colorLabel.setText("Sky");
			else if (color == 12)
				colorLabel.setText("Vanilla");
			else if (color == 13)
				colorLabel.setText("White");
			else if (color == 14)
				colorLabel.setText("Wine");

		} else if (style == 2) {
			styleLabel.setText("Style 2");
			textLocSlider.setDisable(true);
			textLocLabel.setText("");

			colorSlider.setDisable(true);
			colorLabel.setText("");
		}

		backButton = new Button("Back");
		okButton = new Button("OK");
	}

	@Override
	protected Parent createView() {
		HBox styleBox = new HBox(10, new Label("Style"), styleSlider, styleLabel);
		HBox colorBox = new HBox(10, new Label("Color"), colorSlider, colorLabel);
		HBox textLocBox = new HBox(10, new Label("Text Location"), textLocSlider, textLocLabel);
		HBox alphaBox = new HBox(10, new Label("Alpha"), alphaSlider, alphaLabel);

		VBox centerBox = new VBox(15);
		centerBox.setPadding(new Insets(20));
		centerBox.getChildren().addAll(styleBox, colorBox, textLocBox, alphaBox);

		HBox bottomButtons = new HBox(10, backButton, okButton);
		bottomButtons.setPadding(new Insets(15));
		bottomButtons.setAlignment(Pos.BOTTOM_RIGHT);

		BorderPane root = new BorderPane();
		root.setCenter(centerBox);
		root.setBottom(bottomButtons);

		return root;
	}

	@Override
	protected void initActions() {
		styleSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			styleSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1) {
				styleLabel.setText("Style 1");
				textLocSlider.setDisable(false);
				colorSlider.setDisable(false);
				
				if (((int) colorSlider.getValue()) == 1)
					colorLabel.setText("Yellow");
				else if (((int) colorSlider.getValue()) == 2)
					colorLabel.setText("Aqua");
				else if (((int) colorSlider.getValue()) == 3)
					colorLabel.setText("Blue");
				else if (((int) colorSlider.getValue()) == 4)
					colorLabel.setText("Grass");
				else if (((int) colorSlider.getValue()) == 5)
					colorLabel.setText("Green");
				else if (((int) colorSlider.getValue()) == 6)
					colorLabel.setText("Lemon");
				else if (((int) colorSlider.getValue()) == 7)
					colorLabel.setText("Orange");
				else if (((int) colorSlider.getValue()) == 8)
					colorLabel.setText("Peach");
				else if (((int) colorSlider.getValue()) == 9)
					colorLabel.setText("Pink");
				else if (((int) colorSlider.getValue()) == 10)
					colorLabel.setText("Purple");
				else if (((int) colorSlider.getValue()) == 11)
					colorLabel.setText("Sky");
				else if (((int) colorSlider.getValue()) == 12)
					colorLabel.setText("Vanilla");
				else if (((int) colorSlider.getValue()) == 13)
					colorLabel.setText("White");
				else if (((int) colorSlider.getValue()) == 14)
					colorLabel.setText("Wine");

				if (((int) textLocSlider.getValue()) == 1)
					textLocLabel.setText("Top");
				else if (((int) textLocSlider.getValue()) == 2)
					textLocLabel.setText("Inside");
				else if (((int) textLocSlider.getValue()) == 3)
					textLocLabel.setText("Bottom");
				else
					textLocLabel.setText("");

			} else if (newVal.intValue() == 2) {
				styleLabel.setText("Style 2");
				textLocSlider.setDisable(true);
				colorSlider.setDisable(true);
				colorLabel.setText("");
				textLocLabel.setText("");
			}

		});
		alphaSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			alphaSlider.setValue(newVal.intValue());
			alphaLabel.setText(String.valueOf(newVal.intValue()));
		});
		textLocSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			textLocSlider.setValue(newVal.intValue());
			if (newVal.intValue() == 1)
				textLocLabel.setText("Top");
			else if (newVal.intValue() == 2)
				textLocLabel.setText("Inside");
			else if (newVal.intValue() == 3)
				textLocLabel.setText("Bottom");
			else
				textLocLabel.setText("");
		});
		colorSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
			colorSlider.setValue(newVal.intValue());
			
			if (newVal.intValue() == 1)
				colorLabel.setText("Yellow");
			else if (newVal.intValue() == 2)
				colorLabel.setText("Aqua");
			else if (newVal.intValue() == 3)
				colorLabel.setText("Blue");
			else if (newVal.intValue() == 4)
				colorLabel.setText("Grass");
			else if (newVal.intValue() == 5)
				colorLabel.setText("Green");
			else if (newVal.intValue() == 6)
				colorLabel.setText("Lemon");
			else if (newVal.intValue() == 7)
				colorLabel.setText("Orange");
			else if (newVal.intValue() == 8)
				colorLabel.setText("Peach");
			else if (newVal.intValue() == 9)
				colorLabel.setText("Pink");
			else if (newVal.intValue() == 10)
				colorLabel.setText("Purple");
			else if (newVal.intValue() == 11)
				colorLabel.setText("Sky");
			else if (newVal.intValue() == 12)
				colorLabel.setText("Vanilla");
			else if (newVal.intValue() == 13)
				colorLabel.setText("White");
			else if (newVal.intValue() == 14)
				colorLabel.setText("Wine");

		});

		backButton.setOnAction(e -> manager.showAdvanced(stage));
		okButton.setOnAction(e -> {
			manager.getSettings().setCastBar_style((int) styleSlider.getValue());
			manager.getSettings().setCastBar_color((int) colorSlider.getValue());
			manager.getSettings().setCastBar_text_location((int) textLocSlider.getValue());
			manager.getSettings().setCastBar_alpha(alphaSlider.getValue() / 100);
			manager.showAdvanced(stage);
		});
	}

	@Override
	protected String getTitle() {
		return "Castbar";
	}

}
